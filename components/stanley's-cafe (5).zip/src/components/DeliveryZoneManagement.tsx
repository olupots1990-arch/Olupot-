import React, { useState, useMemo } from 'react';
import type { DeliveryZone, DeliveryAgent, LocationInfo } from '../types';
import { ZONE_COLORS } from '../constants';
import { PlusCircleIcon, EditIcon, TrashIcon, AlertTriangleIcon, CloseIcon, MapPinIcon } from './icons';

interface ZoneFormModalProps {
    zoneToEdit: Omit<DeliveryZone, 'id' | 'color'> | null;
    allAgents: DeliveryAgent[];
    onSave: (zoneData: Omit<DeliveryZone, 'id' | 'color'>) => void;
    onClose: () => void;
    currencySymbol: string;
}

const ZoneFormModal: React.FC<ZoneFormModalProps> = ({ zoneToEdit, allAgents, onSave, onClose, currencySymbol }) => {
    const [formData, setFormData] = useState({
        name: zoneToEdit?.name || '',
        radius: zoneToEdit?.radius || 5,
        deliveryFee: zoneToEdit?.deliveryFee || 0,
        assignedAgentIds: zoneToEdit?.assignedAgentIds || [],
    });

    const handleAgentToggle = (agentId: string) => {
        setFormData(prev => ({
            ...prev,
            assignedAgentIds: prev.assignedAgentIds.includes(agentId)
                ? prev.assignedAgentIds.filter(id => id !== agentId)
                : [...prev.assignedAgentIds, agentId]
        }));
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">{zoneToEdit ? 'Edit Delivery Zone' : 'Create New Zone'}</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </header>
                <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium">Zone Name</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={e => setFormData(p => ({...p, name: e.target.value}))} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <div>
                        <label htmlFor="radius" className="block text-sm font-medium">Radius ({formData.radius} km)</label>
                        <input type="range" name="radius" id="radius" value={formData.radius} onChange={e => setFormData(p => ({...p, radius: Number(e.target.value)}))} min="1" max="50" step="1" className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700" />
                    </div>
                    <div>
                        <label htmlFor="deliveryFee" className="block text-sm font-medium">Delivery Fee ({currencySymbol})</label>
                        <input type="number" name="deliveryFee" id="deliveryFee" value={formData.deliveryFee} onChange={e => setFormData(p => ({...p, deliveryFee: Number(e.target.value)}))} required min="0" step="0.01" className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <div>
                        <h4 className="block text-sm font-medium mb-2">Assign Agents</h4>
                        <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto p-2 border rounded-md dark:border-gray-600">
                            {allAgents.map(agent => (
                                <label key={agent.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700">
                                    <input type="checkbox" checked={formData.assignedAgentIds.includes(agent.id)} onChange={() => handleAgentToggle(agent.id)} className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500" />
                                    <span>{agent.name}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                    <footer className="flex justify-end gap-3 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 rounded-md">Cancel</button>
                        <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save Zone</button>
                    </footer>
                </form>
            </div>
        </div>
    );
};


interface DeliveryZoneManagementProps {
    deliveryZones: DeliveryZone[];
    setDeliveryZones: React.Dispatch<React.SetStateAction<DeliveryZone[]>>;
    agents: DeliveryAgent[];
    location: LocationInfo;
    currencySymbol: string;
}

const DeliveryZoneManagement: React.FC<DeliveryZoneManagementProps> = ({ deliveryZones, setDeliveryZones, agents, location, currencySymbol }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingZone, setEditingZone] = useState<DeliveryZone | null>(null);
    const [zoneToDelete, setZoneToDelete] = useState<DeliveryZone | null>(null);
    const [hoveredZoneId, setHoveredZoneId] = useState<string | null>(null);
    
    const agentMap = useMemo(() => new Map(agents.map(a => [a.id, a.name])), [agents]);

    const handleSave = (zoneData: Omit<DeliveryZone, 'id' | 'color'>) => {
        if (editingZone) {
            setDeliveryZones(prev => prev.map(z => (z.id === editingZone.id ? { ...editingZone, ...zoneData } : z)));
        } else {
            const newZone: DeliveryZone = {
                ...zoneData,
                id: `zone-${Date.now()}`,
                color: ZONE_COLORS[deliveryZones.length % ZONE_COLORS.length],
            };
            setDeliveryZones(prev => [...prev, newZone]);
        }
        setIsModalOpen(false);
        setEditingZone(null);
    };

    const handleDelete = () => {
        if (zoneToDelete) {
            setDeliveryZones(prev => prev.filter(z => z.id !== zoneToDelete.id));
            setZoneToDelete(null);
        }
    };

    const maxRadius = useMemo(() => Math.max(10, ...deliveryZones.map(z => z.radius)), [deliveryZones]);

    return (
        <div className="p-6 space-y-6">
             <header>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Delivery Zones</h2>
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                    Define delivery areas, fees, and assign agents to specific zones.
                </p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pt-4 border-t dark:border-gray-700">
                <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Zone Map</h3>
                     <div className="relative w-full aspect-square bg-gray-100 dark:bg-gray-900/50 rounded-lg flex items-center justify-center p-4">
                        {deliveryZones.sort((a, b) => b.radius - a.radius).map(zone => (
                             <div 
                                key={zone.id} 
                                className="absolute rounded-full transition-all duration-300"
                                style={{
                                    width: `${(zone.radius / maxRadius) * 100}%`,
                                    height: `${(zone.radius / maxRadius) * 100}%`,
                                    backgroundColor: `${zone.color}20`,
                                    border: `2px solid ${zone.color}`,
                                    transform: `scale(${hoveredZoneId === zone.id ? 1.05 : 1})`,
                                    boxShadow: hoveredZoneId === zone.id ? `0 0 15px ${zone.color}` : 'none',
                                    zIndex: hoveredZoneId === zone.id ? 10 : 1,
                                }}
                            >
                                <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white dark:bg-gray-800 px-2 py-0.5 text-xs rounded-full" style={{ color: zone.color }}>{zone.name}</span>
                            </div>
                        ))}
                         <div className="relative z-10 text-center">
                            <MapPinIcon className="w-8 h-8 text-red-500 mx-auto" />
                            <p className="text-sm font-bold mt-1">Stanley's Cafe</p>
                            <p className="text-xs text-gray-500">{location.address.split(',')[0]}</p>
                        </div>
                    </div>
                </div>
                <div className="space-y-4">
                    <div className="flex justify-between items-center">
                         <h3 className="text-lg font-semibold">Configured Zones</h3>
                         <button onClick={() => { setEditingZone(null); setIsModalOpen(true); }} className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700">
                            <PlusCircleIcon className="w-5 h-5" /> Add Zone
                        </button>
                    </div>
                    <div className="space-y-3">
                        {deliveryZones.map(zone => (
                            <div key={zone.id} className="p-4 border rounded-lg dark:border-gray-700" onMouseEnter={() => setHoveredZoneId(zone.id)} onMouseLeave={() => setHoveredZoneId(null)}>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <p className="font-bold" style={{ color: zone.color }}>{zone.name}</p>
                                        <p className="text-sm text-gray-600 dark:text-gray-300">Radius: {zone.radius}km | Fee: {currencySymbol}{zone.deliveryFee.toFixed(2)}</p>
                                        <div className="mt-2 text-xs">
                                            <p className="font-semibold">Assigned Agents:</p>
                                            <div className="flex flex-wrap gap-1 mt-1">
                                            {zone.assignedAgentIds.length > 0 ? zone.assignedAgentIds.map(id => (
                                                <span key={id} className="px-2 py-0.5 bg-gray-200 dark:bg-gray-700 rounded-full">{agentMap.get(id) || 'Unknown'}</span>
                                            )) : <span className="text-gray-500">None</span>}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        <button onClick={() => { setEditingZone(zone); setIsModalOpen(true); }} className="p-1 text-gray-500 hover:text-indigo-500"><EditIcon className="w-5 h-5"/></button>
                                        <button onClick={() => setZoneToDelete(zone)} className="p-1 text-gray-500 hover:text-red-500"><TrashIcon className="w-5 h-5"/></button>
                                    </div>
                                </div>
                            </div>
                        ))}
                         {deliveryZones.length === 0 && <p className="text-center text-gray-500 py-8">No delivery zones created yet.</p>}
                    </div>
                </div>
            </div>

            {isModalOpen && <ZoneFormModal zoneToEdit={editingZone} allAgents={agents} onSave={handleSave} onClose={() => setIsModalOpen(false)} currencySymbol={currencySymbol} />}

            {zoneToDelete && (
                 <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60] p-4">
                    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
                        <div className="p-6 text-center">
                             <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 dark:bg-red-900/50"><AlertTriangleIcon className="h-6 w-6 text-red-600 dark:text-red-300" /></div>
                            <h3 className="mt-5 text-lg font-medium text-gray-900 dark:text-white">Delete Zone</h3>
                            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">Are you sure you want to delete the "{zoneToDelete.name}" zone? This cannot be undone.</p>
                        </div>
                        <div className="flex justify-center gap-3 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-b-lg">
                            <button onClick={() => setZoneToDelete(null)} className="px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600">Cancel</button>
                            <button onClick={handleDelete} className="px-4 py-2 text-white bg-red-600 rounded-md hover:bg-red-700">Delete</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DeliveryZoneManagement;
