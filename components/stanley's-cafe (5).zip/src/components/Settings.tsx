import React, { useState } from 'react';
import { MediaManagement } from './MediaManagement';
import BusinessInfoManagement from './BusinessInfoManagement';
import type { BackgroundMedia, LocationInfo, VoiceoverAsset, Advertisement, DeploymentLog, AiAssistantSettings, MenuItem, DeliveryZone, DeliveryAgent } from '../types';
import { FilmIcon, MapIcon, CogIcon, UploadCloudIcon, MenuIcon, MapPinIcon } from './icons';
import APISystemSettings from './APISystemSettings';
import DeploymentManagement from './DeploymentManagement';
import MenuManagement from './MenuManagement';
import DeliveryZoneManagement from './DeliveryZoneManagement';

interface SettingsProps {
  backgroundVideos: (BackgroundMedia | null)[];
  setBackgroundVideos: React.Dispatch<React.SetStateAction<(BackgroundMedia | null)[]>>;
  backgroundImages: (BackgroundMedia | null)[];
  setBackgroundImages: React.Dispatch<React.SetStateAction<(BackgroundMedia | null)[]>>;
  backgroundMusicUrl: string | null;
  onMusicChange: React.Dispatch<React.SetStateAction<string | null>>;
  location: LocationInfo;
  onLocationChange: React.Dispatch<React.SetStateAction<LocationInfo>>;
  domainName: string;
  setDomainName: React.Dispatch<React.SetStateAction<string>>;
  mediaLibrary: BackgroundMedia[];
  setMediaLibrary: React.Dispatch<React.SetStateAction<BackgroundMedia[]>>;
  voiceoverLibrary: VoiceoverAsset[];
  setVoiceoverLibrary: React.Dispatch<React.SetStateAction<VoiceoverAsset[]>>;
  currencySymbol: string;
  setCurrencySymbol: React.Dispatch<React.SetStateAction<string>>;
  advertisements: Advertisement[];
  setAdvertisements: React.Dispatch<React.SetStateAction<Advertisement[]>>;
  onNavigateToUsers: () => void;
  galleryProductIds: string[];
  setGalleryProductIds: React.Dispatch<React.SetStateAction<string[]>>;
  menuItems: MenuItem[];
  setMenuItems: React.Dispatch<React.SetStateAction<MenuItem[]>>;
  isOnline: boolean;
  deploymentHistory: DeploymentLog[];
  setDeploymentHistory: React.Dispatch<React.SetStateAction<DeploymentLog[]>>;
  aiSettings: AiAssistantSettings;
  setAiSettings: React.Dispatch<React.SetStateAction<AiAssistantSettings>>;
  deliveryZones: DeliveryZone[];
  setDeliveryZones: React.Dispatch<React.SetStateAction<DeliveryZone[]>>;
  agents: DeliveryAgent[];
}

type SettingsTab = 'media' | 'menu' | 'info' | 'zones' | 'deployment' | 'system';

const Settings: React.FC<SettingsProps> = (props) => {
  const [activeTab, setActiveTab] = useState<SettingsTab>('system');

  const { 
    location, onLocationChange, 
    domainName, setDomainName,
    backgroundVideos, setBackgroundVideos,
    backgroundImages, setBackgroundImages,
    backgroundMusicUrl, onMusicChange,
    mediaLibrary, setMediaLibrary,
    voiceoverLibrary, setVoiceoverLibrary,
    currencySymbol, setCurrencySymbol,
    advertisements, setAdvertisements,
    onNavigateToUsers,
    galleryProductIds, setGalleryProductIds,
    menuItems, setMenuItems,
    isOnline,
    deploymentHistory, setDeploymentHistory,
    aiSettings, setAiSettings,
    deliveryZones, setDeliveryZones,
    agents
  } = props;
  
  const TabButton = ({ tab, icon, label }: {tab: SettingsTab, icon: React.ReactNode, label: string}) => (
    <button
        onClick={() => setActiveTab(tab)}
        className={`flex items-center gap-2 px-4 py-3 -mb-px text-sm font-semibold transition-colors duration-200 focus:outline-none ${
            activeTab === tab
                ? 'border-b-2 border-indigo-500 text-indigo-600 dark:text-indigo-400'
                : 'border-b-2 border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
        }`}
    >
        {icon}
        {label}
    </button>
  );

  return (
    <div className="space-y-6">
      <nav className="flex flex-wrap space-x-1 border-b-2 border-gray-200 dark:border-gray-700">
          <TabButton tab="media" icon={<FilmIcon className="w-5 h-5"/>} label="Homepage Media" />
          <TabButton tab="menu" icon={<MenuIcon className="w-5 h-5"/>} label="Menu" />
          <TabButton tab="info" icon={<MapIcon className="w-5 h-5"/>} label="Business Info" />
          <TabButton tab="zones" icon={<MapPinIcon className="w-5 h-5"/>} label="Delivery Zones" />
          <TabButton tab="deployment" icon={<UploadCloudIcon className="w-5 h-5"/>} label="Deployment" />
          <TabButton tab="system" icon={<CogIcon className="w-5 h-5"/>} label="API & System" />
      </nav>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg">
        {activeTab === 'media' && (
          <MediaManagement
              backgroundVideos={backgroundVideos}
              setBackgroundVideos={setBackgroundVideos}
              backgroundImages={backgroundImages}
              setBackgroundImages={setBackgroundImages}
              backgroundMusicUrl={backgroundMusicUrl}
              onMusicChange={onMusicChange}
              mediaLibrary={mediaLibrary}
              setMediaLibrary={setMediaLibrary}
              voiceoverLibrary={voiceoverLibrary}
              setVoiceoverLibrary={setVoiceoverLibrary}
              advertisements={advertisements}
              setAdvertisements={setAdvertisements}
              galleryProductIds={galleryProductIds}
              setGalleryProductIds={setGalleryProductIds}
              menuItems={menuItems}
              isOnline={isOnline}
            />
        )}
        {activeTab === 'menu' && (
            <MenuManagement 
                menuItems={menuItems}
                setMenuItems={setMenuItems}
                currencySymbol={currencySymbol}
            />
        )}
        {activeTab === 'info' && (
          <BusinessInfoManagement
              location={location} 
              onLocationChange={onLocationChange} 
              currencySymbol={currencySymbol}
              setCurrencySymbol={setCurrencySymbol}
              isOnline={isOnline}
              domainName={domainName}
              setDomainName={setDomainName}
            />
        )}
        {activeTab === 'zones' && (
          <DeliveryZoneManagement
            deliveryZones={deliveryZones}
            setDeliveryZones={setDeliveryZones}
            agents={agents}
            location={location}
            currencySymbol={currencySymbol}
          />
        )}
        {activeTab === 'deployment' && (
            <DeploymentManagement
                deploymentHistory={deploymentHistory}
                setDeploymentHistory={setDeploymentHistory}
                domainName={domainName}
            />
        )}
        {activeTab === 'system' && (
          <APISystemSettings
            onNavigateToUsers={onNavigateToUsers}
            aiSettings={aiSettings}
            setAiSettings={setAiSettings}
          />
        )}
      </div>
    </div>
  );
};

export default Settings;