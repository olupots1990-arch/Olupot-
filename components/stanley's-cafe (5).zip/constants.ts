import { Order, DeliveryAgent, OrderStatus, PaymentMethod, LeaveRequest, User, Employee, Advertisement, InventoryItem, InventoryLogEntry, MenuItem } from './types';

export const INITIAL_MENU_ITEMS: MenuItem[] = [
  { id: '1', name: 'Margherita Pizza', price: 12.99, imageUrl: 'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/margherita.jpg' },
  { id: '2', name: 'Pepperoni Pizza', price: 14.99, imageUrl: 'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/pepperoni.jpg' },
  { id: '3', name: 'Spaghetti Carbonara', price: 15.50, imageUrl: 'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/spaghetti.jpg' },
  { id: '4', name: 'Caesar Salad', price: 9.75, imageUrl: 'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/salad.jpg' },
  { id: '5', name: 'Garlic Bread', price: 5.00, imageUrl: 'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/garlic-bread.jpg' },
  { id: '6', name: 'Tiramisu', price: 7.50, imageUrl: 'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/tiramisu.jpg' },
];

export const DEFAULT_BACKGROUND_VIDEO = 'https://videos.pexels.com/video-files/3209828/3209828-hd_1920_1080_25fps.mp4';

export const INITIAL_DELIVERY_AGENTS: DeliveryAgent[] = [
  { 
    id: 'agent-1', 
    name: 'John Doe', 
    status: 'available', 
    phone: '+1 (555) 123-4567',
    commissionRate: 12,
    attendance: {
      '2024-07-01': 'present', '2024-07-02': 'present', '2024-07-03': 'absent', '2024-07-04': 'present', '2024-07-05': 'on-leave' 
    }
  },
  { 
    id: 'agent-2', 
    name: 'Jane Smith', 
    status: 'on-delivery', 
    phone: '+1 (555) 987-6543',
    commissionRate: 10,
    attendance: {
       '2024-07-01': 'present', '2024-07-02': 'present', '2024-07-03': 'present', '2024-07-04': 'present', '2024-07-05': 'present' 
    }
  },
  { 
    id: 'agent-3', 
    name: 'Mike Ross', 
    status: 'available', 
    phone: '',
    attendance: {
       '2024-07-01': 'present', '2024-07-02': 'on-leave', '2024-07-03': 'on-leave', '2024-07-04': 'present', '2024-07-05': 'present' 
    }
  },
  { 
    id: 'agent-4', 
    name: 'Rachel Zane', 
    status: 'offline', 
    phone: '+1 (555) 135-7911',
    commissionRate: 15,
    attendance: {}
  },
];

export const MOCK_LEAVE_REQUESTS: LeaveRequest[] = [
    {
        id: 'leave-1',
        employeeId: 'agent-4',
        employeeName: 'Rachel Zane',
        employeeType: 'agent',
        startDate: new Date(new Date().setDate(new Date().getDate() + 5)),
        endDate: new Date(new Date().setDate(new Date().getDate() + 7)),
        reason: 'Family emergency.',
        status: 'pending',
    },
    {
        id: 'leave-2',
        employeeId: 'agent-1',
        employeeName: 'John Doe',
        employeeType: 'agent',
        startDate: new Date(new Date().setDate(new Date().getDate() - 10)),
        endDate: new Date(new Date().setDate(new Date().getDate() - 9)),
        reason: 'Personal appointment.',
        status: 'approved',
    },
    {
        id: 'leave-3',
        employeeId: 'emp-2',
        employeeName: 'Marie Curie',
        employeeType: 'employee',
        startDate: new Date(new Date().setDate(new Date().getDate() + 2)),
        endDate: new Date(new Date().setDate(new Date().getDate() + 3)),
        reason: 'Doctor\'s appointment.',
        status: 'pending',
    }
];


export const MOCK_ORDERS: Order[] = [
  {
    id: 'ORD-001',
    customerId: 'user-cust-1',
    customerName: 'Alice',
    customerPhone: '256772715106',
    items: [
      { name: 'Margherita Pizza', quantity: 1 },
      { name: 'Garlic Bread', quantity: 2 },
    ],
    total: 22.99,
    status: OrderStatus.PENDING,
    timestamp: new Date(Date.now() - 5 * 60 * 1000),
    isPaid: false,
    paymentMethod: PaymentMethod.MOBILE_MONEY,
  },
  {
    id: 'ORD-002',
    customerId: 'user-cust-2',
    customerName: 'Bob',
    customerPhone: '256772715106',
    items: [
      { name: 'Spaghetti Carbonara', quantity: 2 },
    ],
    total: 31.00,
    status: OrderStatus.CONFIRMED,
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    isPaid: true,
    paymentMethod: PaymentMethod.CREDIT_CARD,
  },
  {
    id: 'ORD-003',
    customerId: 'user-cust-3',
    customerName: 'Charlie',
    customerPhone: '256772715106',
    items: [
        { name: 'Pepperoni Pizza', quantity: 1 },
        { name: 'Caesar Salad', quantity: 1 },
        { name: 'Tiramisu', quantity: 1 },
    ],
    total: 32.24,
    status: OrderStatus.OUT_FOR_DELIVERY,
    timestamp: new Date(Date.now() - 35 * 60 * 1000),
    deliveryAgentId: 'agent-2',
    isPaid: false,
    paymentMethod: PaymentMethod.CASH,
    deliveryAgentNotes: 'Customer requested contactless delivery. Please leave at the door and call upon arrival.',
  },
];

export const INITIAL_USERS: User[] = [
  { id: 'user-1', name: 'Admin User', email: 'admin@stanleys.cafe', role: 'admin' },
  { id: 'user-2', name: 'Manager Mike', email: 'manager@stanleys.cafe', role: 'manager' },

];

export const INITIAL_EMPLOYEES: Employee[] = [
  {
    id: 'emp-1',
    name: 'Gordon Ramsay',
    role: 'Chef',
    hireDate: new Date(''),
    email: '',
    phone: '555-987-6543',
    files: [],
    baseSalary: 4500,
    attendance: {},
  },
  {
    id: 'emp-2',
    name: 'Marie Curie',
    role: 'Waiter',
    hireDate: new Date(''),
    phone: '',
    email: '',
    files: [],
    baseSalary: 2800,
    attendance: {},
  },
];

export const INITIAL_ADVERTISEMENTS: Advertisement[] = [
  {
    id: 'ad-1',
    productId: '1', // Margherita Pizza
    title: "Margherita Mondays!",
    description: "Enjoy our classic Margherita pizza at a special price every Monday!",
    isActive: true,
  },
  {
    id: 'ad-2',
    productId: '6', // Tiramisu
    title: "Sweet Finish",
    description: "The perfect sweet finish to any meal. Try our classic Tiramisu today!",
    isActive: false,
  }
];

export const INITIAL_INVENTORY: InventoryItem[] = [
  { id: 'inv-1', name: 'Chef Jacket - M', category: 'Uniform', assignedTo: 'emp-1' },
  { id: 'inv-2', name: 'Chef Jacket - L', category: 'Uniform', assignedTo: null },
  { id: 'inv-3', name: 'POS Tablet', category: 'Electronics', assignedTo: 'emp-2' },
  { id: 'inv-4', name: 'Waiter Apron', category: 'Uniform', assignedTo: null },
  { id: 'inv-5', name: 'Card Reader', category: 'Electronics', assignedTo: null },
];

export const INITIAL_INVENTORY_LOGS: InventoryLogEntry[] = [
  { 
    id: 'log-1', 
    itemId: 'inv-1', 
    employeeId: 'emp-1', 
    action: 'assigned', 
    timestamp: new Date('2023-10-01T10:00:00Z'),
    notes: 'Standard issue jacket for new chef.'
  },
  { 
    id: 'log-2', 
    itemId: 'inv-3', 
    employeeId: 'emp-2', 
    action: 'assigned', 
    timestamp: new Date('2023-11-15T14:30:00Z'),
    notes: 'For front-of-house operations.'
  },
];

export const CURRENCY_DATA = [
    { country: 'United States', code: 'USD', symbol: '$' },
    { country: 'Canada', code: 'CAD', symbol: 'C$' },
    { country: 'Australia', code: 'AUD', symbol: 'A$' },
    { country: 'United Kingdom', code: 'GBP', symbol: '£' },
    { country: 'Japan', code: 'JPY', symbol: '¥' },
    { country: 'Switzerland', code: 'CHF', symbol: 'CHF' },
    { country: 'China', code: 'CNY', symbol: 'CN¥' },
    { country: 'India', code: 'INR', symbol: '₹' },
    { country: 'Brazil', code: 'BRL', symbol: 'R$' },
    { country: 'Russia', code: 'RUB', symbol: '₽' },
    { country: 'South Africa', code: 'ZAR', symbol: 'R' },
    { country: 'South Korea', code: 'KRW', symbol: '₩' },
    { country: 'Nigeria', code: 'NGN', symbol: '₦' },
    { country: 'Malta', code: 'EUR', symbol: '€' }
];

export const INITIAL_GALLERY_PRODUCT_IDS = ['1', '2', '3', '4', '5', '6'];