


import React, { useState } from 'react';
import { MicIcon, SendIcon, StopCircleIcon } from './icons';

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  isRecording: boolean;
  startRecording: () => void;
  stopRecording: () => void;
  isLoading: boolean;
  isOnline: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isRecording, startRecording, stopRecording, isLoading, isOnline }) => {
  const [inputText, setInputText] = useState('');

  const handleSend = () => {
    if (inputText.trim() && !isLoading) {
      onSendMessage(inputText);
      setInputText('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };
  
  const handleMicClick = () => {
    if (isRecording) {
        stopRecording();
    } else {
        startRecording();
    }
  };

  return (
    <div className="flex items-center space-x-2">
      <input
        type="text"
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        onKeyPress={handleKeyPress}
        placeholder={isOnline ? "Type your message or order..." : "Chat is disabled while offline"}
        className="flex-1 bg-gray-800 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 disabled:opacity-70"
        disabled={isLoading || isRecording || !isOnline}
      />
      <button
        onClick={handleMicClick}
        disabled={isLoading || !isOnline}
        className={`p-2.5 rounded-full text-white transition-colors duration-200 ${
            isRecording ? 'bg-red-500 hover:bg-red-600 animate-pulse' : 'bg-green-500 hover:bg-green-600'
        } disabled:bg-gray-500`}
      >
        {isRecording ? <StopCircleIcon className="w-5 h-5"/> : <MicIcon className="w-5 h-5" />}
      </button>
      <button
        onClick={handleSend}
        disabled={isLoading || isRecording || !isOnline}
        className="p-2.5 bg-blue-500 text-white rounded-full hover:bg-blue-600 disabled:bg-gray-500 transition-colors duration-200"
      >
        <SendIcon className="w-5 h-5" />
      </button>
    </div>
  );
};

export default ChatInput;