

import React, { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { sendChatMessage, askWithSearch, askWithMaps, handleComplexQuery, generateSpeech, getSuggestions } from '../services/geminiService';
import type { Message, GeolocationCoordinates, Suggestion, AiAssistantSettings, MenuItem } from '../types';
import ChatWindow from './ChatWindow';
import ChatInput from './ChatInput';
import useLiveChat from '../hooks/useLiveChat';
import { AICreativeTools } from './AICreativeTools';
import { BrainCircuitIcon, ImagePlusIcon, MapIcon, SearchIcon, Volume2Icon, WhatsAppIcon, LightbulbIcon } from './icons';

interface CustomerViewProps {
  backgroundMediaUrl: string;
  initialChatMessage: string | null;
  setInitialChatMessage: React.Dispatch<React.SetStateAction<string | null>>;
  isOnline: boolean;
  aiSettings: AiAssistantSettings;
  menuItems: MenuItem[];
}

const isVideo = (url: string) => /\.(mp4|webm|ogg)$/i.test(url);

const CustomerView: React.FC<CustomerViewProps> = ({ backgroundMediaUrl, initialChatMessage, setInitialChatMessage, isOnline, aiSettings, menuItems }) => {
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', text: "Hi there! I'm Stan, your friendly guide to all things delicious at Stanley's Restaurant! 🍕 Whether you want to place an order, ask about today's specials, or just chat about food, I'm here to help. What can I get for you?", sender: 'bot', timestamp: new Date().toLocaleTimeString() }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [showCreativeTools, setShowCreativeTools] = useState(false);
  const [suggestion, setSuggestion] = useState<Suggestion | null>(null);
  const aiRef = useRef<GoogleGenAI | null>(null);

  const { isRecording, transcript, startRecording, stopRecording } = useLiveChat();
  const adminWhatsAppNumber = "256772715106";
  const whatsAppUrl = `https://wa.me/${adminWhatsAppNumber}`;

  const handleSendMessage = useCallback(async (text: string, tool?: 'search' | 'maps' | 'complex') => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString(),
    };
    setMessages(prev => [...prev, userMessage]);
    setSuggestion(null); // Clear previous suggestion

    if (!isOnline) {
      const offlineMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "I'm sorry, I can't connect to the kitchen right now. My AI features are disabled while offline. Please check your internet connection.",
        sender: 'bot',
        timestamp: new Date().toLocaleTimeString(),
      };
      setMessages(prev => [...prev, offlineMessage]);
      return;
    }

    setIsLoading(true);

    try {
      if (!aiRef.current) {
        aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      }
      const ai = aiRef.current;
      let botResponse: { text: string; sources?: { uri: string; title: string }[] };

      switch(tool) {
        case 'search':
          botResponse = await askWithSearch(ai, text);
          break;
        case 'maps':
          // In a real app, you would get this from the browser's geolocation API
          const location: GeolocationCoordinates = { latitude: 37.78193, longitude: -122.40476 };
          botResponse = await askWithMaps(ai, text, location);
          break;
        case 'complex':
          botResponse = await handleComplexQuery(ai, text);
          break;
        default:
          botResponse = await sendChatMessage(ai, messages, text, aiSettings.systemPrompt);
      }

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: botResponse.text,
        sender: 'bot',
        timestamp: new Date().toLocaleTimeString(),
        sources: botResponse.sources,
      };
      setMessages(prev => [...prev, botMessage]);

      // After getting the bot's response, ask for suggestions
      try {
        const fullHistory = [...messages, userMessage, botMessage];
        const newSuggestion = await getSuggestions(ai, fullHistory, aiSettings.suggestionsEnabled, menuItems);
        setSuggestion(newSuggestion);
      } catch (suggestionError) {
        console.error("Failed to fetch suggestion:", suggestionError);
        setSuggestion(null); // Ensure suggestion is cleared on error
      }

    } catch (error) {
      console.error("Error with Gemini API:", error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "I'm sorry, I'm having a little trouble connecting to my kitchen staff right now. Please try your request again in a moment.",
        sender: 'bot',
        timestamp: new Date().toLocaleTimeString(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [messages, isOnline, aiSettings, menuItems]);
  
  useEffect(() => {
    if (initialChatMessage) {
      handleSendMessage(initialChatMessage);
      setInitialChatMessage(null); // Clear after sending
    }
  }, [initialChatMessage, handleSendMessage, setInitialChatMessage]);


  const handlePlayTTS = async (text: string) => {
    if (!isOnline) {
      alert("Text-to-speech is unavailable while offline.");
      return;
    }
    try {
        if (!aiRef.current) {
            aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
        }
        await generateSpeech(aiRef.current, text);
    } catch (error) {
        console.error('Error generating speech:', error);
        alert('Could not generate audio for this message.');
    }
  };

  const handleAcceptSuggestion = () => {
    if (suggestion?.itemName) {
      handleSendMessage(`Yes, please add the ${suggestion.itemName}.`);
    }
    setSuggestion(null);
  };


  return (
    <div className="flex flex-col h-[calc(100vh-80px)] md:flex-row">
      <div className="flex-1 flex flex-col relative bg-black">
        {isVideo(backgroundMediaUrl) ? (
          <video
            key={backgroundMediaUrl}
            className="absolute top-0 left-0 w-full h-full object-cover"
            src={backgroundMediaUrl}
            autoPlay
            loop
            muted
            playsInline
          />
        ) : (
          <img
            src={backgroundMediaUrl}
            className="absolute top-0 left-0 w-full h-full object-cover"
            alt="Restaurant background"
          />
        )}
        <div className="relative z-10 flex-1 flex flex-col bg-black bg-opacity-50 backdrop-blur-sm">
          <ChatWindow messages={messages} isLoading={isLoading} onPlayTTS={handlePlayTTS} />
          
          {suggestion && (
            <div className="px-4 pb-2 animate-slide-up-suggestion">
              <div className="bg-indigo-900/50 border border-indigo-700 rounded-lg p-3">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 text-indigo-400 pt-1">
                    <LightbulbIcon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-white text-sm">{suggestion.title}</h4>
                    <p className="text-indigo-200 text-xs mt-1">{suggestion.description}</p>
                  </div>
                </div>
                <div className="flex justify-end gap-2 mt-2">
                  <button onClick={() => setSuggestion(null)} className="px-3 py-1 text-xs text-indigo-200 hover:bg-white/10 rounded">
                    No, thanks
                  </button>
                  {suggestion.itemName && (
                    <button onClick={handleAcceptSuggestion} className="px-3 py-1 text-xs text-white bg-indigo-600 hover:bg-indigo-500 rounded font-semibold">
                      Add to Order
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          <div className="p-4 border-t border-gray-700">
            <div className="text-white text-sm mb-2 p-2 bg-black bg-opacity-30 rounded-md">
                {isRecording ? `I'm listening... ${transcript}` : (isOnline ? "Ready to take your order." : "Offline Mode: AI chat is unavailable.")}
            </div>
            <ChatInput 
              onSendMessage={handleSendMessage} 
              isRecording={isRecording}
              startRecording={startRecording}
              stopRecording={stopRecording}
              isLoading={isLoading}
              isOnline={isOnline}
            />
          </div>
        </div>
      </div>
      <div className="w-full md:w-80 bg-gray-50 dark:bg-gray-800 p-4 border-l border-gray-200 dark:border-gray-700 overflow-y-auto">
        <h2 className="text-lg font-semibold mb-4">Quick Tools</h2>
        {!isOnline && <p className="text-xs text-center text-red-500 mb-2 p-2 bg-red-100 dark:bg-red-900/50 rounded-md">AI tools are disabled while offline.</p>}
        <div className="space-y-3">
          <button onClick={() => handleSendMessage("Where are you located?", 'maps')} disabled={!isOnline} className="w-full flex items-center justify-center gap-2 text-white bg-blue-500 hover:bg-blue-600 font-medium rounded-lg text-sm px-5 py-2.5 text-center disabled:opacity-50 disabled:cursor-not-allowed">
            <MapIcon className="w-5 h-5"/> Find Us
          </button>
          <button onClick={() => handleSendMessage("What are today's specials?", 'search')} disabled={!isOnline} className="w-full flex items-center justify-center gap-2 text-white bg-red-500 hover:bg-red-600 font-medium rounded-lg text-sm px-5 py-2.5 text-center disabled:opacity-50 disabled:cursor-not-allowed">
            <SearchIcon className="w-5 h-5"/> Today's Specials
          </button>
          <button onClick={() => handleSendMessage("Plan a romantic vegan dinner for two under $50.", 'complex')} disabled={!isOnline} className="w-full flex items-center justify-center gap-2 text-white bg-purple-500 hover:bg-purple-600 font-medium rounded-lg text-sm px-5 py-2.5 text-center disabled:opacity-50 disabled:cursor-not-allowed">
            <BrainCircuitIcon className="w-5 h-5"/> Complex Order
          </button>
          <button onClick={() => setShowCreativeTools(true)} disabled={!isOnline} className="w-full flex items-center justify-center gap-2 text-white bg-teal-500 hover:bg-teal-600 font-medium rounded-lg text-sm px-5 py-2.5 text-center disabled:opacity-50 disabled:cursor-not-allowed">
            <ImagePlusIcon className="w-5 h-5"/> AI Creative Tools
          </button>
          <div className="text-center pt-4 border-t dark:border-gray-700 mt-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">Scan to chat on WhatsApp!</p>
            <img src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(whatsAppUrl)}`} alt="WhatsApp QR Code" className="mx-auto mt-2 rounded-lg" />
            <a 
              href={whatsAppUrl} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="mt-3 w-full flex items-center justify-center gap-2 text-white bg-green-500 hover:bg-green-600 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
            >
              <WhatsAppIcon className="w-5 h-5" /> Chat on WhatsApp
            </a>
          </div>
        </div>
      </div>
      {showCreativeTools && <AICreativeTools onClose={() => setShowCreativeTools(false)} isOnline={isOnline} />}
       <style>{`
        @keyframes slideUpSuggestion {
          from { transform: translateY(100%); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .animate-slide-up-suggestion { animation: slideUpSuggestion 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default CustomerView;