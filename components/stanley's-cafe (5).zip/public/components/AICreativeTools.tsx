


import React, { useState, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import { generateImage, editImage } from '../services/geminiService';
import { fileToBase64 } from '../utils/image';
import { CloseIcon, DownloadIcon, ImageIcon, SparklesIcon, UploadIcon } from './icons';

interface AICreativeToolsProps {
  onClose: () => void;
  isOnline: boolean;
}

export const AICreativeTools: React.FC<AICreativeToolsProps> = ({ onClose, isOnline }) => {
  const [activeTab, setActiveTab] = useState<'generate' | 'edit'>('generate');
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [originalImage, setOriginalImage] = useState<{ file: File; url: string } | null>(null);
  const [editedImageUrl, setEditedImageUrl] = useState<string | null>(null);
  const [editPrompt, setEditPrompt] = useState('');
  const aiRef = useRef<GoogleGenAI | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setIsLoading(true);
    setGeneratedImageUrl(null);
    try {
      if (!aiRef.current) aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const imageUrl = await generateImage(aiRef.current, prompt);
      setGeneratedImageUrl(imageUrl);
    } catch (error) {
      console.error("Image generation failed:", error);
      alert('Failed to generate image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setOriginalImage({ file, url: URL.createObjectURL(file) });
      setEditedImageUrl(null);
    }
  };
  
  const handleEdit = async () => {
    if (!originalImage || !editPrompt.trim()) return;
    setIsLoading(true);
    setEditedImageUrl(null);
    try {
        if (!aiRef.current) aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
        const base64Data = await fileToBase64(originalImage.file);
        const imageUrl = await editImage(aiRef.current, base64Data, originalImage.file.type, editPrompt);
        setEditedImageUrl(imageUrl);
    } catch (error) {
        console.error("Image editing failed:", error);
        alert('Failed to edit image. Please try again.');
    } finally {
        setIsLoading(false);
    }
  };

  const ImageDisplay: React.FC<{ url: string | null; loading: boolean; prompt: string; type: string }> = ({ url, loading, prompt, type}) => (
    <div className="w-full aspect-square bg-gray-200 dark:bg-gray-700 rounded-lg flex items-center justify-center relative overflow-hidden">
      {loading && (
        <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col items-center justify-center z-10">
          <SparklesIcon className="w-12 h-12 text-white animate-pulse" />
          <p className="text-white mt-2">AI is creating...</p>
        </div>
      )}
      {url ? (
        <>
            <img src={url} alt={prompt} className="w-full h-full object-contain" />
            <a href={url} download={`${type}_${prompt.slice(0,20)}.png`} className="absolute bottom-2 right-2 bg-blue-500 text-white p-2 rounded-full hover:bg-blue-600 transition-colors">
                <DownloadIcon className="w-5 h-5" />
            </a>
        </>
      ) : (
        <ImageIcon className="w-16 h-16 text-gray-400 dark:text-gray-500" />
      )}
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        <header className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-bold">AI Creative Tools</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800 dark:hover:text-white">
            <CloseIcon className="w-6 h-6" />
          </button>
        </header>
        
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          <aside className="w-full md:w-64 p-4 border-b md:border-r md:border-b-0 border-gray-200 dark:border-gray-700">
            <nav className="flex md:flex-col gap-2">
              <button onClick={() => setActiveTab('generate')} className={`w-full text-left p-2 rounded ${activeTab === 'generate' ? 'bg-indigo-500 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>Generate Image</button>
              <button onClick={() => setActiveTab('edit')} className={`w-full text-left p-2 rounded ${activeTab === 'edit' ? 'bg-indigo-500 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>Edit Image</button>
            </nav>
          </aside>

          <main className="flex-1 p-4 overflow-y-auto">
            {activeTab === 'generate' && (
              <div className="flex flex-col gap-4">
                <ImageDisplay url={generatedImageUrl} loading={isLoading} prompt={prompt} type="generated" />
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="e.g., A delicious-looking pizza on a rustic wooden table, photorealistic"
                  className="w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                  rows={3}
                  disabled={isLoading || !isOnline}
                />
                <button onClick={handleGenerate} disabled={isLoading || !prompt.trim() || !isOnline} className="w-full bg-indigo-500 text-white p-2 rounded hover:bg-indigo-600 disabled:bg-gray-400">
                  {isLoading ? 'Generating...' : 'Generate'}
                </button>
                {!isOnline && (
                  <p className="text-xs text-center text-red-500">Image generation is disabled while offline.</p>
                )}
              </div>
            )}
            
            {activeTab === 'edit' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex flex-col gap-4">
                         <div className="w-full aspect-square bg-gray-200 dark:bg-gray-700 rounded-lg flex items-center justify-center relative overflow-hidden">
                           {originalImage ? <img src={originalImage.url} alt="Original" className="w-full h-full object-contain" /> : <ImageIcon className="w-16 h-16 text-gray-400" />}
                         </div>
                        <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                        <button onClick={() => fileInputRef.current?.click()} className="w-full flex items-center justify-center gap-2 bg-gray-500 text-white p-2 rounded hover:bg-gray-600">
                           <UploadIcon className="w-5 h-5" /> {originalImage ? 'Change Image' : 'Upload Image'}
                        </button>
                    </div>
                     <div className="flex flex-col gap-4">
                        <ImageDisplay url={editedImageUrl} loading={isLoading} prompt={editPrompt} type="edited" />
                        <textarea
                          value={editPrompt}
                          onChange={(e) => setEditPrompt(e.target.value)}
                          placeholder="e.g., Add a retro filter, make it black and white"
                          className="w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                          rows={2}
                          disabled={isLoading || !originalImage || !isOnline}
                        />
                         <button onClick={handleEdit} disabled={isLoading || !originalImage || !editPrompt.trim() || !isOnline} className="w-full bg-indigo-500 text-white p-2 rounded hover:bg-indigo-600 disabled:bg-gray-400">
                            {isLoading ? 'Editing...' : 'Apply Edit'}
                        </button>
                        {!isOnline && (
                          <p className="text-xs text-center text-red-500">Image editing is disabled while offline.</p>
                        )}
                     </div>
                </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
};