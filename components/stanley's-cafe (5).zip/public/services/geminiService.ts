import { GoogleGenAI, GenerateContentResponse, Chat, Modality, Type } from '@google/genai';
import type { Message, GeolocationCoordinates, Suggestion, MenuItem } from '../types';
import { decode as base64Decode } from '../utils/audio';
import { decodeAudioData, audioBufferToWav } from '../utils/audio';

// Chat functionality using gemini-2.5-flash
export async function sendChatMessage(ai: GoogleGenAI, history: Message[], newMessage: string, systemPrompt: string): Promise<{ text: string }> {
  const chat: Chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    history: history.map(msg => ({
      role: msg.sender === 'user' ? 'user' : 'model',
      parts: [{ text: msg.text }]
    })),
    config: {
        systemInstruction: systemPrompt,
    }
  });
  const response: GenerateContentResponse = await chat.sendMessage({ message: newMessage });
  return { text: response.text };
}

// Search Grounding using gemini-2.5-flash
export async function askWithSearch(ai: GoogleGenAI, query: string): Promise<{ text: string; sources: { uri: string, title: string }[] }> {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: query,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });
  
  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
    ?.map((chunk) => ({
      uri: chunk.web?.uri || '',
      title: chunk.web?.title || '',
    }))
    .filter(source => source.uri) || [];

  return { text: response.text, sources };
}

// Maps Grounding using gemini-2.5-flash
export async function askWithMaps(ai: GoogleGenAI, query: string, location: GeolocationCoordinates): Promise<{ text: string; sources: { uri: string, title: string }[] }> {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: query,
        config: {
            tools: [{ googleMaps: {} }],
            toolConfig: {
                retrievalConfig: {
                    latLng: {
                        latitude: location.latitude,
                        longitude: location.longitude,
                    }
                }
            }
        },
    });

    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
    ?.map((chunk) => ({
      uri: chunk.maps?.uri || '',
      title: chunk.maps?.title || '',
    }))
    .filter(source => source.uri) || [];

    return { text: response.text, sources };
}

// Complex queries with Thinking Mode using gemini-2.5-pro
export async function handleComplexQuery(ai: GoogleGenAI, query: string): Promise<{ text: string }> {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-pro",
    contents: query,
    config: {
      thinkingConfig: { thinkingBudget: 32768 },
      systemInstruction: "You are 'Stan', the expert meal planner at Stanley's Cafe. Your persona is that of a passionate chef. When a user has a complex request (like planning a dinner for a special occasion), put on your chef's hat! Create a detailed, thoughtful meal plan from our menu, explaining your choices with flair and enthusiasm. Make it sound delicious and special."
    },
  });
  return { text: response.text };
}

// Image Generation using imagen-4.0-generate-001
export async function generateImage(ai: GoogleGenAI, prompt: string): Promise<string> {
    const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
            numberOfImages: 1,
            outputMimeType: 'image/jpeg',
            aspectRatio: '1:1',
        },
    });

    const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
    return `data:image/jpeg;base64,${base64ImageBytes}`;
}

// Image Editing using gemini-2.5-flash-image
export async function editImage(ai: GoogleGenAI, base64ImageData: string, mimeType: string, prompt: string): Promise<string> {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
            parts: [
                {
                    inlineData: {
                        data: base64ImageData,
                        mimeType: mimeType,
                    },
                },
                {
                    text: prompt,
                },
            ],
        },
        config: {
            responseModalities: [Modality.IMAGE],
        },
    });
    
    for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
            const base64ImageBytes: string = part.inlineData.data;
            return `data:${part.inlineData.mimeType};base64,${base64ImageBytes}`;
        }
    }
    throw new Error("No image was returned from the API.");
}

// Speech Generation (plays audio directly)
export async function generateSpeech(ai: GoogleGenAI, text: string): Promise<void> {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: text }] }],
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: 'Kore' },
                },
            },
        },
    });

    // @ts-ignore
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) {
        throw new Error("Web Audio API is not supported in this browser.");
    }
    const outputAudioContext = new AudioContext({ sampleRate: 24000 });
    const outputNode = outputAudioContext.createGain();
    outputNode.connect(outputAudioContext.destination);

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
        const decodedBytes = base64Decode(base64Audio);
        const audioBuffer = await decodeAudioData(
            decodedBytes,
            outputAudioContext,
            24000,
            1,
        );
        const source = outputAudioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(outputNode);
        source.start();
    } else {
        throw new Error("No audio data received from API.");
    }
}


// Speech Generation (returns playable blob URL)
export async function generateSpeechAudioUrl(ai: GoogleGenAI, text: string): Promise<string> {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Say with a friendly and engaging tone: ${text}` }] }],
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
            },
        },
    });
    
    // @ts-ignore
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) throw new Error("Web Audio API is not supported.");
    
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) throw new Error("No audio data received.");

    const audioContext = new AudioContext({ sampleRate: 24000 });
    const decodedBytes = base64Decode(base64Audio);
    const audioBuffer = await decodeAudioData(decodedBytes, audioContext, 24000, 1);
    const wavBlob = audioBufferToWav(audioBuffer);
    
    return URL.createObjectURL(wavBlob);
}

// Video Generation using veo-3.1-fast-generate-preview
export async function generateVideo(
    ai: GoogleGenAI, 
    prompt: string, 
    onStatusUpdate: (message: string) => void
): Promise<string> {
    onStatusUpdate("Initializing video generation...");
    let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio: '16:9'
        }
    });

    onStatusUpdate("Video request sent. Waiting for processing to start...");
    let pollCount = 0;
    while (!operation.done) {
        pollCount++;
        const waitTime = Math.min(10000 + pollCount * 2000, 30000); // Exponential backoff with a cap
        onStatusUpdate(`Processing... (checking status again in ${waitTime / 1000}s)`);
        await new Promise(resolve => setTimeout(resolve, waitTime));
        operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    onStatusUpdate("Video processing complete! Fetching video data...");
    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) {
        throw new Error("Video generation finished, but no download link was provided.");
    }

    const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    if (!response.ok) {
        const errorBody = await response.json();
        if (errorBody?.error?.message.includes("Requested entity was not found")) {
            throw new Error("Requested entity was not found. Your API key may be invalid or lack permissions for this model.");
        }
        throw new Error(`Failed to download video: ${response.statusText}`);
    }
    const videoBlob = await response.blob();
    onStatusUpdate("Video downloaded successfully!");
    return URL.createObjectURL(videoBlob);
}

// AI Music Generation (Simulated)
// NOTE: This is a placeholder function. The Gemini API does not currently support direct text-to-music generation.
// This function simulates the API call to demonstrate the UI/UX flow.
export async function generateMusic(
    ai: GoogleGenAI, 
    prompt: string, 
    onStatusUpdate: (message: string) => void
): Promise<string> {
    onStatusUpdate("Warming up the synthesizers...");
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    onStatusUpdate("Composing melody based on your prompt...");
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    onStatusUpdate("Mixing and mastering the track...");
    await new Promise(resolve => setTimeout(resolve, 2500));

    // In a real implementation, an API call would be made here.
    // We are returning a royalty-free placeholder track.
    // Music: "Lofi Chill" from Pixabay
    const placeholderMusicUrl = "https://cdn.pixabay.com/audio/2022/02/07/audio_6240212df5.mp3";
    
    onStatusUpdate("Music generation complete!");
    return placeholderMusicUrl;
}

// Geocoding using gemini-2.5-flash
export async function geocodeAddress(ai: GoogleGenAI, address: string): Promise<GeolocationCoordinates> {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `Provide the geographic coordinates (latitude and longitude) for the following address: ${address}.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          latitude: { type: Type.NUMBER, description: 'The latitude of the address.' },
          longitude: { type: Type.NUMBER, description: 'The longitude of the address.' },
        },
        required: ['latitude', 'longitude'],
      },
    },
  });

  const jsonStr = response.text.trim();
  const result = JSON.parse(jsonStr);
  
  if (typeof result.latitude !== 'number' || typeof result.longitude !== 'number') {
    throw new Error("Invalid coordinates received from API.");
  }
  
  return {
    latitude: result.latitude,
    longitude: result.longitude,
  };
}

// Function to get contextual suggestions
export async function getSuggestions(ai: GoogleGenAI, history: Message[], suggestionsEnabled: boolean, menuItems: MenuItem[]): Promise<Suggestion | null> {
  // Only try to get suggestions if there's some conversation history and feature is enabled
  if (!suggestionsEnabled || history.length < 2) {
    return null;
  }

  const conversationHistory = history.map(msg => `${msg.sender}: ${msg.text}`).join('\n');
  const menuString = menuItems.map(item => `- ${item.name} (${item.price})`).join('\n');

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Based on the following conversation, suggest ONE complementary item or special offer.
      
      MENU:
      ${menuString}

      CONVERSATION:
      ${conversationHistory}
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: 'A short, catchy title for the suggestion. e.g., "Goes great with..."' },
            description: { type: Type.STRING, description: 'A brief, friendly description of the offer or item.' },
            itemName: { type: Type.STRING, description: 'The exact name of the menu item being suggested, if applicable.' },
          },
          required: ['title', 'description'],
        },
      },
    });

    const jsonStr = response.text.trim();
    if (!jsonStr) return null;
    
    const result = JSON.parse(jsonStr);

    // Basic validation
    if (result && typeof result.title === 'string' && typeof result.description === 'string') {
        // Ensure itemName exists in menu if provided
        if (result.itemName && !menuItems.some(item => item.name === result.itemName)) {
            return null; // Don't suggest items not on the menu
        }
      return result as Suggestion;
    }
    return null;
  } catch (error) {
    console.error("Error getting suggestions:", error);
    return null;
  }
}