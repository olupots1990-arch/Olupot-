// A simple, offline-first service worker
const CACHE_NAME = 'stanleys-cafe-cache-v2';
const urlsToCache = [
  '/',
  '/index.html',
  '/index.tsx',
  '/manifest.json',
  '/favicon.svg',
  // Core Dependencies
  'https://cdn.tailwindcss.com',
  'https://aistudiocdn.com/react@^19.2.0',
  'https://aistudiocdn.com/react-dom@^19.2.0/',
  'https://aistudiocdn.com/@google/genai@^1.29.0',
  // App-specific assets
  'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/thumbnail.png',
  'https://videos.pexels.com/video-files/3209828/3209828-hd_1920_1080_25fps.mp4',
  'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/margherita.jpg',
  'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/pepperoni.jpg',
  'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/spaghetti.jpg',
  'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/salad.jpg',
  'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/garlic-bread.jpg',
  'https://storage.googleapis.com/maker-suite-public-codelab-assets/gen_app_builder_101/pizzas/tiramisu.jpg'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', (event) => {
  // Ignore non-GET requests for caching (e.g., API calls).
  if (event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Cache hit - return response
        if (response) {
          return response;
        }

        // Clone the request because it's a stream and can only be consumed once.
        const fetchRequest = event.request.clone();

        return fetch(fetchRequest).then(
          (response) => {
            // Check if we received a valid response
            if (!response || response.status !== 200 || !['basic', 'cors'].includes(response.type)) {
              return response;
            }

            // Clone the response because it's a stream and can only be consumed once.
            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });

            return response;
          }
        );
      })
    );
});
