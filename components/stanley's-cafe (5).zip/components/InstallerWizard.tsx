import React, { useState } from 'react';
import WelcomeStep from './WelcomeStep';
import LicenseStep from './LicenseStep';
import PathStep from './PathStep';
import ProgressStep from './ProgressStep';
import FinishStep from './FinishStep';
import { ShieldCheckIcon } from './icons';

type Step = 'welcome' | 'license' | 'path' | 'progress' | 'finish';

interface InstallerWizardProps {
    onInstallComplete: () => void;
}

const InstallerWizard: React.FC<InstallerWizardProps> = ({ onInstallComplete }) => {
    const [step, setStep] = useState<Step>('welcome');
    const [licenseAccepted, setLicenseAccepted] = useState(false);
    const [installPath, setInstallPath] = useState("C:\\Program Files\\Stanley's Cafe");

    const nextStepMap: Record<Step, Step> = {
        welcome: 'license',
        license: 'path',
        path: 'progress',
        progress: 'finish',
        finish: 'finish',
    };

    const prevStepMap: Record<Step, Step> = {
        welcome: 'welcome',
        license: 'welcome',
        path: 'license',
        progress: 'path',
        finish: 'progress',
    };

    const handleNext = () => {
        if (step in nextStepMap) {
            setStep(nextStepMap[step]);
        }
    };
    
    const handleBack = () => {
        if (step in prevStepMap) {
            setStep(prevStepMap[step]);
        }
    };

    const handleCancel = () => {
        if (window.confirm("Are you sure you want to cancel the setup?")) {
            setStep('welcome');
            setLicenseAccepted(false);
        }
    };

    const renderStep = () => {
        switch (step) {
            case 'welcome':
                return <WelcomeStep />;
            case 'license':
                return <LicenseStep licenseAccepted={licenseAccepted} onAcceptChange={setLicenseAccepted} />;
            case 'path':
                return <PathStep installPath={installPath} onPathChange={setInstallPath} />;
            case 'progress':
                return <ProgressStep onInstallComplete={() => setStep('finish')} />;
            case 'finish':
                return <FinishStep />;
            default:
                return null;
        }
    };

    const isNextDisabled = () => {
        if (step === 'license' && !licenseAccepted) return true;
        if (step === 'progress' || step === 'finish') return true;
        return false;
    };
    
    const isBackDisabled = step === 'welcome' || step === 'progress' || step === 'finish';

    return (
        <div className="w-full max-w-2xl bg-white dark:bg-gray-800 shadow-2xl rounded-lg flex flex-col h-[500px]">
            <header className="p-4 border-b border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-2">
                    <ShieldCheckIcon className="w-6 h-6 text-indigo-500" />
                    <h1 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Stanley's Cafe Setup</h1>
                </div>
            </header>

            <main className="flex-1 p-6 overflow-y-auto bg-gray-50 dark:bg-gray-800/50">
                {renderStep()}
            </main>

            <footer className="flex justify-end items-center space-x-3 p-4 bg-gray-100 dark:bg-gray-700/50 border-t border-gray-200 dark:border-gray-700 rounded-b-lg">
                <button
                    onClick={handleBack}
                    disabled={isBackDisabled}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    &lt; Back
                </button>
                {step !== 'finish' ? (
                    <button
                        onClick={handleNext}
                        disabled={isNextDisabled()}
                        className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed"
                    >
                        {step === 'path' ? 'Install' : 'Next >'}
                    </button>
                ) : (
                    <button
                        onClick={onInstallComplete}
                        className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700"
                    >
                        Finish
                    </button>
                )}
                 <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>
                <button
                    onClick={step === 'finish' ? onInstallComplete : handleCancel}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600"
                >
                    {step === 'finish' ? 'Close' : 'Cancel'}
                </button>
            </footer>
        </div>
    );
};

export default InstallerWizard;
