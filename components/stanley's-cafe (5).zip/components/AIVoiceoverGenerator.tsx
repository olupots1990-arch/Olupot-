import React, { useState, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import { generateSpeechAudioUrl } from '../services/geminiService';
import { CloseIcon, SparklesIcon, CheckCircleIcon } from './icons';

interface AIVoiceoverGeneratorProps {
    onClose: () => void;
    onVoiceoverGenerated: (url: string, script: string) => void;
}

const AIVoiceoverGenerator: React.FC<AIVoiceoverGeneratorProps> = ({ onClose, onVoiceoverGenerated }) => {
    const [script, setScript] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [statusMessage, setStatusMessage] = useState('');
    const [generatedAudioUrl, setGeneratedAudioUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const aiRef = useRef<GoogleGenAI | null>(null);

    const handleGenerate = async () => {
        if (!script.trim()) {
            setError("Script cannot be empty.");
            return;
        }

        setIsLoading(true);
        setError(null);
        setGeneratedAudioUrl(null);
        setStatusMessage("Initializing audio generation...");

        try {
            if (!aiRef.current) {
                aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            }
            setStatusMessage("Generating voiceover...");
            const audioUrl = await generateSpeechAudioUrl(aiRef.current, script);
            setGeneratedAudioUrl(audioUrl);
            setStatusMessage("Generation complete! Preview below.");
        } catch (e: any) {
            console.error("Voiceover generation failed:", e);
            const errorMessage = e.message || "An unknown error occurred.";
            setError(`Generation failed: ${errorMessage}`);
            setStatusMessage("An error occurred during voiceover generation.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleAddVoiceover = () => {
        if (generatedAudioUrl) {
            onVoiceoverGenerated(generatedAudioUrl, script);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-[60] p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700">
                    <h2 className="text-xl font-bold">AI Voiceover Generator</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800 dark:hover:text-white">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </header>

                <main className="flex-1 p-6 overflow-y-auto space-y-4">
                    <div>
                        <label htmlFor="voiceover-script" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Voiceover Script</label>
                        <textarea
                            id="voiceover-script"
                            rows={4}
                            value={script}
                            onChange={e => setScript(e.target.value)}
                            placeholder="e.g., Welcome to Stanley's Cafe, where every dish tells a story..."
                            className="mt-1 w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                            disabled={isLoading}
                        />
                    </div>

                    <div className="min-h-[6rem] bg-gray-100 dark:bg-gray-900 rounded-lg flex items-center justify-center p-4">
                        {isLoading ? (
                            <div className="text-center">
                                <SparklesIcon className="w-8 h-8 text-indigo-500 animate-pulse mx-auto" />
                                <p className="mt-2 text-sm text-gray-600 dark:text-gray-300 font-medium">{statusMessage}</p>
                            </div>
                        ) : generatedAudioUrl ? (
                            <audio src={generatedAudioUrl} controls className="w-full" />
                        ) : error ? (
                             <p className="text-red-500 text-sm text-center">{error}</p>
                        ) : (
                            <p className="text-gray-500">Your generated audio will appear here for preview.</p>
                        )}
                    </div>
                </main>

                <footer className="flex justify-end items-center space-x-3 p-4 bg-gray-50 dark:bg-gray-700/50 border-t border-gray-200 dark:border-gray-700">
                    <button
                        onClick={onClose}
                        className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600"
                    >
                        Cancel
                    </button>
                    {generatedAudioUrl && !isLoading ? (
                         <button
                            onClick={handleAddVoiceover}
                            className="px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 flex items-center gap-2"
                        >
                           <CheckCircleIcon className="w-5 h-5"/> Add Voiceover
                        </button>
                    ) : (
                         <button
                            onClick={handleGenerate}
                            disabled={isLoading || !script.trim()}
                            className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                            <SparklesIcon className="w-5 h-5"/> {isLoading ? 'Generating...' : 'Generate'}
                        </button>
                    )}
                </footer>
            </div>
        </div>
    );
};

export default AIVoiceoverGenerator;