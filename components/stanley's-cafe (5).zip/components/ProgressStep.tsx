import React, { useState, useEffect } from 'react';
import { CogIcon } from './icons';

interface ProgressStepProps {
    onInstallComplete: () => void;
}

const mockLogs = [
    'Initializing setup...',
    'Extracting files: stanley-core.dll',
    'Extracting files: order-online.exe',
    'Copying new files...',
    'Creating program group...',
    'Registering components: menu-cache.dll',
    'Creating shortcuts on desktop...',
    'Writing uninstall information to registry...',
    'Finalizing installation...',
    'Installation complete!',
];

const ProgressStep: React.FC<ProgressStepProps> = ({ onInstallComplete }) => {
    const [progress, setProgress] = useState(0);
    const [log, setLog] = useState('Preparing to install...');

    useEffect(() => {
        const interval = setInterval(() => {
            setProgress(prev => {
                const newProgress = prev + Math.random() * 5;
                if (newProgress >= 100) {
                    clearInterval(interval);
                    setLog('Installation complete!');
                    setTimeout(onInstallComplete, 1000); 
                    return 100;
                }
                
                const logIndex = Math.floor((newProgress / 100) * (mockLogs.length - 1));
                setLog(mockLogs[logIndex]);
                
                return newProgress;
            });
        }, 250);

        return () => clearInterval(interval);
    }, [onInstallComplete]);

    return (
        <div className="flex flex-col justify-center h-full">
            <div className="flex items-center space-x-3 mb-4">
                <CogIcon className="w-6 h-6 text-indigo-500 animate-spin" />
                <h2 className="text-xl font-semibold">Installing...</h2>
            </div>
            <p className="mb-2 text-sm text-gray-600 dark:text-gray-400">
                Please wait while Stanley's Cafe is being installed. This may take several moments.
            </p>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-4 my-2 overflow-hidden">
                <div 
                    className="bg-indigo-600 h-4 rounded-full transition-all duration-300 ease-linear" 
                    style={{ width: `${progress}%` }}
                ></div>
            </div>
            <p className="mt-2 text-xs text-gray-500 dark:text-gray-400 h-4 truncate">
                {log}
            </p>
        </div>
    );
};

export default ProgressStep;
