import React, { useState, useEffect } from 'react';
import type { MenuItem } from '../types';
import { CloseIcon } from './icons';

interface MenuItemFormModalProps {
    item: MenuItem | null;
    onSave: (itemData: Omit<MenuItem, 'id'>) => void;
    onClose: () => void;
}

const MenuItemFormModal: React.FC<MenuItemFormModalProps> = ({ item, onSave, onClose }) => {
    const [formData, setFormData] = useState({
        name: '',
        price: '',
        imageUrl: '',
    });

    useEffect(() => {
        if (item) {
            setFormData({
                name: item.name,
                price: item.price.toString(),
                imageUrl: item.imageUrl,
            });
        }
    }, [item]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            name: formData.name,
            price: parseFloat(formData.price) || 0,
            imageUrl: formData.imageUrl,
        });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">{item ? 'Edit Menu Item' : 'Add New Menu Item'}</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </header>
                <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium">Item Name</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                     <div>
                        <label htmlFor="price" className="block text-sm font-medium">Price</label>
                        <input type="number" name="price" id="price" value={formData.price} onChange={handleChange} required min="0" step="0.01" className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                     <div>
                        <label htmlFor="imageUrl" className="block text-sm font-medium">Image URL</label>
                        <input type="url" name="imageUrl" id="imageUrl" value={formData.imageUrl} onChange={handleChange} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <footer className="flex justify-end gap-3 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 rounded-md">Cancel</button>
                        <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save Item</button>
                    </footer>
                </form>
            </div>
        </div>
    );
};

export default MenuItemFormModal;
