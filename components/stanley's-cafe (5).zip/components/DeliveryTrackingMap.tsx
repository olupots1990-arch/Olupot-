import React, { useState, useEffect } from 'react';
import type { Order, DeliveryAgent } from '../types';
import { TruckIcon } from './icons';

interface DeliveryTrackingMapProps {
    orders: Order[];
    agents: DeliveryAgent[];
}

const DeliveryTrackingMap: React.FC<DeliveryTrackingMapProps> = ({ orders, agents }) => {
    // Mock positions - in a real app, this would come from a live data source
    const [positions, setPositions] = useState<Record<string, { top: number; left: number }>>({});
    const [highlightedAgentId, setHighlightedAgentId] = useState<string | null>(null);

    useEffect(() => {
        const initialPositions: Record<string, { top: number; left: number }> = {};
        orders.forEach(order => {
            if (order.deliveryAgentId) {
                initialPositions[order.deliveryAgentId] = {
                    top: Math.random() * 80 + 10,
                    left: Math.random() * 80 + 10,
                };
            }
        });
        setPositions(initialPositions);

        const interval = setInterval(() => {
            setPositions(prev => {
                const newPositions = { ...prev };
                Object.keys(newPositions).forEach(key => {
                    newPositions[key] = {
                        top: Math.max(0, Math.min(100, newPositions[key].top + (Math.random() - 0.5) * 2)),
                        left: Math.max(0, Math.min(100, newPositions[key].left + (Math.random() - 0.5) * 2)),
                    };
                });
                return newPositions;
            });
        }, 2000);

        return () => clearInterval(interval);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [orders]);


    return (
        <div className="flex flex-col md:flex-row gap-6 h-[calc(100vh-170px)]">
            <div className="md:w-2/3 h-full bg-gray-200 dark:bg-gray-700 rounded-lg shadow-inner relative overflow-hidden">
                {/* Mock Map Background */}
                <div className="absolute inset-0 bg-map-pattern opacity-20"></div>
                <style>{`.bg-map-pattern { background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%239C92AC' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E"); }`}</style>
                
                 {orders.map(order => {
                    const agent = agents.find(a => a.id === order.deliveryAgentId);
                    const pos = agent ? positions[agent.id] : null;
                    if (!agent || !pos) return null;

                    return (
                        <div 
                            key={agent.id} 
                            className={`absolute transition-all duration-1000 ease-linear ${highlightedAgentId === agent.id ? 'z-10' : ''}`}
                            style={{ top: `${pos.top}%`, left: `${pos.left}%`, transform: 'translate(-50%, -50%)' }}
                        >
                            <div className="relative group">
                                <TruckIcon className={`w-8 h-8 text-indigo-500 transition-transform duration-300 ${highlightedAgentId === agent.id ? 'scale-150' : ''}`} />
                                <div className="absolute bottom-full mb-2 w-48 bg-white dark:bg-gray-800 p-2 rounded-md shadow-lg text-xs opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                    <p className="font-bold">{agent.name}</p>
                                    <p>Order: {order.id}</p>
                                    <p>To: {order.customerName}</p>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
            <div className="md:w-1/3 h-full bg-white dark:bg-gray-800 p-4 rounded-lg shadow-lg overflow-y-auto">
                <h3 className="text-xl font-bold mb-4">Active Deliveries</h3>
                <ul className="space-y-3">
                    {orders.length === 0 && <p className="text-gray-500">No active deliveries.</p>}
                    {orders.map(order => {
                        const agent = agents.find(a => a.id === order.deliveryAgentId);
                        if (!agent) return null;
                        return (
                             <li 
                                key={order.id} 
                                className="p-3 bg-gray-50 dark:bg-gray-700 rounded-md cursor-pointer transition-all duration-200 hover:shadow-md hover:bg-indigo-50 dark:hover:bg-indigo-900/40"
                                onMouseEnter={() => setHighlightedAgentId(agent.id)}
                                onMouseLeave={() => setHighlightedAgentId(null)}
                             >
                                <p className="font-semibold text-gray-800 dark:text-white">Order: {order.id}</p>
                                <p className="text-sm text-gray-600 dark:text-gray-300">Agent: {agent.name}</p>
                                <p className="text-sm text-gray-600 dark:text-gray-300">Customer: {order.customerName}</p>
                            </li>
                        )
                    })}
                </ul>
            </div>
        </div>
    );
};

export default DeliveryTrackingMap;