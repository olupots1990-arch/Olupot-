import React from 'react';
import { PhoneIcon, MapIcon, CalendarIcon } from './icons';
import { LocationInfo } from '../types';

interface ContactPageProps {
    location: LocationInfo;
}

const ContactPage: React.FC<ContactPageProps> = ({ location }) => {
    const addressLines = location.address.split(',').map(line => line.trim());

    return (
        <div className="h-full bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 flex items-center justify-center">
            <div className="max-w-2xl mx-auto p-8 text-center">
                <h1 className="text-4xl font-bold text-indigo-600 dark:text-indigo-400">Contact Us</h1>
                <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
                    We'd love to hear from you! Whether you have a question about our menu, a suggestion, or just want to say hello, feel free to reach out.
                </p>

                <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
                    <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                            <div className="flex items-center justify-center h-12 w-12 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400">
                                <MapIcon className="w-6 h-6" />
                            </div>
                        </div>
                        <div>
                            <h3 className="text-lg font-semibold">Our Address</h3>
                            <p className="mt-1 text-gray-600 dark:text-gray-400">
                                {addressLines.map((line, index) => (
                                    <React.Fragment key={index}>
                                        {line}
                                        <br />
                                    </React.Fragment>
                                ))}
                            </p>
                        </div>
                    </div>

                    <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                            <div className="flex items-center justify-center h-12 w-12 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400">
                                <PhoneIcon className="w-6 h-6" />
                            </div>
                        </div>
                        <div>
                            <h3 className="text-lg font-semibold">Call Us</h3>
                            <p className="mt-1 text-gray-600 dark:text-gray-400">
                                Have a question or want to place an order over the phone?
                            </p>
                            <a href="tel:+356772715106" className="font-semibold text-indigo-600 dark:text-indigo-400 hover:underline">
                                +356 772715106
                            </a>
                        </div>
                    </div>

                    <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                            <div className="flex items-center justify-center h-12 w-12 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400">
                                <CalendarIcon className="w-6 h-6" />
                            </div>
                        </div>
                        <div>
                            <h3 className="text-lg font-semibold">Opening Hours</h3>
                            <p className="mt-1 text-gray-600 dark:text-gray-400">
                                <strong>Mon - Fri:</strong> 11:00 AM - 10:00 PM<br/>
                                <strong>Sat - Sun:</strong> 10:00 AM - 11:00 PM
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ContactPage;