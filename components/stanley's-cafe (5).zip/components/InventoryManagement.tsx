import React, { useState, useMemo } from 'react';
import type { InventoryItem, Employee, InventoryLogEntry } from '../types';
import { PlusCircleIcon, EditIcon, TrashIcon, CloseIcon, AlertTriangleIcon } from './icons';

const InventoryFormModal: React.FC<{
    item: Omit<InventoryItem, 'id' | 'assignedTo'> | null;
    onSave: (item: Omit<InventoryItem, 'id' | 'assignedTo'>) => void;
    onClose: () => void;
}> = ({ item, onSave, onClose }) => {
    const [formData, setFormData] = useState({
        name: item?.name || '',
        category: item?.category || '',
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">{item ? 'Edit Inventory Item' : 'Add New Item'}</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </header>
                <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium">Item Name</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required placeholder="e.g., Chef Jacket - L" className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <div>
                        <label htmlFor="category" className="block text-sm font-medium">Category</label>
                        <input type="text" name="category" id="category" value={formData.category} onChange={handleChange} required placeholder="e.g., Uniform" className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <footer className="flex justify-end gap-3 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 rounded-md">Cancel</button>
                        <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save Item</button>
                    </footer>
                </form>
            </div>
        </div>
    );
};


const InventoryManagement: React.FC<{
    inventory: InventoryItem[];
    setInventory: React.Dispatch<React.SetStateAction<InventoryItem[]>>;
    employees: Employee[];
    inventoryLogs: InventoryLogEntry[];
}> = ({ inventory, setInventory, employees, inventoryLogs }) => {
    const [view, setView] = useState<'list' | 'history'>('list');
    const [historyFilter, setHistoryFilter] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
    const [itemToDelete, setItemToDelete] = useState<InventoryItem | null>(null);

    const employeeMap = useMemo(() => new Map(employees.map(e => [e.id, e.name])), [employees]);
    const itemMap = useMemo(() => new Map(inventory.map(i => [i.id, i.name])), [inventory]);

    const filteredLogs = useMemo(() => {
        return inventoryLogs
            .filter(log => {
                const itemName = itemMap.get(log.itemId) || '';
                return itemName.toLowerCase().includes(historyFilter.toLowerCase());
            })
            .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    }, [inventoryLogs, historyFilter, itemMap]);

    const handleSave = (data: Omit<InventoryItem, 'id' | 'assignedTo'>) => {
        if (editingItem) {
            setInventory(prev => prev.map(i => i.id === editingItem.id ? { ...editingItem, ...data } : i));
        } else {
            const newItem: InventoryItem = { ...data, id: `inv-${Date.now()}`, assignedTo: null };
            setInventory(prev => [newItem, ...prev]);
        }
        setIsModalOpen(false);
        setEditingItem(null);
    };

    const handleDelete = () => {
        if (itemToDelete) {
            setInventory(prev => prev.filter(i => i.id !== itemToDelete.id));
            setItemToDelete(null);
        }
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-2">
                    <button onClick={() => setView('list')} className={`px-3 py-1 text-sm font-medium rounded ${view === 'list' ? 'bg-indigo-500 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>Item List</button>
                    <button onClick={() => setView('history')} className={`px-3 py-1 text-sm font-medium rounded ${view === 'history' ? 'bg-indigo-500 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>Assignment History</button>
                </div>
                {view === 'list' && (
                     <button
                        onClick={() => { setEditingItem(null); setIsModalOpen(true); }}
                        className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg shadow-sm hover:bg-green-700"
                    >
                        <PlusCircleIcon className="w-5 h-5" />
                        Add Item
                    </button>
                )}
            </div>
            
            {view === 'list' && (
                <>
                    <h2 className="text-2xl font-bold mb-4">Manage Inventory</h2>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <tr>
                                    <th scope="col" className="px-6 py-3">Item Name</th>
                                    <th scope="col" className="px-6 py-3">Category</th>
                                    <th scope="col" className="px-6 py-3">Status</th>
                                    <th scope="col" className="px-6 py-3">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {inventory.map(item => (
                                    <tr key={item.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                        <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">{item.name}</td>
                                        <td className="px-6 py-4">{item.category}</td>
                                        <td className="px-6 py-4">
                                            {item.assignedTo ? (
                                                <span className="px-2 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                                                    Assigned to {employeeMap.get(item.assignedTo) || 'Unknown'}
                                                </span>
                                            ) : (
                                                <span className="px-2 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                                                    Available
                                                </span>
                                            )}
                                        </td>
                                        <td className="px-6 py-4 flex items-center space-x-3">
                                            <button onClick={() => { setEditingItem(item); setIsModalOpen(true); }} className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-800"><EditIcon className="w-5 h-5" /></button>
                                            <button onClick={() => setItemToDelete(item)} className="text-red-600 dark:text-red-400 hover:text-red-800"><TrashIcon className="w-5 h-5" /></button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </>
            )}

            {view === 'history' && (
                <div>
                    <h2 className="text-2xl font-bold mb-4">Assignment History</h2>
                    <input 
                        type="text"
                        placeholder="Filter by item name..."
                        value={historyFilter}
                        onChange={e => setHistoryFilter(e.target.value)}
                        className="w-full p-2 mb-4 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                    />
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                           <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <tr>
                                    <th scope="col" className="px-6 py-3">Date</th>
                                    <th scope="col" className="px-6 py-3">Item</th>
                                    <th scope="col" className="px-6 py-3">Action</th>
                                    <th scope="col" className="px-6 py-3">Employee</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredLogs.map(log => (
                                    <tr key={log.id} className="border-b dark:border-gray-700">
                                        <td className="px-6 py-4 whitespace-nowrap">{log.timestamp.toLocaleString()}</td>
                                        <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">{itemMap.get(log.itemId) || 'Unknown Item'}</td>
                                        <td className="px-6 py-4">
                                            <span className={`px-2 py-1 rounded-full text-xs font-semibold capitalize ${
                                                log.action === 'assigned' 
                                                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' 
                                                : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                                            }`}>
                                                {log.action}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4">{employeeMap.get(log.employeeId) || 'Unknown Employee'}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        {filteredLogs.length === 0 && (
                            <div className="text-center py-10">
                                <p className="text-gray-500 dark:text-gray-400">No history records found.</p>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {isModalOpen && <InventoryFormModal item={editingItem} onSave={handleSave} onClose={() => { setIsModalOpen(false); setEditingItem(null); }} />}
            
            {itemToDelete && (
                 <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60] p-4">
                    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
                        <div className="p-6 text-center">
                            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 dark:bg-red-900/50">
                                <AlertTriangleIcon className="h-6 w-6 text-red-600 dark:text-red-300" />
                            </div>
                            <h3 className="mt-5 text-lg font-medium text-gray-900 dark:text-white">Delete Item</h3>
                            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                                Are you sure you want to delete <span className="font-semibold">{itemToDelete.name}</span>?
                                {itemToDelete.assignedTo && ' It is currently assigned and will be removed from the employee.'}
                                This action is irreversible.
                            </p>
                        </div>
                        <div className="flex justify-center gap-3 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-b-lg">
                            <button onClick={() => setItemToDelete(null)} className="px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600">Cancel</button>
                            <button onClick={handleDelete} className="px-4 py-2 text-white bg-red-600 rounded-md hover:bg-red-700">Delete</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default InventoryManagement;