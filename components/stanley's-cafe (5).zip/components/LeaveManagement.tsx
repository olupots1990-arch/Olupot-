import React, { useState, useMemo, useRef } from 'react';
import type { DeliveryAgent, LeaveRequest, Employee } from '../types';
import { CheckCircleIcon, ChevronLeftIcon, ChevronRightIcon, XCircleIcon, ArrowUpIcon, ArrowDownIcon, CloseIcon, PrintIcon, UserPlusIcon, EditIcon, TrashIcon, AlertTriangleIcon } from './icons';

interface LeaveManagementProps {
    agents: DeliveryAgent[];
    setAgents: React.Dispatch<React.SetStateAction<DeliveryAgent[]>>;
    employees: Employee[];
    setEmployees: React.Dispatch<React.SetStateAction<Employee[]>>;
    leaveRequests: LeaveRequest[];
    setLeaveRequests: React.Dispatch<React.SetStateAction<LeaveRequest[]>>;
}

const statusColors = {
    available: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    'on-delivery': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    offline: 'bg-gray-200 text-gray-800 dark:bg-gray-600 dark:text-gray-200',
    'on-leave': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
};

const attendanceColors = {
    present: 'bg-green-500 text-white',
    absent: 'bg-red-500 text-white',
    'on-leave': 'bg-yellow-500 text-white',
};

const AgentFormModal: React.FC<{
    agent: DeliveryAgent | null;
    onSave: (data: Omit<DeliveryAgent, 'id' | 'status' | 'attendance'> & { commissionRate?: number }) => void;
    onClose: () => void;
}> = ({ agent, onSave, onClose }) => {
    const [formData, setFormData] = useState({
        name: agent?.name || '',
        phone: agent?.phone || '',
        commissionRate: agent?.commissionRate ?? '',
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            name: formData.name,
            phone: formData.phone,
            commissionRate: formData.commissionRate === '' ? undefined : Number(formData.commissionRate),
        });
    };
    
    return (
         <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">{agent ? 'Edit Delivery Agent' : 'Add New Delivery Agent'}</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </header>
                <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium">Full Name</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                     <div>
                        <label htmlFor="phone" className="block text-sm font-medium">Phone Number</label>
                        <input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleChange} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                     <div>
                        <label htmlFor="commissionRate" className="block text-sm font-medium">Commission Rate (%)</label>
                        <input type="number" name="commissionRate" id="commissionRate" value={formData.commissionRate} onChange={handleChange} placeholder="Uses global rate if blank" min="0" step="0.5" className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <footer className="flex justify-end gap-3 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 rounded-md">Cancel</button>
                        <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save</button>
                    </footer>
                </form>
            </div>
        </div>
    );
};


const LeaveRequestForm: React.FC<{
    agents: DeliveryAgent[],
    employees: Employee[],
    onSubmit: (request: LeaveRequest) => void,
}> = ({ agents, employees, onSubmit }) => {
    const [employeeId, setEmployeeId] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [reason, setReason] = useState('');
    const [error, setError] = useState('');

    const allStaff = useMemo(() => [
        ...agents.map(a => ({ id: a.id, name: a.name, type: 'agent' as const })),
        ...employees.map(e => ({ id: e.id, name: e.name, type: 'employee' as const }))
    ].sort((a, b) => a.name.localeCompare(b.name)), [agents, employees]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (!employeeId || !startDate || !endDate || !reason) {
            setError('All fields are required.');
            return;
        }

        const start = new Date(startDate);
        const end = new Date(endDate);

        if (start > end) {
            setError('End date cannot be before the start date.');
            return;
        }

        const staffMember = allStaff.find(s => s.id === employeeId);
        if (!staffMember) {
            setError('Selected employee not found.');
            return;
        }
        
        const newRequest: LeaveRequest = {
            id: `leave-${Date.now()}`,
            employeeId: staffMember.id,
            employeeName: staffMember.name,
            employeeType: staffMember.type,
            startDate: start,
            endDate: end,
            reason,
            status: 'pending',
        };
        
        onSubmit(newRequest);
        // Reset form
        setEmployeeId('');
        setStartDate('');
        setEndDate('');
        setReason('');
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 max-w-lg mx-auto p-4 sm:p-6 bg-white dark:bg-gray-800 rounded-lg shadow-lg">
            <h3 className="text-xl font-bold text-center">Submit Leave Request</h3>
            <div>
                <label htmlFor="employeeId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Employee</label>
                <select id="employeeId" value={employeeId} onChange={e => setEmployeeId(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                    <option value="" disabled>Select an employee</option>
                    {allStaff.map(staff => <option key={staff.id} value={staff.id}>{staff.name} ({staff.type === 'agent' ? 'Agent' : 'Staff'})</option>)}
                </select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                 <div>
                    <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Start Date</label>
                    <input type="date" id="startDate" value={startDate} onChange={e => setStartDate(e.target.value)} className="mt-1 block w-full p-2 border rounded-md bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                </div>
                <div>
                    <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">End Date</label>
                    <input type="date" id="endDate" value={endDate} onChange={e => setEndDate(e.target.value)} className="mt-1 block w-full p-2 border rounded-md bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                </div>
            </div>
            <div>
                <label htmlFor="reason" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Reason for Leave</label>
                <textarea id="reason" rows={3} value={reason} onChange={e => setReason(e.target.value)} className="mt-1 block w-full p-2 border rounded-md bg-gray-50 dark:bg-gray-700 dark:border-gray-600" placeholder="e.g., Family vacation"></textarea>
            </div>
            {error && <p className="text-sm text-red-500 text-center">{error}</p>}
            <button type="submit" className="w-full px-4 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700">Submit Request</button>
        </form>
    );
};

export const LeaveManagement: React.FC<LeaveManagementProps> = ({ agents, setAgents, employees, setEmployees, leaveRequests, setLeaveRequests }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedAgentId, setSelectedAgentId] = useState<string | null>(agents[0]?.id || null);
    const [sortConfig, setSortConfig] = useState<{ key: 'name' | 'status'; direction: 'ascending' | 'descending' }>({
        key: 'name',
        direction: 'ascending',
    });
    const [editingDate, setEditingDate] = useState<{ date: Date; target: HTMLElement } | null>(null);
    const [view, setView] = useState<'manage' | 'request'>('manage');
    const popoverRef = useRef<HTMLDivElement>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingAgent, setEditingAgent] = useState<DeliveryAgent | null>(null);
    const [agentToDelete, setAgentToDelete] = useState<DeliveryAgent | null>(null);

    const sortedAgents = useMemo(() => {
        return [...agents].sort((a, b) => {
            const aValue = a[sortConfig.key];
            const bValue = b[sortConfig.key];
            if (aValue < bValue) return sortConfig.direction === 'ascending' ? -1 : 1;
            if (aValue > bValue) return sortConfig.direction === 'ascending' ? 1 : -1;
            return 0;
        });
    }, [agents, sortConfig]);

    const requestSort = (key: 'name' | 'status') => {
        setSortConfig(current => ({
            key,
            direction: current.key === key && current.direction === 'ascending' ? 'descending' : 'ascending',
        }));
    };

    const handleMonthChange = (offset: number) => {
        setCurrentDate(prev => new Date(prev.getFullYear(), prev.getMonth() + offset, 1));
    };

    const handleLeaveRequestAction = (requestId: string, newStatus: 'approved' | 'denied') => {
        const requestToUpdate = leaveRequests.find(req => req.id === requestId);
        if (!requestToUpdate) return;
        
        setLeaveRequests(prev => prev.map(req => req.id === requestId ? { ...req, status: newStatus } : req));
        
        if (newStatus === 'approved') {
            const updateAttendance = (attendance: Record<string, 'present' | 'absent' | 'on-leave'> | undefined) => {
                const newAttendance = { ...(attendance || {}) };
                for (let d = new Date(requestToUpdate.startDate); d <= requestToUpdate.endDate; d.setDate(d.getDate() + 1)) {
                    newAttendance[new Date(d).toISOString().split('T')[0]] = 'on-leave';
                }
                return newAttendance;
            };

            if (requestToUpdate.employeeType === 'agent') {
                setAgents(prevAgents => prevAgents.map(agent => 
                    agent.id === requestToUpdate.employeeId 
                    ? { ...agent, attendance: updateAttendance(agent.attendance) } 
                    : agent
                ));
            } else { // 'employee'
                setEmployees(prevEmployees => prevEmployees.map(employee => 
                    employee.id === requestToUpdate.employeeId
                    ? { ...employee, attendance: updateAttendance(employee.attendance) }
                    : employee
                ));
            }
        }
    };
    
    const handleSetAttendance = (status: 'present' | 'absent' | 'on-leave') => {
        if (!editingDate || !selectedAgentId) return;

        const dateKey = editingDate.date.toISOString().split('T')[0];

        setAgents(prevAgents => prevAgents.map(agent => 
            agent.id === selectedAgentId 
            ? { ...agent, attendance: { ...(agent.attendance || {}), [dateKey]: status } } 
            : agent
        ));
        setEditingDate(null);
    };
    
    const handlePrint = () => window.print();

    const handleRequestSubmitted = (newRequest: LeaveRequest) => {
        setLeaveRequests(prev => [newRequest, ...prev]);
        setView('manage');
        alert(`Leave request submitted for ${newRequest.employeeName}.`);
    };

    const handleSaveAgent = (data: Omit<DeliveryAgent, 'id' | 'status' | 'attendance'>) => {
        if (editingAgent) {
            setAgents(prev => prev.map(a => (a.id === editingAgent.id ? { ...editingAgent, ...data } : a)));
        } else {
            const newAgent: DeliveryAgent = {
                ...data,
                id: `agent-${Date.now()}`,
                status: 'available',
                attendance: {},
            };
            setAgents(prev => [newAgent, ...prev]);
        }
        setIsModalOpen(false);
        setEditingAgent(null);
    };

    const handleDeleteAgent = () => {
        if (agentToDelete) {
            setAgents(prev => prev.filter(a => a.id !== agentToDelete.id));
            setAgentToDelete(null);
        }
    };

    const renderCalendar = () => {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const agent = agents.find(a => a.id === selectedAgentId);
        const attendance = agent?.attendance || {};
        
        const days = Array.from({ length: firstDay }, (_, i) => <div key={`empty-${i}`} className="border-r border-b dark:border-gray-700"></div>);
        for (let day = 1; day <= daysInMonth; day++) {
            const fullDate = new Date(year, month, day);
            const dateKey = fullDate.toISOString().split('T')[0];
            const status = attendance[dateKey];
            days.push(
                <div 
                    key={day} 
                    onClick={(e) => setEditingDate({ date: fullDate, target: e.currentTarget })}
                    className={`p-2 border-r border-b dark:border-gray-700 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors no-print ${status ? attendanceColors[status] : ''}`}
                >
                    <span className="font-medium">{day}</span>
                    {status && <span className="text-xs capitalize mt-1">{status.replace('-', ' ')}</span>}
                </div>
            );
        }

        return (
            <div className="grid grid-cols-7">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                    <div key={day} className="text-center font-bold p-2 border-b-2 border-r dark:border-gray-700">{day}</div>
                ))}
                {days}
            </div>
        );
    };
    
    const TabButton: React.FC<{ tab: 'manage' | 'request', children: React.ReactNode }> = ({ tab, children }) => (
        <button
            onClick={() => setView(tab)}
            className={`px-4 py-2 text-sm font-medium rounded-md ${view === tab ? 'bg-indigo-600 text-white' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
        >
            {children}
        </button>
    );

    const pendingRequests = leaveRequests.filter(r => r.status === 'pending');
    const selectedAgent = agents.find(a => a.id === selectedAgentId);

    return (
        <div>
            {isModalOpen && <AgentFormModal agent={editingAgent} onSave={handleSaveAgent} onClose={() => { setIsModalOpen(false); setEditingAgent(null); }} />}
            {agentToDelete && (
                 <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60] p-4">
                    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
                        <div className="p-6 text-center">
                            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 dark:bg-red-900/50">
                                <AlertTriangleIcon className="h-6 w-6 text-red-600 dark:text-red-300" />
                            </div>
                            <h3 className="mt-5 text-lg font-medium text-gray-900 dark:text-white">Delete Agent</h3>
                            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">Are you sure you want to delete {agentToDelete.name}? This action cannot be undone.</p>
                        </div>
                        <div className="flex justify-center gap-3 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-b-lg">
                            <button onClick={() => setAgentToDelete(null)} className="px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600">Cancel</button>
                            <button onClick={handleDeleteAgent} className="px-4 py-2 text-white bg-red-600 rounded-md hover:bg-red-700">Delete</button>
                        </div>
                    </div>
                </div>
            )}
            <div className="flex justify-center items-center gap-4 mb-6 no-print">
                <TabButton tab="manage">Manage</TabButton>
                <TabButton tab="request">Submit Request</TabButton>
            </div>

            {view === 'manage' && (
                <div className="flex flex-col lg:flex-row gap-6">
                    <div className="lg:w-1/3 bg-white dark:bg-gray-800 p-4 rounded-lg shadow no-print">
                        <div className="flex justify-between items-center mb-2">
                             <h3 className="text-xl font-bold">Delivery Agents</h3>
                             <button onClick={() => { setEditingAgent(null); setIsModalOpen(true); }} className="p-2 rounded-full text-indigo-600 hover:bg-indigo-100 dark:hover:bg-indigo-900/50" title="Add New Agent">
                                <UserPlusIcon className="w-5 h-5"/>
                             </button>
                         </div>
                         <div className="flex items-center gap-2 mb-4 text-sm text-gray-600 dark:text-gray-300">
                            <span>Sort by:</span>
                            <button onClick={() => requestSort('name')} className={`px-2 py-1 rounded-md flex items-center gap-1 transition-colors ${sortConfig.key === 'name' ? 'bg-gray-200 dark:bg-gray-700 font-semibold' : 'hover:bg-gray-100 dark:hover:bg-gray-600'}`}>
                                Name
                                {sortConfig.key === 'name' && (sortConfig.direction === 'ascending' ? <ArrowUpIcon className="w-4 h-4" /> : <ArrowDownIcon className="w-4 h-4" />)}
                            </button>
                            <button onClick={() => requestSort('status')} className={`px-2 py-1 rounded-md flex items-center gap-1 transition-colors ${sortConfig.key === 'status' ? 'bg-gray-200 dark:bg-gray-700 font-semibold' : 'hover:bg-gray-100 dark:hover:bg-gray-600'}`}>
                                Status
                                {sortConfig.key === 'status' && (sortConfig.direction === 'ascending' ? <ArrowUpIcon className="w-4 h-4" /> : <ArrowDownIcon className="w-4 h-4" />)}
                            </button>
                         </div>
                         <ul className="space-y-2">
                            {sortedAgents.map(agent => (
                                <li key={agent.id} onClick={() => { setSelectedAgentId(agent.id); setEditingDate(null); }}
                                    className={`p-3 rounded-md cursor-pointer transition-colors ${selectedAgentId === agent.id ? 'bg-indigo-100 dark:bg-indigo-900/50 ring-2 ring-indigo-500' : 'hover:bg-gray-50 dark:hover:bg-gray-700/50'}`}>
                                   <div className="flex justify-between items-center">
                                       <div>
                                           <span className="font-semibold">{agent.name}</span>
                                           <p className="text-xs text-gray-500">{agent.phone}</p>
                                       </div>
                                        <div className="flex items-center gap-2">
                                            <span className={`hidden sm:inline-block px-2 py-1 rounded-full text-xs font-semibold ${statusColors[agent.status]}`}>{agent.status}</span>
                                            <button onClick={(e) => { e.stopPropagation(); setEditingAgent(agent); setIsModalOpen(true); }} className="p-1 rounded-full text-gray-400 hover:text-indigo-500 hover:bg-gray-200 dark:hover:bg-gray-600"><EditIcon className="w-4 h-4" /></button>
                                            <button onClick={(e) => { e.stopPropagation(); setAgentToDelete(agent); }} className="p-1 rounded-full text-gray-400 hover:text-red-500 hover:bg-gray-200 dark:hover:bg-gray-600"><TrashIcon className="w-4 h-4" /></button>
                                        </div>
                                   </div>
                                </li>
                            ))}
                         </ul>
                    </div>
                    <div className="lg:w-2/3 space-y-6">
                        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow relative">
                            {editingDate && (
                                <div ref={popoverRef} className="absolute z-10 bg-white dark:bg-gray-800 rounded-lg shadow-2xl p-4 border dark:border-gray-600 no-print" style={{ top: `${editingDate.target.offsetTop + editingDate.target.offsetHeight}px`, left: `${editingDate.target.offsetLeft}px`}}>
                                    <div className="flex justify-between items-center mb-3">
                                        <h4 className="font-semibold">{editingDate.date.toLocaleDateString()}</h4>
                                        <button onClick={() => setEditingDate(null)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
                                            <CloseIcon className="w-4 h-4"/>
                                        </button>
                                    </div>
                                    <div className="flex flex-col gap-2">
                                        <button onClick={() => handleSetAttendance('present')} className="w-full text-left px-3 py-1 text-sm rounded hover:bg-green-100 dark:hover:bg-green-900/50">Mark as Present</button>
                                        <button onClick={() => handleSetAttendance('absent')} className="w-full text-left px-3 py-1 text-sm rounded hover:bg-red-100 dark:hover:bg-red-900/50">Mark as Absent</button>
                                        <button onClick={() => handleSetAttendance('on-leave')} className="w-full text-left px-3 py-1 text-sm rounded hover:bg-yellow-100 dark:hover:bg-yellow-900/50">Mark as On Leave</button>
                                    </div>
                                </div>
                            )}
                            <div className="flex justify-between items-center mb-4">
                                <button onClick={() => handleMonthChange(-1)} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 no-print"><ChevronLeftIcon className="w-6 h-6"/></button>
                                <div>
                                     <h3 className="text-xl font-bold text-center">{currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}</h3>
                                     {selectedAgent && <p className="text-sm text-gray-500 text-center">Attendance for: <span className="font-semibold">{selectedAgent.name}</span></p>}
                                </div>
                                <div className="flex items-center gap-2">
                                    <button onClick={handlePrint} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 no-print" disabled={!selectedAgentId}>
                                        <PrintIcon className="w-6 h-6"/>
                                    </button>
                                    <button onClick={() => handleMonthChange(1)} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 no-print"><ChevronRightIcon className="w-6 h-6"/></button>
                                </div>
                            </div>
                            {selectedAgentId ? renderCalendar() : <p className="text-center py-10">Select an agent to view their calendar.</p>}
                             <div className="mt-4 flex flex-wrap gap-4 text-xs no-print">
                                <div className="flex items-center gap-2"><span className="w-4 h-4 rounded-full bg-green-500"></span> Present</div>
                                <div className="flex items-center gap-2"><span className="w-4 h-4 rounded-full bg-red-500"></span> Absent</div>
                                <div className="flex items-center gap-2"><span className="w-4 h-4 rounded-full bg-yellow-500"></span> On Leave</div>
                            </div>
                        </div>
                        
                        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow no-print">
                             <h3 className="text-xl font-bold mb-4">Pending Leave Requests</h3>
                             {pendingRequests.length > 0 ? (
                                <ul className="space-y-3">
                                    {pendingRequests.map(req => (
                                        <li key={req.id} className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-md flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                                            <div>
                                                <p className="font-semibold">{req.employeeName}</p>
                                                <p className="text-sm text-gray-600 dark:text-gray-300">
                                                    {req.startDate.toLocaleDateString()} - {req.endDate.toLocaleDateString()}
                                                </p>
                                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 italic">"{req.reason}"</p>
                                            </div>
                                            <div className="flex gap-2 self-end sm:self-center">
                                                <button onClick={() => handleLeaveRequestAction(req.id, 'approved')} className="p-2 rounded-full text-green-600 hover:bg-green-100 dark:hover:bg-green-900/50"><CheckCircleIcon className="w-6 h-6"/></button>
                                                <button onClick={() => handleLeaveRequestAction(req.id, 'denied')} className="p-2 rounded-full text-red-600 hover:bg-red-100 dark:hover:bg-red-900/50"><XCircleIcon className="w-6 h-6"/></button>
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                             ) : (
                                <p className="text-gray-500">No pending leave requests.</p>
                             )}
                        </div>
                    </div>
                </div>
            )}

            {view === 'request' && (
                <LeaveRequestForm agents={agents} employees={employees} onSubmit={handleRequestSubmitted} />
            )}
        </div>
    );
};