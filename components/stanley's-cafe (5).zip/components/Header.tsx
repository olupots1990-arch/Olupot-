import React, { useState } from 'react';
import type { User } from '../types';
import type { Theme } from '../App';
import { UserIcon, WifiIcon, WifiOffIcon, SunIcon, MoonIcon, MonitorIcon } from './icons';
import ProfileModal from './ProfileModal';

interface HeaderProps {
    isOnline: boolean;
    currentUser: User;
    users: User[];
    onUserChange: (user: User) => void;
    onLogout: () => void;
    activeTab: string;
    theme: Theme;
    setTheme: React.Dispatch<React.SetStateAction<Theme>>;
    setUsers: React.Dispatch<React.SetStateAction<User[]>>;
}

const Header: React.FC<HeaderProps> = ({ isOnline, currentUser, users, onUserChange, onLogout, activeTab, theme, setTheme, setUsers }) => {
    const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

    const getPageTitle = (tab: string) => {
        switch (tab) {
            case 'leave':
                return 'Leave & Attendance';
            case 'users':
                return 'User Accounts';
            default:
                return tab;
        }
    };

    const handleThemeToggle = () => {
        const themes: Theme[] = ['light', 'dark', 'system'];
        const currentIndex = themes.indexOf(theme);
        const nextIndex = (currentIndex + 1) % themes.length;
        setTheme(themes[nextIndex]);
    };

    const ThemeIcon = {
        light: <SunIcon className="w-5 h-5 text-gray-700 dark:text-gray-300" />,
        dark: <MoonIcon className="w-5 h-5 text-gray-700 dark:text-gray-300" />,
        system: <MonitorIcon className="w-5 h-5 text-gray-700 dark:text-gray-300" />,
    }[theme];

    return (
        <>
            <header className="no-print bg-white dark:bg-gray-800 shadow-md flex-shrink-0">
                <div className="container mx-auto px-4 md:px-6 lg:px-8">
                    <div className="flex justify-between items-center h-20">
                        <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 capitalize">
                            {getPageTitle(activeTab)}
                        </h2>
                        <div className="flex items-center space-x-4">
                            <div className="relative group flex items-center gap-2 text-sm">
                                {isOnline ? <WifiIcon className="w-5 h-5 text-green-500"/> : <WifiOffIcon className="w-5 h-5 text-red-500"/>}
                                <span className="hidden group-hover:block absolute bottom-full mb-2 left-1/2 -translate-x-1/2 whitespace-nowrap bg-black text-white text-xs rounded py-1 px-2">
                                    {isOnline ? 'Online: System is connected.' : 'Offline: Changes are saved locally.'}
                                </span>
                            </div>

                            <button 
                                onClick={handleThemeToggle} 
                                className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700" 
                                title={`Theme: ${theme}`}
                                aria-label={`Change theme from ${theme}`}
                            >
                                {ThemeIcon}
                            </button>

                            <select
                                value={currentUser.id}
                                onChange={(e) => {
                                    const selectedUser = users.find(u => u.id === e.target.value);
                                    if (selectedUser) onUserChange(selectedUser);
                                }}
                                className="text-sm bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md p-1.5 focus:ring-indigo-500 focus:border-indigo-500"
                            >
                                {users
                                    .filter(u => ['admin', 'manager', 'supervisor'].includes(u.role))
                                    .map(user => (
                                        <option key={user.id} value={user.id}>
                                            {user.name} ({user.role})
                                        </option>
                                    ))}
                            </select>
                            
                            <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>

                            <div className="flex items-center space-x-2 cursor-pointer" onClick={() => setIsProfileModalOpen(true)}>
                                {currentUser.profilePictureUrl ? (
                                    <img src={currentUser.profilePictureUrl} alt={currentUser.name} className="w-9 h-9 rounded-full object-cover" />
                                ) : (
                                    <div className="w-9 h-9 rounded-full bg-indigo-200 dark:bg-indigo-900 flex items-center justify-center">
                                        <UserIcon className="w-5 h-5 text-indigo-600 dark:text-indigo-300" />
                                    </div>
                                )}
                                <p className="font-semibold text-sm text-gray-800 dark:text-gray-200">{currentUser.name}</p>
                            </div>
                            <button onClick={onLogout} className="text-sm font-medium text-red-500 hover:underline">Logout</button>
                        </div>
                    </div>
                </div>
            </header>
            {isProfileModalOpen && (
                <ProfileModal
                    user={currentUser}
                    onClose={() => setIsProfileModalOpen(false)}
                    onSave={(newProfilePicUrl) => {
                        setUsers(prevUsers => prevUsers.map(u => 
                            u.id === currentUser.id ? { ...u, profilePictureUrl: newProfilePicUrl } : u
                        ));
                        setIsProfileModalOpen(false);
                    }}
                />
            )}
        </>
    );
};

export default Header;