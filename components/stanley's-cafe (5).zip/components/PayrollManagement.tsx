import React, { useState, useMemo, useEffect } from 'react';
import type { Employee, DeliveryAgent, Order, PayrollData } from '../types';
import { OrderStatus } from '../types';
import { DownloadIcon, PrintIcon, CloseIcon } from './icons';

interface PayrollManagementProps {
    employees: Employee[];
    agents: DeliveryAgent[];
    orders: Order[];
    globalCommissionRate: number;
    currencySymbol: string;
}

const PayslipModal: React.FC<{ data: PayrollData, currency: string, onClose: () => void }> = ({ data, currency, onClose }) => {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 printable-area">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b dark:border-gray-700 no-print">
                    <h3 className="text-lg font-bold">Payslip for {data.name}</h3>
                    <div className="flex items-center gap-2">
                         <button onClick={() => window.print()} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"><PrintIcon className="w-5 h-5"/></button>
                         <button onClick={onClose}><CloseIcon className="w-6 h-6"/></button>
                    </div>
                </header>
                <div className="p-6 space-y-4 overflow-y-auto">
                    <h2 className="text-2xl font-bold text-center">Stanley's Cafe</h2>
                    <p className="text-center text-sm text-gray-500">Payslip for {new Date().toLocaleString('default', { month: 'long', year: 'numeric' })}</p>
                    <div className="mt-6 pt-4 border-t dark:border-gray-600">
                        <p><strong>Employee:</strong> {data.name}</p>
                        <p><strong>Role:</strong> {data.type}</p>
                    </div>
                    <table className="w-full mt-4 text-sm">
                        <thead>
                            <tr className="border-b dark:border-gray-600">
                                <th className="text-left py-2">Description</th>
                                <th className="text-right py-2">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className="border-b dark:border-gray-700">
                                <td className="py-2">Earnings</td><td></td>
                            </tr>
                            {data.baseSalary && <tr><td className="pl-4 py-1">Base Salary</td><td className="text-right">{currency}{data.baseSalary.toFixed(2)}</td></tr>}
                            {data.commissionEarned && <tr><td className="pl-4 py-1">Commission ({data.deliveries} deliveries)</td><td className="text-right">{currency}{data.commissionEarned.toFixed(2)}</td></tr>}
                             <tr><td className="pl-4 py-1">Bonuses</td><td className="text-right">{currency}{data.bonuses.toFixed(2)}</td></tr>
                            <tr className="border-b dark:border-gray-700">
                                <td className="py-2 font-semibold">Gross Pay</td>
                                <td className="text-right font-semibold">{currency}{( (data.baseSalary || 0) + (data.commissionEarned || 0) + data.bonuses ).toFixed(2)}</td>
                            </tr>
                            <tr className="border-b dark:border-gray-700">
                                <td className="py-2">Deductions</td><td></td>
                            </tr>
                            <tr><td className="pl-4 py-1">Taxes/Other</td><td className="text-right">- {currency}{data.deductions.toFixed(2)}</td></tr>
                             <tr className="border-b-2 border-black dark:border-white">
                                <td className="py-2 font-semibold">Total Deductions</td>
                                <td className="text-right font-semibold">- {currency}{data.deductions.toFixed(2)}</td>
                            </tr>
                            <tr>
                                <td className="pt-4 text-lg font-bold">Net Pay</td>
                                <td className="pt-4 text-lg font-bold text-right">{currency}{data.netPay.toFixed(2)}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

const PayrollManagement: React.FC<PayrollManagementProps> = ({ employees, agents, orders, globalCommissionRate, currencySymbol }) => {
    const [payPeriod, setPayPeriod] = useState(() => new Date().toISOString().slice(0, 7)); // YYYY-MM
    const [payrollData, setPayrollData] = useState<PayrollData[]>([]);
    const [payslipUser, setPayslipUser] = useState<PayrollData | null>(null);

    const generatePayroll = useMemo(() => {
        const [year, month] = payPeriod.split('-').map(Number);
        const startDate = new Date(year, month - 1, 1);
        const endDate = new Date(year, month, 0, 23, 59, 59);

        const employeePayroll = employees.map(emp => {
            const bonuses = 0; // Placeholder
            const deductions = emp.baseSalary * 0.15; // Placeholder tax
            const netPay = emp.baseSalary + bonuses - deductions;
            return {
                id: emp.id, name: emp.name, type: 'Employee' as const,
                baseSalary: emp.baseSalary, bonuses, deductions, netPay
            };
        });

        const agentPayroll = agents.map(agent => {
            const agentOrders = orders.filter(o => 
                o.deliveryAgentId === agent.id &&
                o.status === OrderStatus.DELIVERED &&
                o.isPaid &&
                o.timestamp >= startDate && o.timestamp <= endDate
            );

            const commissionRate = (agent.commissionRate ?? globalCommissionRate) / 100;
            const commissionEarned = agentOrders.reduce((sum, o) => sum + (o.total * commissionRate), 0);
            
            const bonuses = 0; // Placeholder
            const deductions = commissionEarned * 0.10; // Placeholder tax
            const netPay = commissionEarned + bonuses - deductions;

            return {
                id: agent.id, name: agent.name, type: 'Delivery Agent' as const,
                commissionRate: agent.commissionRate ?? globalCommissionRate,
                deliveries: agentOrders.length,
                commissionEarned, bonuses, deductions, netPay
            };
        });
        
        return [...employeePayroll, ...agentPayroll];
    }, [payPeriod, employees, agents, orders, globalCommissionRate]);

    useEffect(() => {
        setPayrollData(generatePayroll);
    }, [generatePayroll]);

    const handlePayrollDataChange = (id: string, field: 'bonuses' | 'deductions', value: number) => {
        setPayrollData(prev => prev.map(p => {
            if (p.id === id) {
                const updated = { ...p, [field]: value };
                const gross = (updated.baseSalary || 0) + (updated.commissionEarned || 0) + updated.bonuses;
                updated.netPay = gross - updated.deductions;
                return updated;
            }
            return p;
        }));
    };

    const handleExport = () => {
        const headers = ['ID', 'Name', 'Type', 'Base Salary', 'Commission Rate (%)', 'Deliveries', 'Commission Earned', 'Bonuses', 'Deductions', 'Net Pay'];
        const csvRows = [headers.join(',')];
        
        payrollData.forEach(p => {
            const row = [
                p.id, `"${p.name}"`, p.type, p.baseSalary?.toFixed(2) || 'N/A',
                p.commissionRate || 'N/A', p.deliveries || 'N/A', p.commissionEarned?.toFixed(2) || 'N/A',
                p.bonuses.toFixed(2), p.deductions.toFixed(2), p.netPay.toFixed(2)
            ].join(',');
            csvRows.push(row);
        });

        const csvString = csvRows.join('\n');
        const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `payroll_${payPeriod}.csv`;
        link.click();
        URL.revokeObjectURL(link.href);
    };

    const totalPayroll = payrollData.reduce((sum, p) => sum + p.netPay, 0);

    return (
        <div className="bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-lg">
            <>
                <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-3">
                    <h2 className="text-2xl font-bold">Payroll Report</h2>
                    <div className="flex items-center gap-4">
                        <input
                            type="month"
                            value={payPeriod}
                            onChange={e => setPayPeriod(e.target.value)}
                            className="p-2 border rounded-md bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                        />
                        <button onClick={handleExport} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700">
                            <DownloadIcon className="w-5 h-5" /> Export CSV
                        </button>
                    </div>
                </header>

                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th className="px-4 py-3">Name</th>
                                <th className="px-4 py-3">Type</th>
                                <th className="px-4 py-3">Earnings</th>
                                <th className="px-4 py-3">Bonuses</th>
                                <th className="px-4 py-3">Deductions</th>
                                <th className="px-4 py-3">Net Pay</th>
                                <th className="px-4 py-3">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {payrollData.map(p => (
                                <tr key={p.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                    <td className="px-4 py-2 font-medium">{p.name}</td>
                                    <td className="px-4 py-2">{p.type}</td>
                                    <td className="px-4 py-2">
                                        {p.type === 'Employee' && typeof p.baseSalary === 'number' ? (
                                            `${currencySymbol}${p.baseSalary.toFixed(2)}`
                                        ) : p.type === 'Delivery Agent' ? (
                                            <div>
                                                <span className="font-semibold">{currencySymbol}{(p.commissionEarned || 0).toFixed(2)}</span>
                                                <br />
                                                <span className="text-xs text-gray-500 dark:text-gray-400">
                                                    {p.deliveries} deliveries @ {p.commissionRate}%
                                                </span>
                                            </div>
                                        ) : (
                                            'N/A'
                                        )}
                                    </td>
                                    <td className="px-4 py-2">
                                        <input type="number" value={p.bonuses} onChange={e => handlePayrollDataChange(p.id, 'bonuses', +e.target.value)} className="w-24 p-1 text-sm border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                                    </td>
                                    <td className="px-4 py-2">
                                        <input type="number" value={p.deductions} onChange={e => handlePayrollDataChange(p.id, 'deductions', +e.target.value)} className="w-24 p-1 text-sm border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                                    </td>
                                    <td className="px-4 py-2 font-semibold">{currencySymbol}{p.netPay.toFixed(2)}</td>
                                    <td className="px-4 py-2">
                                        <button onClick={() => setPayslipUser(p)} className="text-indigo-600 hover:underline text-xs">View Payslip</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                <div className="mt-6 pt-4 border-t dark:border-gray-600 flex justify-end">
                    <div className="text-right">
                        <p className="text-gray-500">Total Payroll for {new Date(payPeriod + '-02').toLocaleString('default', { month: 'long', year: 'numeric' })}:</p>
                        <p className="text-2xl font-bold">{currencySymbol}{totalPayroll.toFixed(2)}</p>
                    </div>
                </div>
            </>
            {payslipUser && <PayslipModal data={payslipUser} currency={currencySymbol} onClose={() => setPayslipUser(null)} />}
        </div>
    );
};

export default PayrollManagement;