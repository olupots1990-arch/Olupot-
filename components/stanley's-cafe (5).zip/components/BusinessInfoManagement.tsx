import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import { LocationInfo } from '../types';
import { geocodeAddress } from '../services/geminiService';
import { MapIcon, SparklesIcon, GlobeIcon } from './icons';
import { CURRENCY_DATA } from '../constants';

interface BusinessInfoManagementProps {
    location: LocationInfo;
    onLocationChange: React.Dispatch<React.SetStateAction<LocationInfo>>;
    currencySymbol: string;
    setCurrencySymbol: React.Dispatch<React.SetStateAction<string>>;
    isOnline: boolean;
    domainName: string;
    setDomainName: React.Dispatch<React.SetStateAction<string>>;
}

const BusinessInfoManagement: React.FC<BusinessInfoManagementProps> = ({ location, onLocationChange, currencySymbol, setCurrencySymbol, isOnline, domainName, setDomainName }) => {
    const [addressInput, setAddressInput] = useState(location.address);
    const [domainInput, setDomainInput] = useState(domainName);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const aiRef = useRef<GoogleGenAI | null>(null);

    useEffect(() => {
        setAddressInput(location.address);
    }, [location.address]);

    useEffect(() => {
        setDomainInput(domainName);
    }, [domainName]);

    const handleUpdateLocation = async () => {
        if (!addressInput.trim()) {
            setError("Address cannot be empty.");
            return;
        }
        
        setIsLoading(true);
        setError(null);
        
        try {
            if (!aiRef.current) {
                aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            }
            const coordinates = await geocodeAddress(aiRef.current, addressInput);
            onLocationChange({
                address: addressInput,
                coordinates,
            });
        } catch (e: any) {
            console.error("Geocoding failed:", e);
            setError("Could not find coordinates for this address. Please try a different format.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleUpdateDomain = () => {
        if (domainInput.trim()) {
            setDomainName(domainInput.trim());
        }
    };

    return (
        <div className="p-6 space-y-6">
            <header>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Business Information</h2>
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                    Manage your cafe's physical location and contact details.
                </p>
            </header>

            <div className="space-y-4 pt-4 border-t dark:border-gray-700">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Physical Location</h3>
                 <div>
                    <label htmlFor="address" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Cafe Address
                    </label>
                    <div className="mt-1 flex flex-col sm:flex-row gap-2">
                        <input
                            type="text"
                            id="address"
                            value={addressInput}
                            onChange={(e) => setAddressInput(e.target.value)}
                            className="flex-grow block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600 focus:ring-indigo-500 focus:border-indigo-500"
                            placeholder="e.g., 123 Foodie Lane, Valletta, Malta"
                            disabled={isLoading || !isOnline}
                        />
                        <button 
                            onClick={handleUpdateLocation} 
                            disabled={isLoading || addressInput === location.address || !isOnline}
                            className="flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed"
                        >
                            <SparklesIcon className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
                            {isLoading ? 'Updating...' : 'Update Location'}
                        </button>
                    </div>
                    {!isOnline && <p className="mt-2 text-xs text-red-500">Address geocoding is disabled while offline.</p>}
                     {error && <p className="mt-2 text-sm text-red-500">{error}</p>}
                </div>

                <div className="p-4 bg-gray-50 dark:bg-gray-900/40 rounded-lg flex items-start gap-4">
                    <MapIcon className="w-6 h-6 text-gray-500 mt-1"/>
                    <div>
                        <p className="font-semibold text-gray-800 dark:text-gray-200">Current Geolocation</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                            These coordinates are used for map features on the website.
                        </p>
                        <p className="mt-1 text-xs font-mono bg-gray-200 dark:bg-gray-700 inline-block px-2 py-1 rounded">
                            Lat: {location.coordinates.latitude.toFixed(4)}, Lng: {location.coordinates.longitude.toFixed(4)}
                        </p>
                    </div>
                </div>
            </div>

            <div className="space-y-4 pt-4 border-t dark:border-gray-700">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Online Presence</h3>
                 <div>
                    <label htmlFor="domainName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Website Domain
                    </label>
                    <div className="mt-1 flex flex-col sm:flex-row gap-2">
                        <div className="relative flex-grow">
                             <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <GlobeIcon className="w-5 h-5 text-gray-400" />
                            </div>
                            <input
                                type="text"
                                id="domainName"
                                value={domainInput}
                                onChange={(e) => setDomainInput(e.target.value)}
                                className="w-full p-2 pl-10 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600 focus:ring-indigo-500 focus:border-indigo-500"
                                placeholder="e.g., www.stanleycafe.com"
                            />
                        </div>
                        <button 
                            onClick={handleUpdateDomain} 
                            disabled={domainInput === domainName}
                            className="flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed"
                        >
                            Save Domain
                        </button>
                    </div>
                </div>
            </div>
            
            <div className="space-y-4 pt-4 border-t dark:border-gray-700">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Currency Settings</h3>
                <div>
                    <label htmlFor="currency" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Select Currency by Country
                    </label>
                    <select
                        id="currency"
                        value={currencySymbol}
                        onChange={(e) => setCurrencySymbol(e.target.value)}
                        className="mt-1 block w-full sm:w-1/2 p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600 focus:ring-indigo-500 focus:border-indigo-500"
                    >
                        {CURRENCY_DATA.map((currency) => (
                            <option key={`${currency.country}-${currency.code}`} value={currency.symbol}>
                                {currency.country} ({currency.code}) - {currency.symbol}
                            </option>
                        ))}
                    </select>
                    <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">Set the currency symbol that will be used across the application.</p>
                </div>
            </div>
        </div>
    );
};

export default BusinessInfoManagement;