import React, { useState, useMemo, useEffect } from 'react';
import type { Order, DeliveryAgent, User, MenuItem } from '../types';
import { OrderStatus, PaymentMethod } from '../types';
import { AlertTriangleIcon, CloseIcon, DownloadIcon, PrintIcon, PlusCircleIcon } from './icons';
import AgentLocationMap from './AgentLocationMap';
import { CreateOrderModal } from './CreateOrderModal';

interface OrderListProps {
    orders: Order[];
    agents: DeliveryAgent[];
    users: User[];
    setOrders: React.Dispatch<React.SetStateAction<Order[]>>;
    setAgents: React.Dispatch<React.SetStateAction<DeliveryAgent[]>>;
    selectedOrder: Order | null;
    onSelectOrder: (order: Order) => void;
    onCloseDetails: () => void;
    globalCommissionRate: number;
    currencySymbol: string;
    onNewOrderNotification: (order: Order) => void;
    menuItems: MenuItem[];
}

const statusColors: Record<OrderStatus, string> = {
    [OrderStatus.PENDING]: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
    [OrderStatus.CONFIRMED]: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    [OrderStatus.PREPARING]: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
    [OrderStatus.OUT_FOR_DELIVERY]: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
    [OrderStatus.DELIVERED]: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    [OrderStatus.CANCELLED]: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
};

const OrderList: React.FC<OrderListProps> = ({ orders, agents, setOrders, setAgents, selectedOrder, onSelectOrder, onCloseDetails, globalCommissionRate, currencySymbol, users, onNewOrderNotification, menuItems }) => {
    const [confirmation, setConfirmation] = useState<{
        isOpen: boolean;
        title: string;
        message: string;
        onConfirm: () => void;
    } | null>(null);
    const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');
    const [currentPage, setCurrentPage] = useState(1);
    const [isCreateOrderModalOpen, setIsCreateOrderModalOpen] = useState(false);
    const ordersPerPage = 10;
    
    const userMap = useMemo(() => new Map(users.map(user => [user.id, user])), [users]);

    const filteredOrders = useMemo(() => {
        if (statusFilter === 'all') {
            return orders;
        }
        return orders.filter(order => order.status === statusFilter);
    }, [orders, statusFilter]);

    useEffect(() => {
        setCurrentPage(1);
    }, [statusFilter]);
    
    const paginatedOrders = useMemo(() => {
        const indexOfLastOrder = currentPage * ordersPerPage;
        const indexOfFirstOrder = indexOfLastOrder - ordersPerPage;
        return filteredOrders.slice(indexOfFirstOrder, indexOfLastOrder);
    }, [filteredOrders, currentPage]);

    const totalPages = Math.ceil(filteredOrders.length / ordersPerPage);


    const sendWhatsAppUpdate = (order: Order, status: OrderStatus) => {
        const customer = userMap.get(order.customerId);
        const phone = order.customerPhone || customer?.phone;
        
        if (!phone) {
            alert(`Cannot send notification: Customer phone for order ${order.id} is missing.`);
            return;
        }

        let message = '';
        
        switch (status) {
            case OrderStatus.CONFIRMED:
                message = `Hi ${customer?.name}, your order #${order.id} has been confirmed and is being processed. Thank you for choosing Stanley's Restaurant!`;
                break;
            case OrderStatus.PREPARING:
                message = `Great news, ${customer?.name}! Your order #${order.id} is now being prepared by our chefs.`;
                break;
            case OrderStatus.OUT_FOR_DELIVERY:
                message = `Your order #${order.id} is on its way, ${customer?.name}! It will be with you shortly.`;
                break;
            case OrderStatus.DELIVERED:
                message = `Your order #${order.id} has been delivered. We hope you enjoy your meal! - Stanley's Restaurant`;
                break;
            case OrderStatus.CANCELLED:
                message = `We're sorry, ${customer?.name}. Your order #${order.id} has been cancelled. Please contact us if you have any questions.`;
                break;
        }

        if (message) {
            const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank');
        }
    };

    const updateOrder = (orderId: string, updates: Partial<Order>) => {
        setOrders(prevOrders => {
            const newOrders = prevOrders.map(o =>
                o.id === orderId ? { ...o, ...updates } : o
            );
            if (selectedOrder?.id === orderId) {
                const updatedOrder = newOrders.find(o => o.id === orderId);
                if (updatedOrder) onSelectOrder(updatedOrder);
            }
            return newOrders;
        });
    };
    
    const handleUpdateStatus = (orderId: string, status: OrderStatus) => {
        const originalOrder = orders.find(o => o.id === orderId);
        if (!originalOrder) return;

        const updates: Partial<Order> = { status };

        if (status === OrderStatus.OUT_FOR_DELIVERY) {
             if (!originalOrder.deliveryAgentId) {
                alert("Please assign a delivery agent before marking the order as 'Out for Delivery'.");
                return; // Prevent status change
            }
            if (originalOrder.status !== OrderStatus.OUT_FOR_DELIVERY) {
                setAgents(prev => prev.map(a => a.id === originalOrder.deliveryAgentId ? { ...a, status: 'on-delivery' } : a));
            }
        }
        
        const wasOutForDelivery = originalOrder.status === OrderStatus.OUT_FOR_DELIVERY;
        const isNowFinished = status === OrderStatus.DELIVERED || status === OrderStatus.CANCELLED;

        if (wasOutForDelivery && isNowFinished && originalOrder.deliveryAgentId) {
             setAgents(prev => prev.map(a => a.id === originalOrder.deliveryAgentId ? { ...a, status: 'available' } : a));
        }

        updateOrder(orderId, updates);

        const notificationStatuses = [OrderStatus.CONFIRMED, OrderStatus.PREPARING, OrderStatus.OUT_FOR_DELIVERY, OrderStatus.DELIVERED, OrderStatus.CANCELLED];
        if (notificationStatuses.includes(status)) {
            sendWhatsAppUpdate({ ...originalOrder, ...updates }, status);
        }
    };
    
    const requestUpdateStatus = (orderId: string, status: OrderStatus) => {
        const criticalStatuses: Partial<Record<OrderStatus, { title: string; message: string }>> = {
            [OrderStatus.DELIVERED]: {
                title: 'Confirm Delivery',
                message: `Are you sure you want to mark order #${orderId} as Delivered? This will notify the customer.`,
            },
            [OrderStatus.CANCELLED]: {
                title: 'Confirm Cancellation',
                message: `Are you sure you want to cancel order #${orderId}? This action cannot be undone and the customer will be notified.`,
            },
        };

        const confirmationDetails = criticalStatuses[status];

        if (confirmationDetails) {
            setConfirmation({
                isOpen: true,
                ...confirmationDetails,
                onConfirm: () => handleUpdateStatus(orderId, status),
            });
        } else {
            handleUpdateStatus(orderId, status);
        }
    };
    
    const handlePrintOrder = () => {
        const printableElement = document.getElementById('order-details-printable');
        if (printableElement) {
            const printContent = printableElement.cloneNode(true) as HTMLElement;
            // The existing print CSS in index.html is designed to show only an element
            // with the 'printable-area' class that is at the top level. We clone the
            // content, add the class, append it to the body for printing, and then remove it.
            printContent.classList.add('printable-area');
            document.body.appendChild(printContent);
            window.print();
            document.body.removeChild(printContent);
        }
    };


    const handleAssignAgent = (orderId: string, agentId: string) => updateOrder(orderId, { deliveryAgentId: agentId });
    const handleMarkAsPaid = (orderId: string) => updateOrder(orderId, { isPaid: true });
    const handleUpdateDeliveryAgentNotes = (orderId: string, notes: string) => updateOrder(orderId, { deliveryAgentNotes: notes });
    const handleUpdatePaymentMethod = (orderId: string, method: string) => updateOrder(orderId, { paymentMethod: method });
    const handleCancelOrder = (orderId: string) => requestUpdateStatus(orderId, OrderStatus.CANCELLED);

    const handleExportToCsv = () => {
        const headers = [
            'Order ID',
            'Customer Name',
            'Customer Phone',
            'Items',
            'Total',
            'Status',
            'Timestamp',
            'Delivery Agent',
            'Payment Status',
            'Payment Method',
            'Delivery Agent Notes',
            'Commission',
        ];

        const csvRows = [headers.join(',')];
        const dataToExport = filteredOrders;

        for (const order of dataToExport) {
            const agent = agents.find(a => a.id === order.deliveryAgentId);
            const customer = userMap.get(order.customerId);
            const commissionRate = (agent?.commissionRate ?? globalCommissionRate) / 100;
            const commission = order.status === OrderStatus.DELIVERED ? (order.total * commissionRate).toFixed(2) : 'N/A';
            
            const formatCsvCell = (value: string | undefined | null) => {
                if (value === null || value === undefined) return 'N/A';
                const stringValue = String(value);
                if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
                    return `"${stringValue.replace(/"/g, '""')}"`;
                }
                return stringValue;
            };

            const itemsString = formatCsvCell(order.items.map(i => `${i.quantity}x ${i.name}`).join('; '));

            const row = [
                order.id,
                formatCsvCell(customer?.name || order.customerName),
                order.customerPhone || customer?.phone || 'N/A',
                itemsString,
                order.total.toFixed(2),
                order.status,
                formatCsvCell(order.timestamp.toLocaleString()),
                formatCsvCell(agent?.name),
                order.isPaid ? 'Paid' : 'Unpaid',
                order.paymentMethod || 'N/A',
                formatCsvCell(order.deliveryAgentNotes),
                commission
            ].join(',');
            csvRows.push(row);
        }

        const csvString = csvRows.join('\n');
        const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `orders_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };
    
    const isOtherPaymentMethod = selectedOrder && !Object.values(PaymentMethod).includes(selectedOrder.paymentMethod as PaymentMethod);
    const paymentSelectValue = selectedOrder ? (isOtherPaymentMethod ? PaymentMethod.OTHER : selectedOrder.paymentMethod) : '';
    const selectedOrderCustomer = selectedOrder ? userMap.get(selectedOrder.customerId) : null;


    return (
        <div className="bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-lg">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-3 no-print">
                <h2 className="text-2xl font-bold">Incoming Orders</h2>
                <div className="flex items-center gap-4">
                    <button
                        onClick={() => setIsCreateOrderModalOpen(true)}
                        className="flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg shadow-sm hover:bg-green-700"
                    >
                        <PlusCircleIcon className="w-5 h-5" />
                        Create Order
                    </button>
                    <div>
                        <label htmlFor="status-filter" className="sr-only">Filter by status</label>
                        <select
                            id="status-filter"
                            value={statusFilter}
                            onChange={(e) => setStatusFilter(e.target.value as OrderStatus | 'all')}
                            className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                        >
                            <option value="all">All Statuses</option>
                            {Object.values(OrderStatus).map(status => (
                                <option key={status} value={status}>{status}</option>
                            ))}
                        </select>
                    </div>
                    <button
                        onClick={handleExportToCsv}
                        className="flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        <DownloadIcon className="w-5 h-5" />
                        Export to CSV
                    </button>
                </div>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3">Order ID</th>
                            <th scope="col" className="px-6 py-3">Customer</th>
                            <th scope="col" className="px-6 py-3">Total</th>
                            <th scope="col" className="px-6 py-3">Status</th>
                            <th scope="col" className="px-6 py-3">Payment</th>
                            <th scope="col" className="px-6 py-3">Payment Method</th>
                            <th scope="col" className="px-6 py-3">Time</th>
                            <th scope="col" className="px-6 py-3 no-print">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {paginatedOrders.map(order => {
                            const customerName = userMap.get(order.customerId)?.name || order.customerName;
                            return (
                                <tr key={order.id} className={`border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors duration-300 ${order.isNew ? 'bg-indigo-50 dark:bg-indigo-900/30' : 'bg-white dark:bg-gray-800'}`}>
                                    <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">
                                        <div className="flex items-center gap-2">
                                            {order.isNew && <span className="w-2.5 h-2.5 bg-green-400 rounded-full animate-pulse"></span>}
                                            {order.id}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">{customerName}</td>
                                    <td className="px-6 py-4">{currencySymbol}{order.total.toFixed(2)}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${statusColors[order.status]}`}>
                                            {order.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4">
                                         {order.isPaid ? (
                                            <span className="px-2 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Paid</span>
                                        ) : (
                                            <span className="px-2 py-1 rounded-full text-xs font-semibold bg-gray-200 text-gray-800 dark:bg-gray-600 dark:text-gray-200">Unpaid</span>
                                        )}
                                    </td>
                                    <td className="px-6 py-4">{order.paymentMethod || '—'}</td>
                                    <td className="px-6 py-4">{order.timestamp.toLocaleTimeString()}</td>
                                    <td className="px-6 py-4 flex items-center space-x-2 no-print">
                                        <button onClick={() => onSelectOrder(order)} className="font-medium text-indigo-600 dark:text-indigo-500 hover:underline">
                                            Details
                                        </button>
                                        {!order.isPaid && (
                                            <button onClick={() => handleMarkAsPaid(order.id)} className="font-medium text-green-600 dark:text-green-500 hover:underline">
                                                Mark as Paid
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
                 {filteredOrders.length === 0 && (
                    <div className="text-center py-10">
                        <p className="text-gray-500 dark:text-gray-400">No orders match the current filter.</p>
                    </div>
                )}
            </div>

            {totalPages > 1 && (
                <div className="flex justify-between items-center mt-4 text-sm no-print">
                    <button 
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                        className="px-4 py-2 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Previous
                    </button>
                    <span className="text-gray-600 dark:text-gray-400">
                        Page {currentPage} of {totalPages}
                    </span>
                    <button 
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                        className="px-4 py-2 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Next
                    </button>
                </div>
            )}

            {isCreateOrderModalOpen && (
                <CreateOrderModal 
                    users={users}
                    setOrders={setOrders}
                    onClose={() => setIsCreateOrderModalOpen(false)}
                    onNewOrderNotification={onNewOrderNotification}
                    menuItems={menuItems}
                />
            )}

            {selectedOrder && (
                 <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 no-print">
                    <div id="order-details-printable" className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col">
                        <header className="flex justify-between items-center p-4 border-b dark:border-gray-700 sticky top-0 bg-white dark:bg-gray-800 z-10 no-print">
                            <h3 className="text-lg font-bold">Order Details: {selectedOrder.id}</h3>
                            <button onClick={onCloseDetails}><CloseIcon className="w-6 h-6"/></button>
                        </header>
                        <div className="p-4 space-y-4 overflow-y-auto">
                            <div className="pb-4 border-b dark:border-gray-700">
                                <div>
                                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Customer: {selectedOrderCustomer?.name || selectedOrder.customerName}</p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Phone: {selectedOrder.customerPhone || selectedOrderCustomer?.phone || 'N/A'}</p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Email: {selectedOrderCustomer?.email || 'N/A'}</p>
                                    <ul className="mt-2 text-sm">{selectedOrder.items.map(i => <li key={i.name}>{i.quantity} x {i.name}</li>)}</ul>
                                </div>
                                <div className="text-right">
                                    <p className="font-bold text-lg">{currencySymbol}{selectedOrder.total.toFixed(2)}</p>
                                    <div className={`mt-1 inline-block px-2 py-1 rounded-full text-xs font-semibold ${selectedOrder.isPaid ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-gray-200 text-gray-800 dark:bg-gray-600 dark:text-gray-200'}`}>
                                        {selectedOrder.isPaid ? 'Paid' : 'Unpaid'}
                                    </div>
                                </div>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 no-print">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                                    <select
                                        value={selectedOrder.status}
                                        onChange={e => requestUpdateStatus(selectedOrder.id, e.target.value as OrderStatus)}
                                        className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                                    >
                                        {Object.values(OrderStatus).map(s => <option key={s} value={s}>{s}</option>)}
                                    </select>
                                </div>
                                <div>
                                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Assign Agent</label>
                                    <select
                                        value={selectedOrder.deliveryAgentId || ''}
                                        onChange={e => handleAssignAgent(selectedOrder.id, e.target.value)}
                                        className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                                    >
                                        <option value="">Unassigned</option>
                                        {agents.filter(a => a.status === 'available' || a.id === selectedOrder.deliveryAgentId).map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                                    </select>
                                </div>
                            </div>

                            <div className="no-print">
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Payment Method</label>
                                <div className="mt-1 flex flex-col sm:flex-row gap-2">
                                    <select
                                        value={paymentSelectValue || ''}
                                        onChange={e => {
                                            const value = e.target.value;
                                            if (value !== PaymentMethod.OTHER) {
                                                handleUpdatePaymentMethod(selectedOrder.id, value);
                                            } else {
                                                handleUpdatePaymentMethod(selectedOrder.id, '');
                                            }
                                        }}
                                        className="flex-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                                    >
                                        <option value="" disabled>Select a method</option>
                                        {Object.values(PaymentMethod).map(m => <option key={m} value={m}>{m}</option>)}
                                    </select>
                                    
                                    {paymentSelectValue === PaymentMethod.OTHER && (
                                        <input
                                            type="text"
                                            placeholder="Specify other method"
                                            value={isOtherPaymentMethod ? selectedOrder.paymentMethod : ''}
                                            onChange={e => handleUpdatePaymentMethod(selectedOrder.id, e.target.value)}
                                            className="flex-1 block w-full pl-3 py-2 text-base border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                                        />
                                    )}
                                </div>
                            </div>
                            
                            <div className="no-print">
                                <label htmlFor="deliveryAgentNotes" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                    Delivery Agent Notes
                                </label>
                                <textarea
                                    id="deliveryAgentNotes"
                                    rows={3}
                                    className="mt-1 block w-full text-base border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                                    placeholder="e.g., Gate code is #1234. Leave at front porch."
                                    value={selectedOrder.deliveryAgentNotes || ''}
                                    onChange={e => handleUpdateDeliveryAgentNotes(selectedOrder.id, e.target.value)}
                                />
                            </div>

                            {(() => {
                                const agent = agents.find(a => a.id === selectedOrder.deliveryAgentId);
                                if (agent) {
                                    return (
                                        <>
                                            <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                                                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Assigned Agent Details</h4>
                                                <div className="flex items-center justify-between">
                                                    <p className="text-sm text-gray-800 dark:text-gray-200 font-semibold">{agent.name}</p>
                                                    <a href={`tel:${agent.phone}`} className="text-sm text-indigo-600 dark:text-indigo-400 hover:underline">{agent.phone}</a>
                                                </div>
                                            </div>
                                            
                                            {selectedOrder.status === OrderStatus.OUT_FOR_DELIVERY ? (
                                                <div className="no-print"><AgentLocationMap order={selectedOrder} agent={agent} /></div>
                                            ) : (
                                                <div className="mt-4 p-3 bg-gray-100 dark:bg-gray-700 rounded-lg text-center no-print">
                                                    <p className="text-sm text-gray-600 dark:text-gray-300">
                                                        Location tracking will be available once the order is 'Out for Delivery'.
                                                    </p>
                                                </div>
                                            )}
                                        </>
                                    );
                                }
                                return null;
                            })()}
                        </div>
                        <footer className="flex items-center justify-between gap-3 p-4 border-t dark:border-gray-700 sticky bottom-0 bg-white dark:bg-gray-800 z-10 no-print">
                             <button
                                onClick={handlePrintOrder}
                                className="px-4 py-2 flex items-center gap-2 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                            >
                                <PrintIcon className="w-5 h-5"/> Print Order
                            </button>
                            <div className="flex items-center gap-3">
                                <button
                                    onClick={() => handleCancelOrder(selectedOrder.id)}
                                    disabled={selectedOrder.status !== OrderStatus.PENDING && selectedOrder.status !== OrderStatus.CONFIRMED}
                                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                                >
                                    Cancel Order
                                </button>
                                {!selectedOrder.isPaid && (
                                    <button
                                        onClick={() => handleMarkAsPaid(selectedOrder.id)}
                                        className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                                    >
                                        Mark as Paid
                                    </button>
                                )}
                            </div>
                        </footer>
                    </div>
                 </div>
            )}

            {confirmation?.isOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60] p-4 no-print">
                    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
                        <div className="p-6 text-center">
                            <div className={`mx-auto flex items-center justify-center h-12 w-12 rounded-full ${confirmation.title.includes('Cancel') ? 'bg-red-100 dark:bg-red-900/50' : 'bg-blue-100 dark:bg-blue-900/50'}`}>
                                <AlertTriangleIcon className={`h-6 w-6 ${confirmation.title.includes('Cancel') ? 'text-red-600 dark:text-red-300' : 'text-blue-600 dark:text-blue-300'}`} />
                            </div>
                            <h3 className="mt-5 text-lg font-medium text-gray-900 dark:text-white">{confirmation.title}</h3>
                            <div className="mt-2">
                                <p className="text-sm text-gray-500 dark:text-gray-400">{confirmation.message}</p>
                            </div>
                        </div>
                        <div className="flex justify-center gap-3 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-b-lg">
                            <button
                                type="button"
                                onClick={() => setConfirmation(null)}
                                className="px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                onClick={() => {
                                    confirmation.onConfirm();
                                    setConfirmation(null);
                                }}
                                className={`px-4 py-2 text-white rounded-md transition-colors ${
                                    confirmation.title.includes('Cancel')
                                    ? 'bg-red-600 hover:bg-red-700'
                                    : 'bg-indigo-600 hover:bg-indigo-700'
                                }`}
                            >
                                Confirm
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default OrderList;