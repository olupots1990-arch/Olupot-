import React, { useState, useMemo } from 'react';
import type { User, UserRole } from '../types';
import { UserPlusIcon, EditIcon, TrashIcon, CloseIcon, AlertTriangleIcon } from './icons';

interface UserManagementProps {
    users: User[];
    setUsers: React.Dispatch<React.SetStateAction<User[]>>;
    currentUser: User;
}

const UserManagement: React.FC<UserManagementProps> = ({ users, setUsers, currentUser }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingUser, setEditingUser] = useState<User | null>(null);
    const [userToDelete, setUserToDelete] = useState<User | null>(null);

    const openModal = (user: User | null = null) => {
        setEditingUser(user);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setEditingUser(null);
        setIsModalOpen(false);
    };

    const handleSaveUser = (user: User) => {
        if (editingUser) {
            // Update existing user
            setUsers(prev => prev.map(u => (u.id === user.id ? user : u)));
        } else {
            // Add new user
            const newUser = { ...user, id: `user-${Date.now()}` };
            setUsers(prev => [...prev, newUser]);
        }
        closeModal();
    };

    const handleDeleteUser = () => {
        if (userToDelete) {
            setUsers(prev => prev.filter(u => u.id !== userToDelete.id));
            setUserToDelete(null);
        }
    };

    const roleColors: Record<UserRole, string> = {
        admin: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
        manager: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
        supervisor: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
        deliveryAgent: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
        customer: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    };

    const PERMISSIONS = useMemo(() => ({
        canManage: (targetUser: User): boolean => {
            if (currentUser.role === 'admin') return true;
            if (currentUser.role === 'manager') return targetUser.role !== 'admin';
            if (currentUser.role === 'supervisor') return ['deliveryAgent', 'customer'].includes(targetUser.role);
            return false;
        }
    }), [currentUser.role]);
    
    const visibleUsers = useMemo(() => users.filter(user => {
        if (currentUser.role === 'admin') return true;
        if (currentUser.role === 'manager') return user.role !== 'admin';
        if (currentUser.role === 'supervisor') return ['deliveryAgent', 'customer', 'supervisor'].includes(user.role);
        return false;
    }), [users, currentUser.role]);

    return (
        <div className="bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">User Accounts</h2>
                <button
                    onClick={() => openModal(null)}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700"
                >
                    <UserPlusIcon className="w-5 h-5" />
                    Add User
                </button>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3">Name</th>
                            <th scope="col" className="px-6 py-3">Email</th>
                            <th scope="col" className="px-6 py-3">Role</th>
                            <th scope="col" className="px-6 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {visibleUsers.map(user => (
                            <tr key={user.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">{user.name}</td>
                                <td className="px-6 py-4">{user.email}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-semibold capitalize ${roleColors[user.role]}`}>
                                        {user.role === 'deliveryAgent' ? 'Delivery Agent' : user.role}
                                    </span>
                                </td>
                                <td className="px-6 py-4 flex items-center space-x-3">
                                    <button
                                        onClick={() => openModal(user)}
                                        className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 disabled:text-gray-400 disabled:cursor-not-allowed"
                                        disabled={!PERMISSIONS.canManage(user) || user.id === currentUser.id}
                                    >
                                        <EditIcon className="w-5 h-5" />
                                    </button>
                                    <button
                                        onClick={() => setUserToDelete(user)}
                                        className="text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 disabled:text-gray-400 disabled:cursor-not-allowed"
                                        disabled={!PERMISSIONS.canManage(user) || user.id === currentUser.id}
                                    >
                                        <TrashIcon className="w-5 h-5" />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {isModalOpen && <UserFormModal user={editingUser} onSave={handleSaveUser} onClose={closeModal} currentUserRole={currentUser.role} />}
            
            {userToDelete && (
                 <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
                    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
                        <div className="p-6 text-center">
                            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 dark:bg-red-900/50">
                                <AlertTriangleIcon className="h-6 w-6 text-red-600 dark:text-red-300" />
                            </div>
                            <h3 className="mt-5 text-lg font-medium text-gray-900 dark:text-white">Delete User</h3>
                            <div className="mt-2">
                                <p className="text-sm text-gray-500 dark:text-gray-400">
                                    Are you sure you want to delete {userToDelete.name}? This action cannot be undone.
                                </p>
                            </div>
                        </div>
                        <div className="flex justify-center gap-3 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-b-lg">
                            <button onClick={() => setUserToDelete(null)} className="px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600">
                                Cancel
                            </button>
                            <button onClick={handleDeleteUser} className="px-4 py-2 text-white bg-red-600 rounded-md hover:bg-red-700">
                                Delete
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const UserFormModal: React.FC<{ user: User | null; onSave: (user: User) => void; onClose: () => void; currentUserRole: UserRole }> = ({ user, onSave, onClose, currentUserRole }) => {
    
    const ASSIGNABLE_ROLES: Record<UserRole, UserRole[]> = {
        admin: ['admin', 'manager', 'supervisor', 'deliveryAgent', 'customer'],
        manager: ['manager', 'supervisor', 'deliveryAgent', 'customer'],
        supervisor: ['deliveryAgent', 'customer'],
        deliveryAgent: [],
        customer: [],
    };

    const availableRoles = ASSIGNABLE_ROLES[currentUserRole] || [];
    
    const [formData, setFormData] = useState<User>(user || { id: '', name: '', email: '', role: availableRoles[0] || 'customer', password: '' });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">{user ? 'Edit User' : 'Add New User'}</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </header>
                <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium">Full Name</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium">Email Address</label>
                        <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium">{user ? 'New Password (optional)' : 'Password'}</label>
                        <input type="password" name="password" id="password" value={formData.password} onChange={handleChange} required={!user} className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                     <div>
                        <label htmlFor="phone" className="block text-sm font-medium">Phone (Optional)</label>
                        <input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleChange} className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <div>
                        <label htmlFor="role" className="block text-sm font-medium">Role</label>
                        <select name="role" id="role" value={formData.role} onChange={handleChange} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600">
                           {availableRoles.map(role => (
                                <option key={role} value={role} className="capitalize">
                                    {role === 'deliveryAgent' ? 'Delivery Agent' : role}
                                </option>
                            ))}
                        </select>
                    </div>
                    <footer className="flex justify-end gap-3 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 rounded-md">Cancel</button>
                        <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save</button>
                    </footer>
                </form>
            </div>
        </div>
    );
};

export default UserManagement;
