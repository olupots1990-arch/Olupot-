import React, { useState } from 'react';
import type { DeploymentLog } from '../types';
import { CheckCircleIcon, CogIcon, UploadCloudIcon } from './icons';

interface DeploymentManagementProps {
    deploymentHistory: DeploymentLog[];
    setDeploymentHistory: React.Dispatch<React.SetStateAction<DeploymentLog[]>>;
    domainName: string;
}

const DeploymentManagement: React.FC<DeploymentManagementProps> = ({ deploymentHistory, setDeploymentHistory, domainName }) => {
    const [isDeploying, setIsDeploying] = useState(false);
    const [deployStatus, setDeployStatus] = useState('');

    const lastDeployment = deploymentHistory[0];

    const handleRedeploy = () => {
        setIsDeploying(true);
        const newDeployment: DeploymentLog = {
            id: `dep-${Date.now()}`,
            timestamp: new Date(),
            status: 'In Progress',
            trigger: 'Manual deploy from Admin Panel'
        };
        setDeploymentHistory(prev => [newDeployment, ...prev]);

        const steps = [
            'Connecting to build server (build.stanleycafe.com)...',
            'Running linting and security checks...',
            'Building production application container (v1.2.5)...',
            'Pushing image to global container registry...',
            'Connecting to web server cluster...',
            `Performing rolling update to ${domainName}...`,
            'Running health checks on new version...',
            'Deployment successful! Your changes are live.',
        ];
        
        let stepIndex = 0;
        const interval = setInterval(() => {
            setDeployStatus(steps[stepIndex]);
            stepIndex++;
            if (stepIndex >= steps.length) {
                clearInterval(interval);
                setIsDeploying(false);
                setDeployStatus('');
                setDeploymentHistory(prev => prev.map(d => d.id === newDeployment.id ? { ...d, status: 'Success' } : d));
            }
        }, 1500);
    };

    const statusColors = {
        'Success': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
        'In Progress': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 animate-pulse',
        'Failed': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
    };

    return (
        <div className="p-6 space-y-6">
            <header>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Deployment & Live Status</h2>
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                    Manage your website's deployment status and view its history.
                </p>
            </header>

            <div className="space-y-4 pt-4 border-t dark:border-gray-700">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Live Website Status</h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-900/40 rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                        <p className="font-semibold text-gray-800 dark:text-gray-200">Domain</p>
                        <a href={`https://${domainName}`} target="_blank" rel="noopener noreferrer" className="font-mono text-sm text-indigo-600 dark:text-indigo-400 hover:underline">
                            {domainName}
                        </a>
                    </div>
                     <div className="flex items-center justify-between">
                        <p className="font-semibold text-gray-800 dark:text-gray-200">Status</p>
                        <span className="px-2 py-1 text-xs font-medium text-green-800 bg-green-100 rounded-full dark:bg-green-900 dark:text-green-200 flex items-center gap-1.5">
                           <CheckCircleIcon className="w-3.5 h-3.5" /> Live
                        </span>
                    </div>
                     <div className="flex items-center justify-between">
                        <p className="font-semibold text-gray-800 dark:text-gray-200">Last Deployed</p>
                        <span className="text-sm text-gray-600 dark:text-gray-300">
                            {lastDeployment.timestamp.toLocaleString()}
                        </span>
                    </div>
                </div>
                <div className="pt-2">
                    <button 
                        onClick={handleRedeploy}
                        disabled={isDeploying}
                        className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700 disabled:bg-indigo-400 disabled:cursor-wait"
                    >
                        <UploadCloudIcon className={`w-5 h-5 ${isDeploying ? 'animate-pulse' : ''}`} />
                        {isDeploying ? 'Deployment in Progress...' : 'Deploy to Production'}
                    </button>
                    {isDeploying && <p className="text-center text-sm text-gray-500 mt-2">{deployStatus}</p>}
                </div>
            </div>

            <div className="space-y-4 pt-4 border-t dark:border-gray-700">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Deployment History</h3>
                <div className="overflow-x-auto border border-gray-200 dark:border-gray-700 rounded-lg max-h-80 overflow-y-auto">
                    <table className="w-full text-sm text-left">
                         <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400 sticky top-0">
                            <tr>
                                <th className="px-4 py-3">Timestamp</th>
                                <th className="px-4 py-3">Status</th>
                                <th className="px-4 py-3">Trigger</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                            {deploymentHistory.map(log => (
                                <tr key={log.id}>
                                    <td className="px-4 py-2 whitespace-nowrap">{log.timestamp.toLocaleString()}</td>
                                    <td className="px-4 py-2">
                                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${statusColors[log.status]}`}>
                                            {log.status}
                                        </span>
                                    </td>
                                    <td className="px-4 py-2">{log.trigger}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default DeploymentManagement;
