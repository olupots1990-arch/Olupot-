import React from 'react';
import HomePage from './HomePage';
import OrderPage from './OrderPage';
import ContactPage from './ContactPage';
import GalleryPage from './GalleryPage';
import { HomeIcon, MessageSquareIcon, PhoneIcon, ImageIcon } from './icons';
import type { BackgroundMedia, LocationInfo, Advertisement, AiAssistantSettings, MenuItem } from '../types';
import type { Page } from '../App';
import { DEFAULT_BACKGROUND_VIDEO } from '../constants';

interface WebsiteViewProps {
  backgroundVideos: (BackgroundMedia | null)[];
  backgroundImages: (BackgroundMedia | null)[];
  backgroundMusicUrl: string | null;
  location: LocationInfo;
  activePage: Page;
  setActivePage: (page: Page) => void;
  advertisements: Advertisement[];
  galleryProductIds: string[];
  menuItems: MenuItem[];
  initialChatMessage: string | null;
  setInitialChatMessage: React.Dispatch<React.SetStateAction<string | null>>;
  isOnline: boolean;
  aiSettings: AiAssistantSettings;
}

const WebsiteView: React.FC<WebsiteViewProps> = ({ 
  backgroundVideos, 
  backgroundImages, 
  backgroundMusicUrl, 
  location, 
  activePage, 
  setActivePage, 
  advertisements,
  galleryProductIds,
  menuItems,
  initialChatMessage,
  setInitialChatMessage,
  isOnline,
  aiSettings
}) => {
  const renderContent = () => {
    switch (activePage) {
      case 'home':
        return <HomePage backgroundVideos={backgroundVideos} backgroundImages={backgroundImages} backgroundMusicUrl={backgroundMusicUrl} onNavigate={() => setActivePage('order')} advertisements={advertisements} menuItems={menuItems} />;
      case 'order':
        return <OrderPage 
                  initialChatMessage={initialChatMessage}
                  setInitialChatMessage={setInitialChatMessage}
                  isOnline={isOnline}
                  backgroundMediaUrl={backgroundImages.find(i => i !== null)?.url || DEFAULT_BACKGROUND_VIDEO}
                  aiSettings={aiSettings}
                  menuItems={menuItems}
                />;
      case 'gallery':
        return <GalleryPage 
                galleryProductIds={galleryProductIds}
                menuItems={menuItems}
                setActivePage={setActivePage}
                setInitialChatMessage={setInitialChatMessage}
              />;
      case 'contact':
        return <ContactPage location={location} />;
      default:
        return <HomePage backgroundVideos={backgroundVideos} backgroundImages={backgroundImages} backgroundMusicUrl={backgroundMusicUrl} onNavigate={() => setActivePage('order')} advertisements={advertisements} menuItems={menuItems} />;
    }
  };

  const NavButton: React.FC<{ page: Page, icon: React.ReactNode, label: string }> = ({ page, icon, label }) => (
    <button
      onClick={() => setActivePage(page)}
      className={`flex flex-col items-center justify-center w-full py-2 transition-colors duration-200 ${
        activePage === page ? 'text-indigo-500' : 'text-gray-500 hover:text-indigo-400'
      }`}
    >
      {icon}
      <span className="text-xs font-medium">{label}</span>
    </button>
  );

  return (
    <div className="h-[calc(100vh-68px)] relative">
      <div className="absolute inset-0 overflow-y-auto pb-14 md:pb-0">
        {renderContent()}
      </div>

      <nav className="flex md:hidden fixed bottom-0 left-0 right-0 z-20 justify-around bg-white dark:bg-gray-800 shadow-t-md border-t dark:border-gray-700">
        <NavButton page="home" icon={<HomeIcon className="w-6 h-6" />} label="Home" />
        <NavButton page="order" icon={<MessageSquareIcon className="w-6 h-6" />} label="Order" />
        <NavButton page="gallery" icon={<ImageIcon className="w-6 h-6" />} label="Gallery" />
        <NavButton page="contact" icon={<PhoneIcon className="w-6 h-6" />} label="Contact" />
      </nav>
    </div>
  );
};

export default WebsiteView;
