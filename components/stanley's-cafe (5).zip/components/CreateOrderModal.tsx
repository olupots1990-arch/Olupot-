import React, { useState, useMemo } from 'react';
import type { User, Order, MenuItem } from '../types';
import { OrderStatus, PaymentMethod } from '../types';
import { CloseIcon } from './icons';

interface CreateOrderModalProps {
    users: User[];
    setOrders: React.Dispatch<React.SetStateAction<Order[]>>;
    onClose: () => void;
    onNewOrderNotification: (order: Order) => void;
    menuItems: MenuItem[];
}

export const CreateOrderModal: React.FC<CreateOrderModalProps> = ({ users, setOrders, onClose, onNewOrderNotification, menuItems }) => {
    const [selectedCustomerId, setSelectedCustomerId] = useState('');
    const [orderItems, setOrderItems] = useState<Record<string, number>>({});
    const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(PaymentMethod.CASH);

    const customers = useMemo(() => users.filter(u => u.role === 'customer'), [users]);

    const handleItemQuantityChange = (itemId: string, quantity: number) => {
        setOrderItems(prev => {
            const newItems = { ...prev };
            if (quantity > 0) {
                newItems[itemId] = quantity;
            } else {
                delete newItems[itemId];
            }
            return newItems;
        });
    };

    const total = useMemo(() => {
        return Object.entries(orderItems).reduce((acc, [itemId, quantity]) => {
            const menuItem = menuItems.find(item => item.id === itemId);
            return acc + (menuItem ? menuItem.price * Number(quantity) : 0);
        }, 0);
    }, [orderItems, menuItems]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const customer = users.find(u => u.id === selectedCustomerId);
        if (!customer || Object.keys(orderItems).length === 0) {
            alert("Please select a customer and add at least one item.");
            return;
        }

        const newOrder: Order = {
            id: `ORD-${Date.now().toString().slice(-5)}`,
            customerId: customer.id,
            customerName: customer.name,
            customerPhone: customer.phone,
            items: Object.entries(orderItems).map(([itemId, quantity]) => {
                const menuItem = menuItems.find(item => item.id === itemId)!;
                return { name: menuItem.name, quantity: Number(quantity) };
            }),
            total: total,
            status: OrderStatus.PENDING,
            timestamp: new Date(),
            isPaid: false,
            paymentMethod: paymentMethod,
            isNew: true,
        };
        
        setOrders(prev => [newOrder, ...prev]);
        onNewOrderNotification(newOrder);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[60] p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">Create New Order</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6"/></button>
                </header>
                <form onSubmit={handleSubmit} className="flex-1 flex flex-col overflow-hidden">
                    <div className="p-6 space-y-4 overflow-y-auto">
                        <div>
                            <label htmlFor="customer" className="block text-sm font-medium">Customer</label>
                            <select id="customer" value={selectedCustomerId} onChange={e => setSelectedCustomerId(e.target.value)} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600">
                                <option value="" disabled>Select a customer</option>
                                {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                        </div>
                        <div>
                            <h4 className="text-sm font-medium mb-2">Order Items</h4>
                            <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                                {menuItems.map(item => (
                                    <div key={item.id} className="flex justify-between items-center">
                                        <span>{item.name}</span>
                                        <input 
                                            type="number" 
                                            min="0"
                                            value={orderItems[item.id] || 0}
                                            onChange={e => handleItemQuantityChange(item.id, parseInt(e.target.value, 10) || 0)}
                                            className="w-20 p-1 text-center border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                                        />
                                    </div>
                                ))}
                            </div>
                        </div>
                         <div>
                            <label htmlFor="paymentMethod" className="block text-sm font-medium">Payment Method</label>
                            <select id="paymentMethod" value={paymentMethod} onChange={e => setPaymentMethod(e.target.value as PaymentMethod)} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600">
                                {Object.values(PaymentMethod).map(method => <option key={method} value={method}>{method}</option>)}
                            </select>
                        </div>
                    </div>
                    <footer className="flex justify-between items-center p-4 border-t dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                        <span className="text-xl font-bold">Total: {total.toFixed(2)}</span>
                        <button type="submit" className="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 disabled:opacity-50" disabled={!selectedCustomerId || total === 0}>
                            Create Order
                        </button>
                    </footer>
                </form>
            </div>
        </div>
    );
};