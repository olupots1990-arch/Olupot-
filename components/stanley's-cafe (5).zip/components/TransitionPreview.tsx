import React, { useState, useEffect, useCallback } from 'react';
import type { BackgroundMedia } from '../types';
import { CloseIcon } from './icons';

interface TransitionPreviewProps {
    mediaItems: BackgroundMedia[];
    startIndex: number;
    onClose: () => void;
}

const isVideo = (url: string) => /\.(mp4|webm|ogg|mov)$/i.test(url) || url.startsWith('blob:');

const TransitionPreview: React.FC<TransitionPreviewProps> = ({ mediaItems, startIndex, onClose }) => {
    const [currentIndex, setCurrentIndex] = useState(startIndex);
    const [exitingIndex, setExitingIndex] = useState<number | null>(null);
    const [isAnimating, setIsAnimating] = useState(false);
    
    const playTransition = useCallback(() => {
        if (isAnimating || mediaItems.length < 2) return;
        setIsAnimating(true);
        
        const nextIndex = (currentIndex + 1) % mediaItems.length;
        
        const outgoingMedia = mediaItems[currentIndex];
        const duration = (outgoingMedia.transitionDuration || 1.5) * 1000;

        setExitingIndex(currentIndex);
        setCurrentIndex(nextIndex);

        setTimeout(() => {
            setExitingIndex(null);
            setIsAnimating(false);
        }, duration);
    }, [isAnimating, currentIndex, mediaItems]);

    useEffect(() => {
        const timer = setTimeout(playTransition, 100);
        return () => clearTimeout(timer);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    if (mediaItems.length < 2) {
        return (
             <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-[70] p-4">
                 <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center shadow-xl">
                    <p className="font-semibold">Cannot Preview Transition</p>
                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">You need at least two different media items in the slideshow to preview a transition.</p>
                    <button onClick={onClose} className="mt-4 px-4 py-2 bg-indigo-500 text-white rounded-md text-sm font-medium hover:bg-indigo-600">
                        Close
                    </button>
                 </div>
            </div>
        )
    }

    const exitingMedia = exitingIndex !== null ? mediaItems[exitingIndex] : null;
    const transitionType = exitingMedia?.transitionType || 'fade';
    const transitionDuration = exitingMedia?.transitionDuration || 1.5;

    const PreviewItem: React.FC<{ media: BackgroundMedia; isActive: boolean; isExiting: boolean; }> = ({ media, isActive, isExiting }) => {
        let animationClass = '';
        if (isActive && exitingIndex !== null) { // Animating IN
            switch(transitionType) {
                case 'slide': animationClass = 'animate-slide-in-new'; break;
                case 'zoom': animationClass = 'animate-zoom-in'; break;
                case 'rotate': animationClass = 'animate-rotate-in'; break;
                default: animationClass = 'animate-fade-in'; break;
            }
        }
        if (isExiting) { // Animating OUT
            switch(transitionType) {
                case 'slide': animationClass = 'animate-slide-out-old'; break;
                case 'zoom': animationClass = 'animate-zoom-out'; break;
                case 'rotate': animationClass = 'animate-rotate-out'; break;
                default: animationClass = 'animate-fade-out'; break;
            }
        }
        
        if (!isActive && !isExiting) return null;

        return (
            <div
                className={`absolute inset-0 w-full h-full ${animationClass}`}
                style={{
                  animationDuration: `${transitionDuration}s`,
                  zIndex: isExiting ? 1 : 2,
                }}
            >
                {isVideo(media.url) ? <video key={media.url} className="w-full h-full object-cover" src={media.url} autoPlay loop muted playsInline />
                                 : <img src={media.url} className="w-full h-full object-cover" alt="Preview background" />}
            </div>
        );
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-[70] p-4" onClick={onClose}>
            <div className="relative w-full max-w-2xl aspect-video bg-black rounded-lg overflow-hidden shadow-2xl" onClick={e => e.stopPropagation()}>
                <style>{`
                    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } } .animate-fade-in { animation: fadeIn ease-in-out forwards; }
                    @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } } .animate-fade-out { animation: fadeOut ease-in-out forwards; }
                    @keyframes slideInNew { from { transform: translateX(100%); } to { transform: translateX(0); } } .animate-slide-in-new { animation: slideInNew ease-in-out forwards; }
                    @keyframes slideOutOld { from { transform: translateX(0); } to { transform: translateX(-100%); } } .animate-slide-out-old { animation: slideOutOld ease-in-out forwards; }
                    @keyframes zoomIn { from { transform: scale(1.2); opacity: 0; } to { transform: scale(1); opacity: 1; } } .animate-zoom-in { animation: zoomIn ease-in-out forwards; }
                    @keyframes zoomOut { from { transform: scale(1); opacity: 1; } to { transform: scale(0.8); opacity: 0; } } .animate-zoom-out { animation: zoomOut ease-in-out forwards; }
                    @keyframes rotateIn { from { transform: rotate(-25deg) scale(0.7); opacity: 0; } to { transform: rotate(0) scale(1); opacity: 1; } } .animate-rotate-in { animation: rotateIn cubic-bezier(0.25, 1, 0.5, 1) forwards; }
                    @keyframes rotateOut { from { transform: rotate(0) scale(1); opacity: 1; } to { transform: rotate(25deg) scale(0.7); opacity: 0; } } .animate-rotate-out { animation: rotateOut cubic-bezier(0.5, 0, 0.75, 0) forwards; }
                `}</style>

                {mediaItems.map((media, index) => 
                    <PreviewItem 
                      key={`${index}-${media.url}`} 
                      media={media} 
                      isActive={index === currentIndex} 
                      isExiting={index === exitingIndex}
                    />
                )}

                <div className="absolute top-2 right-2 z-30">
                     <button onClick={onClose} className="p-1.5 bg-black/50 rounded-full text-white hover:bg-black/80 transition-colors">
                        <CloseIcon className="w-5 h-5" />
                     </button>
                </div>
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-4 p-2 bg-black/50 rounded-lg backdrop-blur-sm">
                    <p className="text-white text-sm">Preview: <span className="font-bold capitalize">{transitionType}</span> ({transitionDuration}s)</p>
                    <button onClick={playTransition} disabled={isAnimating} className="px-3 py-1 text-sm bg-indigo-500 text-white rounded hover:bg-indigo-600 disabled:bg-indigo-300">
                        {isAnimating ? 'Playing...' : 'Replay'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default TransitionPreview;