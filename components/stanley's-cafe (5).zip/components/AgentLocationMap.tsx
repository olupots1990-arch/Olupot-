import React, { useState, useEffect } from 'react';
import type { Order, DeliveryAgent } from '../types';
import { TruckIcon } from './icons';

interface AgentLocationMapProps {
    order: Order;
    agent: DeliveryAgent;
}

const AgentLocationMap: React.FC<AgentLocationMapProps> = ({ order, agent }) => {
    const [position, setPosition] = useState<{ top: number; left: number }>({ top: 50, left: 50 });

    useEffect(() => {
        // Start with a random position
        setPosition({
            top: Math.random() * 80 + 10,
            left: Math.random() * 80 + 10,
        });

        // Simulate movement
        const interval = setInterval(() => {
            setPosition(prev => ({
                top: Math.max(0, Math.min(100, prev.top + (Math.random() - 0.5) * 4)),
                left: Math.max(0, Math.min(100, prev.left + (Math.random() - 0.5) * 4)),
            }));
        }, 2000);

        return () => clearInterval(interval);
    }, [order.id]); // Re-initialize if the order changes

    return (
        <div className="mt-4">
            <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Agent Location</h4>
            <div className="w-full h-48 bg-gray-200 dark:bg-gray-700 rounded-lg shadow-inner relative overflow-hidden">
                {/* Mock Map Background */}
                <div className="absolute inset-0 bg-map-pattern opacity-20"></div>
                <style>{`.bg-map-pattern { background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%239C92AC' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E"); }`}</style>
                
                <div 
                    className="absolute transition-all duration-1000 ease-linear" 
                    style={{ top: `${position.top}%`, left: `${position.left}%`, transform: 'translate(-50%, -50%)' }}
                >
                    <div className="relative group">
                        <TruckIcon className="w-8 h-8 text-indigo-500" />
                        <div className="absolute bottom-full mb-2 w-max bg-white dark:bg-gray-800 p-2 rounded-md shadow-lg text-xs opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                            <p className="font-bold">{agent.name}</p>
                            <p>Order: {order.id}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AgentLocationMap;
