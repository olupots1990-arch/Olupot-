import React, { useState, useMemo } from 'react';
import type { Order, DeliveryAgent, MenuItem } from '../types';
import { DownloadIcon, PrintIcon } from './icons';

interface FinanceManagementProps {
    orders: Order[];
    agents: DeliveryAgent[];
    globalCommissionRate: number;
    currencySymbol: string;
    menuItems: MenuItem[];
}

type TimeRange = 'today' | 'week' | 'month';

const downloadCsv = (filename: string, csvContent: string) => {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
};

const FinanceManagement: React.FC<FinanceManagementProps> = ({ orders, agents, globalCommissionRate, currencySymbol, menuItems }) => {
    const [timeRange, setTimeRange] = useState<TimeRange>('week');
    const [currentPage, setCurrentPage] = useState(1);
    const transactionsPerPage = 10;

    const {
        filteredOrders,
        totalRevenue,
        totalCommissions,
        netProfit,
        numberOfOrders,
        averageOrderValue,
        productPerformance,
        topProducts,
        maxRevenue,
    } = useMemo(() => {
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

        let startDate: Date;
        switch (timeRange) {
            case 'today':
                startDate = today;
                break;
            case 'month':
                startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 30);
                break;
            case 'week':
            default:
                startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6);
                break;
        }

        const filtered = orders.filter(o => o.timestamp >= startDate);
        const numberOfOrders = filtered.length;
        const revenue = filtered.reduce((acc, o) => o.isPaid ? acc + o.total : acc, 0);
        const averageOrderValue = numberOfOrders > 0 ? revenue / numberOfOrders : 0;
        
        const commissions = filtered
            .filter(o => o.isPaid && o.status === 'Delivered' && o.deliveryAgentId)
            .reduce((acc, o) => {
                const agent = agents.find(a => a.id === o.deliveryAgentId);
                const rate = (agent?.commissionRate ?? globalCommissionRate) / 100;
                return acc + (o.total * rate);
            }, 0);

        const netProfit = revenue - commissions;

        const productSales: Record<string, { quantity: number; revenue: number }> = {};
        const menuItemsMap = new Map(menuItems.map(item => [item.name, item.price]));

        filtered.forEach(order => {
            if (order.isPaid) {
                order.items.forEach(item => {
                    // FIX: price and quantity can be strings from older data, so they need to be cast to Numbers for arithmetic operations.
                    const price = Number(menuItemsMap.get(item.name)) || 0;
                    if (!productSales[item.name]) {
                        productSales[item.name] = { quantity: 0, revenue: 0 };
                    }
                    productSales[item.name].quantity += Number(item.quantity);
                    productSales[item.name].revenue += Number(item.quantity) * price;
                });
            }
        });

        const perfData = Object.entries(productSales)
            .map(([name, data]) => ({ name, ...data }))
            .sort((a, b) => b.revenue - a.revenue);

        const top5 = perfData.slice(0, 5);
        const maxRev = top5.length > 0 ? top5[0].revenue : 0;

        return {
            filteredOrders: filtered.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()),
            totalRevenue: revenue,
            totalCommissions: commissions,
            netProfit,
            numberOfOrders,
            averageOrderValue,
            productPerformance: perfData,
            topProducts: top5,
            maxRevenue: maxRev,
        };

    }, [orders, timeRange, agents, globalCommissionRate, menuItems]);

    const paginatedTransactions = filteredOrders.slice(
        (currentPage - 1) * transactionsPerPage,
        currentPage * transactionsPerPage
    );
    const totalPages = Math.ceil(filteredOrders.length / transactionsPerPage);
    
    const handleExportSummary = () => {
        const rows = [
            ['Metric', 'Value'],
            [`Time Range`, timeRange],
            ['Total Revenue', totalRevenue.toFixed(2)],
            ['Total Commissions', totalCommissions.toFixed(2)],
            ['Net Profit', netProfit.toFixed(2)]
        ];
        const csvContent = rows.map(e => e.join(",")).join("\n");
        downloadCsv(`financial_summary_${timeRange}_${new Date().toISOString().split('T')[0]}.csv`, csvContent);
    };

    const handleExportProducts = () => {
        const headers = ['Product Name', 'Quantity Sold', `Total Revenue (${currencySymbol})`];
        const rows = productPerformance.map(p => [p.name, p.quantity, p.revenue.toFixed(2)]);
        const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
        downloadCsv(`product_performance_${timeRange}_${new Date().toISOString().split('T')[0]}.csv`, csvContent);
    };

    const handleExportTransactions = () => {
        const headers = ['Order ID', 'Date', 'Customer', 'Total', 'Payment Status', 'Payment Method', 'Commission'];
        const csvRows = filteredOrders.map(o => {
            const agent = agents.find(a => a.id === o.deliveryAgentId);
            const rate = (agent?.commissionRate ?? globalCommissionRate) / 100;
            const commission = (o.status === 'Delivered' && o.isPaid) ? (o.total * rate).toFixed(2) : '0.00';
            return [o.id, o.timestamp.toLocaleString(), o.customerName, o.total.toFixed(2), o.isPaid ? 'Paid' : 'Unpaid', o.paymentMethod || 'N/A', commission].join(',');
        });
        const csvContent = [headers.join(','), ...csvRows].join('\n');
        downloadCsv(`transaction_history_${timeRange}_${new Date().toISOString().split('T')[0]}.csv`, csvContent);
    };
    
    const handlePrint = () => {
        window.print();
    };

    return (
        <div className="p-6 bg-white dark:bg-gray-800 rounded-lg shadow space-y-8">
            <header className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <div>
                    <h3 className="text-2xl font-bold">Sales & Finance Dashboard</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 no-print">
                        Displaying data for the last <span className="font-semibold">{timeRange === 'today' ? '24 hours' : (timeRange === 'week' ? '7 days' : '30 days')}</span>.
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    <div className="flex bg-gray-100 dark:bg-gray-700 p-1 rounded-md no-print">
                        {(['today', 'week', 'month'] as TimeRange[]).map(range => (
                            <button key={range} onClick={() => setTimeRange(range)} className={`px-3 py-1 text-sm font-medium rounded capitalize ${timeRange === range ? 'bg-indigo-500 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}>
                                {range}
                            </button>
                        ))}
                    </div>
                    <button onClick={handlePrint} className="no-print p-2 bg-gray-100 dark:bg-gray-700 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600">
                        <PrintIcon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                    </button>
                </div>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
                 <div className="p-4 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <p className="text-sm text-blue-700 dark:text-blue-300">Total Sales</p>
                    <p className="text-3xl font-bold text-blue-800 dark:text-blue-200">{currencySymbol}{totalRevenue.toFixed(2)}</p>
                </div>
                <div className="p-4 bg-teal-100 dark:bg-teal-900 rounded-lg">
                    <p className="text-sm text-teal-700 dark:text-teal-300">Number of Orders</p>
                    <p className="text-3xl font-bold text-teal-800 dark:text-teal-200">{numberOfOrders}</p>
                </div>
                <div className="p-4 bg-purple-100 dark:bg-purple-900 rounded-lg">
                    <p className="text-sm text-purple-700 dark:text-purple-300">Average Order Value</p>
                    <p className="text-3xl font-bold text-purple-800 dark:text-purple-200">{currencySymbol}{averageOrderValue.toFixed(2)}</p>
                </div>
                <div className="p-4 bg-green-100 dark:bg-green-900 rounded-lg">
                    <p className="text-sm text-green-700 dark:text-green-300">Net Profit</p>
                    <p className="text-3xl font-bold text-green-800 dark:text-green-200">{currencySymbol}{netProfit.toFixed(2)}</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    <div>
                        <h4 className="text-lg font-semibold mb-3">Top Sellers by Revenue ({timeRange})</h4>
                        <div className="space-y-4 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
                             {topProducts.length > 0 ? topProducts.map(p => (
                                <div key={p.name} className="flex items-center text-sm">
                                    <div className="w-1/3 truncate pr-2 font-medium text-gray-700 dark:text-gray-300">{p.name}</div>
                                    <div className="w-2/3">
                                        <div className="bg-gray-200 dark:bg-gray-700 rounded-full h-6 flex items-center" title={`${currencySymbol}${p.revenue.toFixed(2)}`}>
                                            <div 
                                                className="bg-indigo-500 h-6 rounded-full text-white text-xs flex items-center justify-end px-2"
                                                style={{ width: `${maxRevenue > 0 ? (p.revenue / maxRevenue) * 100 : 0}%` }}
                                            >
                                                <span className="font-bold">{currencySymbol}{p.revenue.toFixed(2)}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )) : (
                                <p className="text-center py-4 text-gray-500">No sales data for this period.</p>
                            )}
                        </div>
                    </div>
                    <div>
                        <h4 className="text-lg font-semibold mb-3">All Best-Sellers ({timeRange})</h4>
                        <div className="overflow-x-auto border border-gray-200 dark:border-gray-700 rounded-lg max-h-60 overflow-y-auto">
                            <table className="w-full text-sm">
                                <thead className="bg-gray-50 dark:bg-gray-700 sticky top-0">
                                    <tr>
                                        <th className="px-4 py-2 text-left font-medium text-gray-600 dark:text-gray-300">Product</th>
                                        <th className="px-4 py-2 text-center font-medium text-gray-600 dark:text-gray-300">Qty</th>
                                        <th className="px-4 py-2 text-right font-medium text-gray-600 dark:text-gray-300">Revenue</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                                    {productPerformance.length > 0 ? productPerformance.map(p => (
                                        <tr key={p.name}>
                                            <td className="px-4 py-2 whitespace-nowrap font-medium">{p.name}</td>
                                            <td className="px-4 py-2 text-center whitespace-nowrap">{p.quantity}</td>
                                            <td className="px-4 py-2 text-right whitespace-nowrap">{currencySymbol}{p.revenue.toFixed(2)}</td>
                                        </tr>
                                    )) : (
                                        <tr>
                                            <td colSpan={3} className="text-center py-10 text-gray-500">No product sales data for this period.</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div className="lg:col-span-3">
                    <h4 className="text-lg font-semibold mb-3">Transaction History ({timeRange})</h4>
                    <div className="overflow-x-auto border border-gray-200 dark:border-gray-700 rounded-lg max-h-96 overflow-y-auto">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-50 dark:bg-gray-700 sticky top-0">
                                <tr>
                                    <th className="px-4 py-2 text-left font-medium text-gray-600 dark:text-gray-300">Order ID</th>
                                    <th className="px-4 py-2 text-left font-medium text-gray-600 dark:text-gray-300">Date</th>
                                    <th className="px-4 py-2 text-right font-medium text-gray-600 dark:text-gray-300">Amount</th>
                                    <th className="px-4 py-2 text-center font-medium text-gray-600 dark:text-gray-300">Status</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                                {paginatedTransactions.map(o => (
                                    <tr key={o.id}>
                                        <td className="px-4 py-2 whitespace-nowrap">{o.id}</td>
                                        <td className="px-4 py-2 whitespace-nowrap">{o.timestamp.toLocaleDateString()}</td>
                                        <td className="px-4 py-2 text-right whitespace-nowrap">{currencySymbol}{o.total.toFixed(2)}</td>
                                        <td className="px-4 py-2 text-center whitespace-nowrap">
                                            <span className={`px-2 py-1 rounded-full text-xs font-semibold ${o.isPaid ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-gray-200 text-gray-800 dark:bg-gray-600 dark:text-gray-200'}`}>
                                                {o.isPaid ? 'Paid' : 'Unpaid'}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="mt-4 flex justify-between items-center text-sm no-print">
                        <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="px-3 py-1 border rounded disabled:opacity-50">Previous</button>
                        <span>Page {currentPage} of {totalPages}</span>
                        <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="px-3 py-1 border rounded disabled:opacity-50">Next</button>
                    </div>
                </div>
            </div>
            
            <div className="no-print">
                <h4 className="text-lg font-semibold mb-3">Export Reports</h4>
                <div className="flex flex-wrap items-center gap-3">
                    <button onClick={handleExportSummary} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600">
                        <DownloadIcon className="w-4 h-4" />
                        Export Financial Summary
                    </button>
                     <button onClick={handleExportProducts} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600">
                        <DownloadIcon className="w-4 h-4" />
                        Export Product Performance
                    </button>
                    <button onClick={handleExportTransactions} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600">
                        <DownloadIcon className="w-4 h-4" />
                        Export Transaction History
                    </button>
                </div>
            </div>
        </div>
    );
};

export default FinanceManagement;
