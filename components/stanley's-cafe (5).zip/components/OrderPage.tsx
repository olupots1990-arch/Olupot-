import React from 'react';
import CustomerView from './CustomerView';
import { AiAssistantSettings, MenuItem } from '../types';

interface OrderPageProps {
    initialChatMessage: string | null;
    setInitialChatMessage: React.Dispatch<React.SetStateAction<string | null>>;
    backgroundMediaUrl: string;
    isOnline: boolean;
    aiSettings: AiAssistantSettings;
    menuItems: MenuItem[];
}

const OrderPage: React.FC<OrderPageProps> = ({ initialChatMessage, setInitialChatMessage, backgroundMediaUrl, isOnline, aiSettings, menuItems }) => {
    return (
        <div className="w-full h-full bg-gray-100 dark:bg-gray-900">
             <CustomerView 
                initialChatMessage={initialChatMessage}
                setInitialChatMessage={setInitialChatMessage}
                backgroundMediaUrl={backgroundMediaUrl}
                isOnline={isOnline}
                aiSettings={aiSettings}
                menuItems={menuItems}
             />
        </div>
    );
};

export default OrderPage;
