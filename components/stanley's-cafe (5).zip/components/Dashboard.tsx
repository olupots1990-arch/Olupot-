import React from 'react';
import FinanceManagement from './FinanceManagement';
import type { Order, DeliveryAgent, MenuItem } from '../types';

interface DashboardProps {
  orders: Order[];
  agents: DeliveryAgent[];
  globalCommissionRate: number;
  currencySymbol: string;
  menuItems: MenuItem[];
}

const Dashboard: React.FC<DashboardProps> = ({ orders, agents, globalCommissionRate, currencySymbol, menuItems }) => {
  return (
    <FinanceManagement 
        orders={orders} 
        agents={agents} 
        globalCommissionRate={globalCommissionRate} 
        currencySymbol={currencySymbol} 
        menuItems={menuItems}
    />
  );
};

export default Dashboard;
