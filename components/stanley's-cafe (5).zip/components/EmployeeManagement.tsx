import React, { useState, useRef, useMemo } from 'react';
import type { Employee, EmployeeFile, InventoryItem, InventoryLogEntry } from '../types';
import { UserPlusIcon, EditIcon, TrashIcon, AlertTriangleIcon, CloseIcon, UploadIcon, FileTextIcon, BriefcaseIcon, PackageIcon, ClipboardListIcon } from './icons';
import InventoryManagement from './InventoryManagement';

const EmployeeFormModal: React.FC<{
    employee: Employee | null;
    onSave: (employee: Omit<Employee, 'id' | 'files' | 'baseSalary'> & { baseSalary: number }) => void;
    onClose: () => void;
}> = ({ employee, onSave, onClose }) => {
    const [formData, setFormData] = useState({
        name: employee?.name || '',
        role: employee?.role || 'Waiter',
        hireDate: employee?.hireDate.toISOString().split('T')[0] || '',
        phone: employee?.phone || '',
        email: employee?.email || '',
        baseSalary: employee?.baseSalary || 0,
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ 
            ...formData, 
            hireDate: new Date(formData.hireDate), 
            role: formData.role as Employee['role'],
            baseSalary: Number(formData.baseSalary),
        });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">{employee ? 'Edit Employee' : 'Add New Employee'}</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </header>
                <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium">Full Name</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <div>
                        <label htmlFor="role" className="block text-sm font-medium">Role</label>
                        <select name="role" id="role" value={formData.role} onChange={handleChange} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600">
                            {['Chef', 'Waiter', 'Cashier', 'Cleaner', 'Other'].map(role => (
                                <option key={role} value={role}>{role}</option>
                            ))}
                        </select>
                    </div>
                     <div>
                        <label htmlFor="baseSalary" className="block text-sm font-medium">Base Salary (Monthly)</label>
                        <input type="number" name="baseSalary" id="baseSalary" value={formData.baseSalary} onChange={handleChange} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <div>
                        <label htmlFor="hireDate" className="block text-sm font-medium">Hire Date</label>
                        <input type="date" name="hireDate" id="hireDate" value={formData.hireDate} onChange={handleChange} required className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium">Email Address</label>
                        <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} placeholder="e.g., employee@stanleys.cafe" className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <div>
                        <label htmlFor="phone" className="block text-sm font-medium">Phone Number</label>
                        <input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleChange} placeholder="e.g., 555-123-4567" className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                    </div>
                    <footer className="flex justify-end gap-3 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 rounded-md">Cancel</button>
                        <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save</button>
                    </footer>
                </form>
            </div>
        </div>
    );
};


const EmployeeManagement: React.FC<{
    employees: Employee[];
    setEmployees: React.Dispatch<React.SetStateAction<Employee[]>>;
    inventory: InventoryItem[];
    setInventory: React.Dispatch<React.SetStateAction<InventoryItem[]>>;
    inventoryLogs: InventoryLogEntry[];
    setInventoryLogs: React.Dispatch<React.SetStateAction<InventoryLogEntry[]>>;
}> = ({ employees, setEmployees, inventory, setInventory, inventoryLogs, setInventoryLogs }) => {
    const [activeTab, setActiveTab] = useState<'employees' | 'inventory'>('employees');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
    const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
    const [employeeToDelete, setEmployeeToDelete] = useState<Employee | null>(null);
    const [assignmentData, setAssignmentData] = useState({
        itemId: '',
        date: new Date().toISOString().split('T')[0],
        notes: ''
    });
    const [itemToUnassign, setItemToUnassign] = useState<{ item: InventoryItem; notes: string } | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const availableInventory = useMemo(() => inventory.filter(item => item.assignedTo === null), [inventory]);
    
    const handleSave = (data: Omit<Employee, 'id' | 'files'>) => {
        if (editingEmployee) {
            setEmployees(prev => prev.map(e => e.id === editingEmployee.id ? { ...editingEmployee, ...data } : e));
            if (selectedEmployee?.id === editingEmployee.id) {
                setSelectedEmployee(prev => prev ? { ...prev, ...data } : null);
            }
        } else {
            const newEmployee: Employee = { ...data, id: `emp-${Date.now()}`, files: [] };
            setEmployees(prev => [newEmployee, ...prev]);
        }
        setIsModalOpen(false);
        setEditingEmployee(null);
    };

    const handleDelete = () => {
        if (employeeToDelete) {
            // Unassign any items associated with this employee
            setInventory(prev => prev.map(item => 
                item.assignedTo === employeeToDelete.id ? { ...item, assignedTo: null } : item
            ));
            setEmployees(prev => prev.filter(e => e.id !== employeeToDelete.id));
            if (selectedEmployee?.id === employeeToDelete.id) {
                setSelectedEmployee(null);
            }
            setEmployeeToDelete(null);
        }
    };
    
    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file && selectedEmployee) {
            const newFile: EmployeeFile = { name: file.name, type: file.type, size: file.size, url: URL.createObjectURL(file) };
            const update = (emp: Employee) => ({ ...emp, files: [...emp.files, newFile] });
            setEmployees(prev => prev.map(e => e.id === selectedEmployee.id ? update(e) : e));
            setSelectedEmployee(prev => prev ? update(prev) : null);
        }
    };

    const handleFileDelete = (fileUrl: string) => {
        if(selectedEmployee) {
             const update = (emp: Employee) => ({ ...emp, files: emp.files.filter(f => f.url !== fileUrl) });
            setEmployees(prev => prev.map(e => e.id === selectedEmployee.id ? update(e) : e));
            setSelectedEmployee(prev => prev ? update(prev) : null);
            URL.revokeObjectURL(fileUrl);
        }
    };

    const handleAssignItem = () => {
        if (!assignmentData.itemId || !selectedEmployee) return;

        // Update inventory item
        setInventory(prev => prev.map(item => 
            item.id === assignmentData.itemId ? { ...item, assignedTo: selectedEmployee.id } : item
        ));

        // Create log entry
        const newLogEntry: InventoryLogEntry = {
            id: `log-${Date.now()}`,
            itemId: assignmentData.itemId,
            employeeId: selectedEmployee.id,
            action: 'assigned',
            timestamp: new Date(assignmentData.date),
            notes: assignmentData.notes.trim() || undefined,
        };
        setInventoryLogs(prev => [newLogEntry, ...prev]);

        // Reset form
        setAssignmentData({
            itemId: '',
            date: new Date().toISOString().split('T')[0],
            notes: ''
        });
    };
    
    const handleUnassignItem = () => {
        if (!itemToUnassign) return;
        const { item, notes } = itemToUnassign;
        
        const employeeId = item.assignedTo;
        if (!employeeId) return;

        // Update inventory item
        setInventory(prev => prev.map(i => 
            i.id === item.id ? { ...i, assignedTo: null } : i
        ));
        
        // Create log entry
        const newLogEntry: InventoryLogEntry = {
            id: `log-${Date.now()}`,
            itemId: item.id,
            employeeId: employeeId,
            action: 'unassigned',
            timestamp: new Date(),
            notes: notes.trim() || undefined,
        };
        setInventoryLogs(prev => [newLogEntry, ...prev]);
        
        setItemToUnassign(null); // Close modal
    };


    const assignedToSelectedEmployee = useMemo(() => {
        if (!selectedEmployee) return [];
        
        const assignedItems = inventory.filter(item => item.assignedTo === selectedEmployee.id);
        
        return assignedItems.map(item => {
            const assignmentLog = inventoryLogs
                .filter(log => log.itemId === item.id && log.employeeId === selectedEmployee.id && log.action === 'assigned')
                .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0];
            
            return {
                ...item,
                assignmentDate: assignmentLog?.timestamp,
                assignmentNotes: assignmentLog?.notes,
            };
        });
    }, [inventory, inventoryLogs, selectedEmployee]);

    const TabButton: React.FC<{ tabId: 'employees' | 'inventory', icon: React.ReactNode, label: string }> = ({ tabId, icon, label }) => (
        <button
            onClick={() => setActiveTab(tabId)}
            className={`flex items-center gap-2 px-4 py-3 -mb-px text-sm font-semibold transition-colors duration-200 focus:outline-none ${
                activeTab === tabId
                    ? 'border-b-2 border-indigo-500 text-indigo-600 dark:text-indigo-400'
                    : 'border-b-2 border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
        >
            {icon} {label}
        </button>
    );

    return (
        <div className="bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-lg">
            <nav className="flex space-x-1 border-b-2 border-gray-200 dark:border-gray-700 mb-6">
                <TabButton tabId="employees" icon={<BriefcaseIcon className="w-5 h-5"/>} label="Employees" />
                <TabButton tabId="inventory" icon={<PackageIcon className="w-5 h-5"/>} label="Inventory" />
            </nav>

            {activeTab === 'employees' && (
                <>
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-2xl font-bold">Employee Records</h2>
                        <button onClick={() => { setEditingEmployee(null); setIsModalOpen(true); }} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700">
                            <UserPlusIcon className="w-5 h-5" /> Add Employee
                        </button>
                    </div>
                    <div className="flex flex-col lg:flex-row gap-6">
                        <div className="lg:w-1/2 overflow-x-auto">
                            <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                    <tr>
                                        <th scope="col" className="px-6 py-3">Name</th>
                                        <th scope="col" className="px-6 py-3">Role</th>
                                        <th scope="col" className="px-6 py-3">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {employees.map(emp => (
                                        <tr key={emp.id} className={`border-b dark:border-gray-700 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 ${selectedEmployee?.id === emp.id ? 'bg-indigo-50 dark:bg-indigo-900/50' : ''}`} onClick={() => setSelectedEmployee(emp)}>
                                            <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">{emp.name}</td>
                                            <td className="px-6 py-4">{emp.role}</td>
                                            <td className="px-6 py-4 flex items-center space-x-3">
                                                <button onClick={(e) => { e.stopPropagation(); setEditingEmployee(emp); setIsModalOpen(true); }} className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-800"><EditIcon className="w-5 h-5" /></button>
                                                <button onClick={(e) => { e.stopPropagation(); setEmployeeToDelete(emp); }} className="text-red-600 dark:text-red-400 hover:text-red-800"><TrashIcon className="w-5 h-5" /></button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        <div className="lg:w-1/2 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg min-h-[300px]">
                            {selectedEmployee ? (
                                <div>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <h3 className="text-xl font-bold">{selectedEmployee.name}</h3>
                                            <p className="text-sm text-gray-500">{selectedEmployee.role}</p>
                                        </div>
                                        <button onClick={() => setSelectedEmployee(null)} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"><CloseIcon className="w-5 h-5"/></button>
                                    </div>
                                    <div className="mt-4 pt-4 border-t dark:border-gray-600 space-y-2 text-sm">
                                        <p><strong>Hire Date:</strong> {selectedEmployee.hireDate.toLocaleDateString()}</p>
                                        <p><strong>Email:</strong> {selectedEmployee.email || 'N/A'}</p>
                                        <p><strong>Phone:</strong> {selectedEmployee.phone || 'N/A'}</p>
                                    </div>
                                    <div className="mt-4 pt-4 border-t dark:border-gray-600">
                                        <h4 className="font-semibold mb-2 flex items-center gap-2"><ClipboardListIcon className="w-5 h-5 text-gray-500" />Assigned Inventory</h4>
                                        <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                                            {assignedToSelectedEmployee.map(item => (
                                                <div key={item.id} className="p-2 bg-white dark:bg-gray-700 rounded-md text-sm">
                                                    <div className="flex items-center justify-between">
                                                        <span className="font-medium">{item.name}</span>
                                                        <button onClick={() => setItemToUnassign({ item, notes: '' })} className="text-red-500 hover:text-red-700 text-xs font-semibold">Unassign</button>
                                                    </div>
                                                    <p className="text-xs text-gray-500 dark:text-gray-400">Assigned on: {item.assignmentDate ? item.assignmentDate.toLocaleDateString() : 'N/A'}</p>
                                                    {item.assignmentNotes && <p className="text-xs italic text-gray-600 dark:text-gray-300 mt-1">"{item.assignmentNotes}"</p>}
                                                </div>
                                            ))}
                                            {assignedToSelectedEmployee.length === 0 && <p className="text-sm text-gray-500 text-center py-2">No items assigned.</p>}
                                        </div>
                                        <div className="mt-3 p-3 bg-gray-100 dark:bg-gray-800 rounded-md space-y-2">
                                            <select value={assignmentData.itemId} onChange={e => setAssignmentData(p => ({ ...p, itemId: e.target.value }))} className="block w-full p-2 text-sm border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600">
                                                <option value="">Select an item to assign...</option>
                                                {availableInventory.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
                                            </select>
                                            <input type="date" value={assignmentData.date} onChange={e => setAssignmentData(p => ({ ...p, date: e.target.value }))} className="block w-full p-2 text-sm border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" />
                                            <textarea placeholder="Assignment notes (optional)..." value={assignmentData.notes} onChange={e => setAssignmentData(p => ({ ...p, notes: e.target.value }))} className="block w-full p-2 text-sm border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" rows={2}></textarea>
                                            <button onClick={handleAssignItem} disabled={!assignmentData.itemId} className="w-full px-3 py-2 text-sm text-white bg-green-600 rounded-md hover:bg-green-700 disabled:bg-gray-400">Assign Item</button>
                                        </div>
                                    </div>
                                    <div className="mt-4 pt-4 border-t dark:border-gray-600">
                                        <h4 className="font-semibold mb-2">Documents</h4>
                                        <div className="space-y-2 max-h-40 overflow-y-auto">
                                            {selectedEmployee.files.map(file => (
                                                <div key={file.url} className="flex items-center justify-between p-2 bg-white dark:bg-gray-700 rounded-md">
                                                    <div className="flex items-center gap-2">
                                                        <FileTextIcon className="w-5 h-5 text-gray-500"/>
                                                        <a href={file.url} target="_blank" rel="noopener noreferrer" className="text-sm hover:underline">{file.name}</a>
                                                        <span className="text-xs text-gray-400">({(file.size / 1024).toFixed(1)} KB)</span>
                                                    </div>
                                                    <button onClick={() => handleFileDelete(file.url)} className="text-red-500 hover:text-red-700"><TrashIcon className="w-4 h-4"/></button>
                                                </div>
                                            ))}
                                        </div>
                                        {selectedEmployee.files.length === 0 && <p className="text-sm text-gray-500 text-center py-4">No documents uploaded.</p>}
                                        <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                                        <button onClick={() => fileInputRef.current?.click()} className="mt-4 w-full flex items-center justify-center gap-2 px-3 py-2 text-sm text-white bg-blue-600 rounded-md hover:bg-blue-700">
                                            <UploadIcon className="w-5 h-5"/> Upload Document
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex items-center justify-center h-full">
                                    <p className="text-gray-500">Select an employee to view details</p>
                                </div>
                            )}
                        </div>
                    </div>
                </>
            )}
            
            {activeTab === 'inventory' && (
                <InventoryManagement 
                    inventory={inventory} 
                    setInventory={setInventory} 
                    employees={employees}
                    inventoryLogs={inventoryLogs}
                />
            )}

            {isModalOpen && <EmployeeFormModal employee={editingEmployee} onSave={handleSave} onClose={() => { setIsModalOpen(false); setEditingEmployee(null); }} />}
            
            {itemToUnassign && (
                <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60] p-4">
                    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
                         <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                            <h3 className="text-lg font-bold">Unassign Item</h3>
                            <button onClick={() => setItemToUnassign(null)}><CloseIcon className="w-6 h-6" /></button>
                        </header>
                         <div className="p-6 space-y-4">
                            <p>Unassigning <span className="font-semibold">{itemToUnassign.item.name}</span> from <span className="font-semibold">{selectedEmployee?.name}</span>.</p>
                             <div>
                                <label htmlFor="unassignNotes" className="block text-sm font-medium">Return Notes (Optional)</label>
                                <textarea
                                    id="unassignNotes"
                                    placeholder="e.g., Item returned in good condition."
                                    value={itemToUnassign.notes}
                                    onChange={e => setItemToUnassign(prev => prev ? { ...prev, notes: e.target.value } : null)}
                                    className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                                    rows={3}
                                />
                            </div>
                        </div>
                        <div className="flex justify-end gap-3 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-b-lg">
                            <button onClick={() => setItemToUnassign(null)} className="px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600">Cancel</button>
                            <button onClick={handleUnassignItem} className="px-4 py-2 text-white bg-indigo-600 rounded-md hover:bg-indigo-700">Confirm Unassignment</button>
                        </div>
                    </div>
                </div>
            )}

            {employeeToDelete && (
                 <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60] p-4">
                    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
                        <div className="p-6 text-center">
                            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 dark:bg-red-900/50">
                                <AlertTriangleIcon className="h-6 w-6 text-red-600 dark:text-red-300" />
                            </div>
                            <h3 className="mt-5 text-lg font-medium text-gray-900 dark:text-white">Delete Employee</h3>
                            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">Are you sure you want to delete {employeeToDelete.name}? Any assigned inventory will be unassigned. This action is irreversible.</p>
                        </div>
                        <div className="flex justify-center gap-3 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-b-lg">
                            <button onClick={() => setEmployeeToDelete(null)} className="px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600">Cancel</button>
                            <button onClick={handleDelete} className="px-4 py-2 text-white bg-red-600 rounded-md hover:bg-red-700">Delete</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default EmployeeManagement;