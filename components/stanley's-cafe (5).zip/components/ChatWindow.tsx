
import React, { useRef, useEffect } from 'react';
import type { Message } from '../types';
import { BotIcon, UserIcon, Volume2Icon } from './icons';

interface ChatWindowProps {
  messages: Message[];
  isLoading: boolean;
  onPlayTTS: (text: string) => void;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading, onPlayTTS }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages, isLoading]);
  
  const SourceLink: React.FC<{uri: string, title: string}> = ({ uri, title }) => (
    <a href={uri} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-400 hover:underline block truncate">
      - {title || uri}
    </a>
  );

  return (
    <div className="flex-1 p-4 overflow-y-auto">
      <div className="space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex items-end gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.sender === 'bot' && <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-500 flex items-center justify-center"><BotIcon className="w-5 h-5 text-white" /></div>}
            <div className={`max-w-xs md:max-w-md lg:max-w-lg p-3 rounded-2xl ${msg.sender === 'user' ? 'bg-blue-500 text-white rounded-br-none' : 'bg-gray-700 text-white rounded-bl-none'}`}>
              <p className="text-sm">{msg.text}</p>
              {msg.sources && msg.sources.length > 0 && (
                <div className="mt-2 pt-2 border-t border-gray-600">
                    <p className="text-xs font-bold mb-1">Sources:</p>
                    {msg.sources.map((source, index) => <SourceLink key={index} {...source} />)}
                </div>
              )}
              <div className="flex justify-between items-center mt-2">
                <span className="text-xs opacity-70">{msg.timestamp}</span>
                {msg.sender === 'bot' && (
                    <button onClick={() => onPlayTTS(msg.text)} className="ml-2 text-gray-300 hover:text-white transition-colors">
                        <Volume2Icon className="w-4 h-4" />
                    </button>
                )}
              </div>
            </div>
            {msg.sender === 'user' && <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center"><UserIcon className="w-5 h-5 text-white" /></div>}
          </div>
        ))}
        {isLoading && (
          <div className="flex items-end gap-3 justify-start">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-500 flex items-center justify-center"><BotIcon className="w-5 h-5 text-white" /></div>
            <div className="max-w-xs md:max-w-md lg:max-w-lg p-3 rounded-2xl bg-gray-700 text-white rounded-bl-none">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-gray-300 rounded-full animate-pulse"></div>
                <div className="w-2 h-2 bg-gray-300 rounded-full animate-pulse delay-150"></div>
                <div className="w-2 h-2 bg-gray-300 rounded-full animate-pulse delay-300"></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};

export default ChatWindow;
