import React from 'react';

interface LicenseStepProps {
    licenseAccepted: boolean;
    onAcceptChange: (accepted: boolean) => void;
}

const LicenseStep: React.FC<LicenseStepProps> = ({ licenseAccepted, onAcceptChange }) => {
    return (
        <div>
            <h2 className="text-xl font-semibold">License Agreement</h2>
            <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">Please read the following license agreement carefully.</p>
            <div className="mt-4 p-3 h-64 overflow-y-scroll border bg-white dark:bg-gray-900 dark:border-gray-600 rounded-md text-sm text-gray-500 dark:text-gray-400">
                <h3 className="font-bold mb-2">END-USER LICENSE AGREEMENT (EULA) for Stanley's Cafe App</h3>
                <p>
                    This End-User License Agreement ("EULA") is a legal agreement between you and Stanley's Cafe. This EULA agreement governs your acquisition and use of our Stanley's Cafe software ("Software") directly from Stanley's Cafe or indirectly through a Stanley's Cafe authorized reseller or distributor (a "Reseller").
                </p>
                <p className="mt-2">
                    Please read this EULA agreement carefully before completing the installation process and using the Stanley's Cafe software. It provides a license to use the Stanley's Cafe software and contains warranty information and liability disclaimers.
                </p>
                 <p className="mt-2">
                    By clicking "accept" or installing and/or using the Stanley's Cafe software, you are confirming your acceptance of the Software and agreeing to become bound by the terms of this EULA agreement. If you are entering into this EULA agreement on behalf of a company or other legal entity, you represent that you have the authority to bind such entity and its affiliates to these terms and conditions. If you do not have such authority or if you do not agree with the terms and conditions of this EULA agreement, do not install or use the Software, and you must not accept this EULA agreement.
                </p>
            </div>
            <div className="mt-4">
                <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                        type="checkbox"
                        checked={licenseAccepted}
                        onChange={(e) => onAcceptChange(e.target.checked)}
                        className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700 dark:text-gray-300">I accept the terms in the License Agreement</span>
                </label>
            </div>
        </div>
    );
};

export default LicenseStep;
