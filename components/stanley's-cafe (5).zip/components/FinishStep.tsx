import React from 'react';
import { CheckIcon } from './icons';

const FinishStep: React.FC = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-20 h-20 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mb-4">
                <CheckIcon className="w-12 h-12 text-green-500" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100">Completing the Stanley's Cafe Setup Wizard</h2>
            <p className="mt-2 text-gray-600 dark:text-gray-300">
                Stanley's Cafe has been successfully installed on your computer.
            </p>
             <p className="mt-6 text-sm text-gray-500 dark:text-gray-400">
                Click Finish to exit this wizard.
            </p>
             <div className="mt-8">
                <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                        type="checkbox"
                        defaultChecked
                        className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700 dark:text-gray-300">Run Stanley's Cafe</span>
                </label>
            </div>
        </div>
    );
};

export default FinishStep;
