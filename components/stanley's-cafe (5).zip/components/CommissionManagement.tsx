import React from 'react';
import type { DeliveryAgent } from '../types';
import { PercentIcon } from './icons';

interface CommissionManagementProps {
    agents: DeliveryAgent[];
    setAgents: React.Dispatch<React.SetStateAction<DeliveryAgent[]>>;
    globalCommissionRate: number;
    setGlobalCommissionRate: (rate: number) => void;
}

const CommissionManagement: React.FC<CommissionManagementProps> = ({ agents, setAgents, globalCommissionRate, setGlobalCommissionRate }) => {
    
    const handleGlobalRateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setGlobalCommissionRate(value === '' ? 0 : parseFloat(value));
    };

    const handleAgentRateChange = (agentId: string, value: string) => {
        setAgents(prevAgents =>
            prevAgents.map(agent =>
                agent.id === agentId
                    ? { ...agent, commissionRate: value === '' ? undefined : parseFloat(value) }
                    : agent
            )
        );
    };

    return (
        <div className="p-6 bg-white dark:bg-gray-800 rounded-lg shadow space-y-6 max-w-4xl mx-auto">
            <header>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Commission Management</h2>
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                    Set a global commission rate or specify individual rates for each delivery agent. Individual rates will override the global rate.
                </p>
            </header>

            <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                <label htmlFor="globalRate" className="block text-lg font-semibold text-gray-800 dark:text-gray-200">
                    Global Commission Rate
                </label>
                <div className="mt-2 relative">
                    <input
                        type="number"
                        id="globalRate"
                        value={globalCommissionRate}
                        onChange={handleGlobalRateChange}
                        className="block w-full pl-3 pr-12 py-2 text-base border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                        placeholder="e.g., 10"
                        min="0"
                        step="0.5"
                    />
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                        <PercentIcon className="h-5 w-5 text-gray-400" />
                    </div>
                </div>
            </div>

            <div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Individual Agent Rates</h3>
                <div className="mt-4 space-y-3">
                    {agents.map(agent => (
                        <div key={agent.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 bg-gray-50 dark:bg-gray-900/50 rounded-md">
                            <span className="font-medium text-gray-700 dark:text-gray-300">{agent.name}</span>
                            <div className="relative mt-2 sm:mt-0">
                                <input
                                    type="number"
                                    value={agent.commissionRate ?? ''}
                                    onChange={(e) => handleAgentRateChange(agent.id, e.target.value)}
                                    className="block w-full sm:w-40 pl-3 pr-12 py-2 text-base border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                                    placeholder={`Global (${globalCommissionRate}%)`}
                                    min="0"
                                    step="0.5"
                                />
                                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                    <PercentIcon className="h-5 w-5 text-gray-400" />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default CommissionManagement;
