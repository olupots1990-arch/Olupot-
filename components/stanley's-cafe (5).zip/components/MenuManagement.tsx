import React, { useState } from 'react';
import type { MenuItem } from '../types';
import { PlusCircleIcon, EditIcon, TrashIcon, AlertTriangleIcon } from './icons';
import MenuItemFormModal from './MenuItemFormModal';

interface MenuManagementProps {
    menuItems: MenuItem[];
    setMenuItems: React.Dispatch<React.SetStateAction<MenuItem[]>>;
    currencySymbol: string;
}

const MenuManagement: React.FC<MenuManagementProps> = ({ menuItems, setMenuItems, currencySymbol }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
    const [itemToDelete, setItemToDelete] = useState<MenuItem | null>(null);

    const handleSave = (itemData: Omit<MenuItem, 'id'>) => {
        if (editingItem) {
            setMenuItems(prev => prev.map(item => item.id === editingItem.id ? { ...editingItem, ...itemData } : item));
        } else {
            const newItem: MenuItem = { ...itemData, id: `menu-${Date.now()}` };
            setMenuItems(prev => [...prev, newItem]);
        }
        setIsModalOpen(false);
        setEditingItem(null);
    };
    
    const handleDelete = () => {
        if (itemToDelete) {
            setMenuItems(prev => prev.filter(item => item.id !== itemToDelete.id));
            setItemToDelete(null);
        }
    };

    return (
        <div className="p-6 space-y-6">
            <header className="flex justify-between items-center">
                <div>
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Menu Management</h2>
                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                        Add, edit, or remove items from your cafe's menu.
                    </p>
                </div>
                 <button
                    onClick={() => { setEditingItem(null); setIsModalOpen(true); }}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700"
                >
                    <PlusCircleIcon className="w-5 h-5" />
                    Add New Item
                </button>
            </header>
            
            <div className="overflow-x-auto border border-gray-200 dark:border-gray-700 rounded-lg">
                <table className="w-full text-sm text-left">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th className="px-6 py-3">Item</th>
                            <th className="px-6 py-3">Price</th>
                            <th className="px-6 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                        {menuItems.map(item => (
                            <tr key={item.id} className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td className="px-6 py-4 flex items-center gap-4">
                                    <img src={item.imageUrl} alt={item.name} className="w-12 h-12 rounded-md object-cover" />
                                    <span className="font-medium text-gray-900 dark:text-white">{item.name}</span>
                                </td>
                                <td className="px-6 py-4 font-mono text-gray-700 dark:text-gray-300">
                                    {currencySymbol}{item.price.toFixed(2)}
                                </td>
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-4">
                                        <button onClick={() => { setEditingItem(item); setIsModalOpen(true); }} className="text-indigo-600 hover:text-indigo-800"><EditIcon className="w-5 h-5"/></button>
                                        <button onClick={() => setItemToDelete(item)} className="text-red-600 hover:text-red-800"><TrashIcon className="w-5 h-5"/></button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {menuItems.length === 0 && (
                    <p className="text-center py-10 text-gray-500 dark:text-gray-400">No menu items found. Add one to get started!</p>
                )}
            </div>

            {isModalOpen && (
                <MenuItemFormModal 
                    item={editingItem}
                    onSave={handleSave}
                    onClose={() => setIsModalOpen(false)}
                />
            )}

            {itemToDelete && (
                 <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60] p-4">
                    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md">
                        <div className="p-6 text-center">
                            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 dark:bg-red-900/50">
                                <AlertTriangleIcon className="h-6 w-6 text-red-600 dark:text-red-300" />
                            </div>
                            <h3 className="mt-5 text-lg font-medium text-gray-900 dark:text-white">Delete Menu Item</h3>
                            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                                Are you sure you want to delete <span className="font-semibold">{itemToDelete.name}</span>? This action cannot be undone.
                            </p>
                        </div>
                        <div className="flex justify-center gap-3 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-b-lg">
                            <button onClick={() => setItemToDelete(null)} className="px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600">Cancel</button>
                            <button onClick={handleDelete} className="px-4 py-2 text-white bg-red-600 rounded-md hover:bg-red-700">Delete</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default MenuManagement;
