import React from 'react';
import { HomeIcon, CogIcon, CalendarIcon, ClipboardListIcon, UsersIcon, BriefcaseIcon, CreditCardIcon, TruckIcon } from './icons';

type AdminTab = 'orders' | 'dashboard' | 'leave' | 'users' | 'employees' | 'payroll' | 'settings' | 'tracking';

interface SidebarProps {
  activeTab: AdminTab;
  setActiveTab: (tab: AdminTab) => void;
  allowedTabs: AdminTab[];
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, allowedTabs }) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <HomeIcon className="w-5 h-5" /> },
    { id: 'orders', label: 'Orders', icon: <ClipboardListIcon className="w-5 h-5" /> },
    { id: 'tracking', label: 'Delivery Tracking', icon: <TruckIcon className="w-5 h-5" /> },
    { id: 'leave', label: 'Leave & Attendance', icon: <CalendarIcon className="w-5 h-5" /> },
    { id: 'employees', label: 'Employees', icon: <BriefcaseIcon className="w-5 h-5" /> },
    { id: 'payroll', label: 'Payroll', icon: <CreditCardIcon className="w-5 h-5" /> },
    { id: 'users', label: 'User Accounts', icon: <UsersIcon className="w-5 h-5" /> },
    { id: 'settings', label: 'Settings', icon: <CogIcon className="w-5 h-5" /> },
  ];

  const NavLink: React.FC<{ tab: AdminTab, icon: React.ReactNode, label: string }> = ({ tab, icon, label }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`flex items-center w-full px-4 py-3 text-sm font-medium transition-colors duration-200 rounded-lg ${
        activeTab === tab
          ? 'bg-indigo-600 text-white'
          : 'text-gray-400 hover:bg-gray-700 hover:text-white'
      }`}
    >
      {icon}
      <span className="ml-3">{label}</span>
    </button>
  );

  return (
    <aside className="no-print flex-shrink-0 w-64 bg-gray-800 text-white flex flex-col">
      <div className="flex items-center justify-center h-20 border-b border-gray-700">
        <h1 className="text-2xl font-bold text-indigo-400">Stanley's Cafe</h1>
      </div>
      <nav className="flex-1 px-4 py-4 space-y-2">
        {navItems
          .filter(item => allowedTabs.includes(item.id as AdminTab))
          .map(item => (
            <NavLink
              key={item.id}
              tab={item.id as AdminTab}
              icon={item.icon}
              label={item.label}
            />
          ))}
      </nav>
    </aside>
  );
};

export default Sidebar;