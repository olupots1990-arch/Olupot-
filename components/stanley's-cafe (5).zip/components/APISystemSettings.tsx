import React, { useState, useEffect } from 'react';
import { ShieldCheckIcon, UsersIcon, BrainCircuitIcon } from './icons';
import type { AiAssistantSettings } from '../types';

interface APISystemSettingsProps {
    onNavigateToUsers: () => void;
    aiSettings: AiAssistantSettings;
    setAiSettings: React.Dispatch<React.SetStateAction<AiAssistantSettings>>;
}

const APISystemSettings: React.FC<APISystemSettingsProps> = ({ onNavigateToUsers, aiSettings, setAiSettings }) => {
    const [veoKeyStatus, setVeoKeyStatus] = useState<'checking' | 'selected' | 'not_selected'>('checking');

    useEffect(() => {
        const checkVeoKey = async () => {
            // @ts-ignore
            if (window.aistudio && typeof window.aistudio.hasSelectedApiKey === 'function') {
                 // @ts-ignore
                const hasKey = await window.aistudio.hasSelectedApiKey();
                setVeoKeyStatus(hasKey ? 'selected' : 'not_selected');
            } else {
                setVeoKeyStatus('not_selected'); // aistudio might not be available
            }
        };
        checkVeoKey();
    }, []);
    
    const geminiApiKey = process.env.API_KEY;

    return (
        <div className="p-6 space-y-6">
            <header>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">API & System Settings</h2>
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                    Monitor API integrations and manage system-level configurations.
                </p>
            </header>

            <div className="space-y-4 pt-4 border-t dark:border-gray-700">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">API Key Status</h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-900/40 rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="font-semibold text-gray-800 dark:text-gray-200">Google Gemini API Key</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">For chat, search, image generation, etc.</p>
                        </div>
                        {geminiApiKey ? (
                            <span className="px-2 py-1 text-xs font-medium text-green-800 bg-green-100 rounded-full dark:bg-green-900 dark:text-green-200">Loaded from Environment</span>
                        ) : (
                            <span className="px-2 py-1 text-xs font-medium text-red-800 bg-red-100 rounded-full dark:bg-red-900 dark:text-red-200">Not Found</span>
                        )}
                    </div>
                    <div className="flex items-center justify-between">
                         <div>
                            <p className="font-semibold text-gray-800 dark:text-gray-200">Google Veo (Video) API Key</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">For AI video generation features.</p>
                        </div>
                        {veoKeyStatus === 'checking' && <span className="text-xs text-gray-500">Checking...</span>}
                        {veoKeyStatus === 'selected' && <span className="px-2 py-1 text-xs font-medium text-green-800 bg-green-100 rounded-full dark:bg-green-900 dark:text-green-200">Key Selected</span>}
                        {veoKeyStatus === 'not_selected' && <span className="px-2 py-1 text-xs font-medium text-yellow-800 bg-yellow-100 rounded-full dark:bg-yellow-900 dark:text-yellow-200">Selection Required</span>}
                    </div>
                </div>
            </div>

             <div className="space-y-4 pt-4 border-t dark:border-gray-700">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <BrainCircuitIcon className="w-6 h-6" />
                    AI Assistant Settings
                </h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-900/40 rounded-lg space-y-4">
                    <div>
                        <label htmlFor="systemPrompt" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                            System Prompt (AI Persona)
                        </label>
                        <textarea
                            id="systemPrompt"
                            rows={5}
                            className="mt-1 block w-full text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 rounded-md"
                            placeholder="Describe how the AI assistant should behave..."
                            value={aiSettings.systemPrompt}
                            onChange={e => setAiSettings(prev => ({ ...prev, systemPrompt: e.target.value }))}
                        />
                        <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                            This instruction defines the personality and core functions of your customer-facing AI assistant, Stan.
                        </p>
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t dark:border-gray-600">
                        <div>
                            <p className="font-semibold text-gray-800 dark:text-gray-200">Enable Smart Suggestions</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">Allow the AI to suggest additional items to customers.</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                            <input
                                type="checkbox"
                                checked={aiSettings.suggestionsEnabled}
                                onChange={e => setAiSettings(prev => ({ ...prev, suggestionsEnabled: e.target.checked }))}
                                className="sr-only peer"
                            />
                            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 dark:peer-focus:ring-indigo-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-indigo-600"></div>
                        </label>
                    </div>
                </div>
            </div>

            <div className="space-y-4 pt-4 border-t dark:border-gray-700">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">System Administration</h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-900/40 rounded-lg flex items-center justify-between">
                    <div>
                        <p className="font-semibold text-gray-800 dark:text-gray-200">User Account Management</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                            Add, edit, and remove users and manage their roles.
                        </p>
                    </div>
                    <button 
                        onClick={onNavigateToUsers}
                        className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700"
                    >
                        <UsersIcon className="w-5 h-5"/>
                        Manage Users
                    </button>
                </div>
            </div>
        </div>
    );
};

export default APISystemSettings;