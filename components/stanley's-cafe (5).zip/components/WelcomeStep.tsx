import React from 'react';
import { ShieldCheckIcon } from './icons';

const WelcomeStep: React.FC = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center">
             <ShieldCheckIcon className="w-20 h-20 text-indigo-400 mb-4" />
            <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100">Welcome to the Stanley's Cafe Setup Wizard</h2>
            <p className="mt-2 text-gray-600 dark:text-gray-300">
                This wizard will guide you through the installation of the Stanley's Cafe ordering application.
            </p>
            <p className="mt-6 text-sm text-gray-500 dark:text-gray-400">
                It is recommended that you close all other applications before continuing.
            </p>
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                Click Next to continue, or Cancel to exit Setup.
            </p>
        </div>
    );
};

export default WelcomeStep;
