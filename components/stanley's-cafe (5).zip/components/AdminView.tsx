import React, { useState, useEffect, useCallback } from 'react';
import { INITIAL_DELIVERY_AGENTS, MOCK_LEAVE_REQUESTS } from '../constants';
import type { Order, DeliveryAgent, LeaveRequest, LocationInfo, VoiceoverAsset, User, BackgroundMedia, UserRole, Employee, Advertisement, InventoryItem, InventoryLogEntry, DeploymentLog, AiAssistantSettings, MenuItem } from '../types';
import { OrderStatus, PaymentMethod } from '../types';
import type { Theme } from '../App';
import { BellIcon } from './icons';
import Dashboard from './Dashboard';
import Settings from './Settings';
import { LeaveManagement } from './LeaveManagement';
import OrderList from './OrderList';
import UserManagement from './UserManagement';
import EmployeeManagement from './EmployeeManagement';
import PayrollManagement from './PayrollManagement';
import Sidebar from './Sidebar';
import Header from './Header';
import DeliveryTrackingMap from './DeliveryTrackingMap';

type AdminTab = 'orders' | 'dashboard' | 'tracking' | 'leave' | 'users' | 'employees' | 'payroll' | 'settings';

interface AdminViewProps {
  onLogout: () => void;
  backgroundVideos: (BackgroundMedia | null)[];
  setBackgroundVideos: React.Dispatch<React.SetStateAction<(BackgroundMedia | null)[]>>;
  backgroundImages: (BackgroundMedia | null)[];
  setBackgroundImages: React.Dispatch<React.SetStateAction<(BackgroundMedia | null)[]>>;
  backgroundMusicUrl: string | null;
  setBackgroundMusicUrl: React.Dispatch<React.SetStateAction<string | null>>;
  location: LocationInfo;
  setLocation: React.Dispatch<React.SetStateAction<LocationInfo>>;
  domainName: string;
  setDomainName: React.Dispatch<React.SetStateAction<string>>;
  mediaLibrary: BackgroundMedia[];
  setMediaLibrary: React.Dispatch<React.SetStateAction<BackgroundMedia[]>>;
  voiceoverLibrary: VoiceoverAsset[];
  setVoiceoverLibrary: React.Dispatch<React.SetStateAction<VoiceoverAsset[]>>;
  currencySymbol: string;
  setCurrencySymbol: React.Dispatch<React.SetStateAction<string>>;
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  orders: Order[];
  setOrders: React.Dispatch<React.SetStateAction<Order[]>>;
  employees: Employee[];
  setEmployees: React.Dispatch<React.SetStateAction<Employee[]>>;
  advertisements: Advertisement[];
  setAdvertisements: React.Dispatch<React.SetStateAction<Advertisement[]>>;
  inventory: InventoryItem[];
  setInventory: React.Dispatch<React.SetStateAction<InventoryItem[]>>;
  inventoryLogs: InventoryLogEntry[];
  setInventoryLogs: React.Dispatch<React.SetStateAction<InventoryLogEntry[]>>;
  isOnline: boolean;
  theme: Theme;
  setTheme: React.Dispatch<React.SetStateAction<Theme>>;
  galleryProductIds: string[];
  setGalleryProductIds: React.Dispatch<React.SetStateAction<string[]>>;
  menuItems: MenuItem[];
  setMenuItems: React.Dispatch<React.SetStateAction<MenuItem[]>>;
  deploymentHistory: DeploymentLog[];
  setDeploymentHistory: React.Dispatch<React.SetStateAction<DeploymentLog[]>>;
  aiSettings: AiAssistantSettings;
  setAiSettings: React.Dispatch<React.SetStateAction<AiAssistantSettings>>;
}

const AdminView: React.FC<AdminViewProps> = (props) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('settings');
  const [agents, setAgents] = useState<DeliveryAgent[]>(INITIAL_DELIVERY_AGENTS);
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>(MOCK_LEAVE_REQUESTS);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [globalCommissionRate, setGlobalCommissionRate] = useState<number>(10);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  
  const { 
    onLogout,
    backgroundVideos, setBackgroundVideos, 
    backgroundImages, setBackgroundImages,
    backgroundMusicUrl, setBackgroundMusicUrl, 
    location, setLocation,
    domainName, setDomainName,
    mediaLibrary, setMediaLibrary,
    voiceoverLibrary, setVoiceoverLibrary,
    currencySymbol, setCurrencySymbol,
    users, setUsers,
    orders, setOrders,
    employees, setEmployees,
    advertisements, setAdvertisements,
    inventory, setInventory,
    inventoryLogs, setInventoryLogs,
    isOnline,
    theme, setTheme,
    galleryProductIds, setGalleryProductIds,
    menuItems, setMenuItems,
    deploymentHistory, setDeploymentHistory,
    aiSettings, setAiSettings,
  } = props;

  const [currentUser, setCurrentUser] = useState<User>(users.find(u => u.role === 'admin')!);

  const PERMISSIONS: Record<UserRole, { tabs: AdminTab[] }> = {
      admin: { tabs: ['dashboard', 'orders', 'tracking', 'leave', 'users', 'employees', 'payroll', 'settings'] },
      manager: { tabs: ['dashboard', 'orders', 'tracking', 'leave', 'users', 'employees', 'payroll', 'settings'] },
      supervisor: { tabs: ['orders', 'tracking', 'leave', 'users'] },
      deliveryAgent: { tabs: [] },
      customer: { tabs: [] },
  };

  const allowedTabs = PERMISSIONS[currentUser.role]?.tabs || [];

  useEffect(() => {
      if (!allowedTabs.includes(activeTab)) {
          setActiveTab(allowedTabs[0] || 'dashboard');
      }
  }, [currentUser, activeTab, allowedTabs]);

  // Sync currentUser state if the user is updated in the main users list (e.g., profile picture change)
  useEffect(() => {
      const userInList = users.find(u => u.id === currentUser.id);
      if (userInList && JSON.stringify(userInList) !== JSON.stringify(currentUser)) {
          setCurrentUser(userInList);
      }
  }, [users, currentUser]);

  const handleSelectOrder = useCallback((order: Order) => {
    setSelectedOrder(order);
    if (order.isNew) {
      setOrders(currentOrders =>
        currentOrders.map(o =>
          o.id === order.id ? { ...o, isNew: false } : o
        )
      );
    }
  }, [setOrders]);
  
  const showNotification = useCallback((order: Order) => {
    setToastMessage(`New order #${order.id} from ${order.customerName}`);

    if (!("Notification" in window)) {
      console.log("This browser does not support desktop notification");
      return;
    }

    if (Notification.permission === "granted") {
      const notification = new Notification("New Order Received!", {
        body: `Order #${order.id} from ${order.customerName}`,
        icon: '/favicon.svg',
      });
      notification.onclick = () => {
        window.focus();
        setActiveTab('orders');
        handleSelectOrder(order);
      };
    }
  }, [handleSelectOrder]);
  
  useEffect(() => {
    if (toastMessage) {
        const timer = setTimeout(() => {
            setToastMessage(null);
        }, 5000);
        return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  useEffect(() => {
    // This effect simulates new orders arriving from the customer website
    // to demonstrate the notification system.
    const intervalId = setInterval(() => {
      // Don't create new orders if the tab is not visible to be less intrusive
      if (document.hidden) return;

      const randomItem = menuItems[Math.floor(Math.random() * menuItems.length)] || { name: 'Margherita Pizza', price: 12.99, id: '1', imageUrl: '' };
      const customerUsers = users.filter(u => u.role === 'customer');
      const randomUser = customerUsers[Math.floor(Math.random() * customerUsers.length)] || { id: `cust-${Date.now()}`, name: 'Random Customer', email: '', role: 'customer'};

      const newOrder: Order = {
        id: `ORD-${Date.now().toString().slice(-5)}`,
        customerId: randomUser.id,
        customerName: randomUser.name,
        items: [{ name: randomItem.name, quantity: 1 }],
        total: randomItem.price,
        status: OrderStatus.PENDING,
        timestamp: new Date(),
        isPaid: false,
        paymentMethod: PaymentMethod.CREDIT_CARD,
        isNew: true,
      };

      setOrders(prevOrders => [newOrder, ...prevOrders]);
      showNotification(newOrder);
    }, 30000); // A new order every 30 seconds

    return () => clearInterval(intervalId);
  }, [menuItems, users, setOrders, showNotification]);


  const renderContent = () => {
    const contentProps = {
        className: "printable-area"
    };
    switch (activeTab) {
      case 'orders':
        return <div {...contentProps}><OrderList
                  orders={orders}
                  agents={agents}
                  setOrders={setOrders}
                  setAgents={setAgents}
                  selectedOrder={selectedOrder}
                  onSelectOrder={handleSelectOrder}
                  onCloseDetails={() => setSelectedOrder(null)}
                  globalCommissionRate={globalCommissionRate}
                  currencySymbol={currencySymbol}
                  users={users}
                  onNewOrderNotification={showNotification}
                  menuItems={menuItems}
                /></div>;
      case 'dashboard':
        return <div {...contentProps}><Dashboard 
                  orders={orders}
                  agents={agents}
                  globalCommissionRate={globalCommissionRate}
                  currencySymbol={currencySymbol}
                  menuItems={menuItems}
                /></div>;
      case 'tracking':
        return <DeliveryTrackingMap 
                  orders={orders.filter(o => o.status === 'Out for Delivery')} 
                  agents={agents} 
                />;
      case 'leave':
        return <div {...contentProps} className="bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-lg printable-area">
                 <LeaveManagement
                    agents={agents}
                    setAgents={setAgents}
                    employees={employees}
                    setEmployees={setEmployees}
                    leaveRequests={leaveRequests}
                    setLeaveRequests={setLeaveRequests}
                  />
               </div>;
      case 'users':
        return <UserManagement users={users} setUsers={setUsers} currentUser={currentUser} />;
      case 'employees':
        return <EmployeeManagement 
                    employees={employees} 
                    setEmployees={setEmployees} 
                    inventory={inventory} 
                    setInventory={setInventory} 
                    inventoryLogs={inventoryLogs}
                    setInventoryLogs={setInventoryLogs}
                />;
      case 'payroll':
        return <PayrollManagement 
                 employees={employees} 
                 agents={agents} 
                 orders={orders}
                 globalCommissionRate={globalCommissionRate}
                 currencySymbol={currencySymbol}
               />;
      case 'settings':
        return <Settings
                  backgroundVideos={backgroundVideos}
                  setBackgroundVideos={setBackgroundVideos}
                  backgroundImages={backgroundImages}
                  setBackgroundImages={setBackgroundImages}
                  backgroundMusicUrl={backgroundMusicUrl}
                  onMusicChange={setBackgroundMusicUrl}
                  location={location}
                  onLocationChange={setLocation}
                  domainName={domainName}
                  setDomainName={setDomainName}
                  mediaLibrary={mediaLibrary}
                  setMediaLibrary={setMediaLibrary}
                  voiceoverLibrary={voiceoverLibrary}
                  setVoiceoverLibrary={setVoiceoverLibrary}
                  currencySymbol={currencySymbol}
                  setCurrencySymbol={setCurrencySymbol}
                  advertisements={advertisements}
                  setAdvertisements={setAdvertisements}
                  onNavigateToUsers={() => setActiveTab('users')}
                  galleryProductIds={galleryProductIds}
                  setGalleryProductIds={setGalleryProductIds}
                  menuItems={menuItems}
                  setMenuItems={setMenuItems}
                  isOnline={isOnline}
                  deploymentHistory={deploymentHistory}
                  setDeploymentHistory={setDeploymentHistory}
                  aiSettings={aiSettings}
                  setAiSettings={setAiSettings}
                />;
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900 font-sans">
      <style>{`
          @keyframes slideInDownToast {
              from { transform: translateY(-100%); opacity: 0; }
              to { transform: translateY(0); opacity: 1; }
          }
          .animate-slide-in-down { animation: slideInDownToast 0.5s ease-out forwards; }
      `}</style>
      
      <Sidebar 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        allowedTabs={allowedTabs}
      />
      
      <div className="relative flex-1 flex flex-col overflow-hidden">
        {toastMessage && (
          <div className="absolute top-5 right-5 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-[100] animate-slide-in-down">
              <div className="flex items-center gap-3">
                <BellIcon className="w-6 h-6"/>
                <p className="font-semibold">{toastMessage}</p>
              </div>
          </div>
        )}

        <Header 
          isOnline={isOnline}
          currentUser={currentUser}
          users={users}
          onUserChange={setCurrentUser}
          onLogout={onLogout}
          activeTab={activeTab}
          theme={theme}
          setTheme={setTheme}
          setUsers={setUsers}
        />
        
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 dark:bg-gray-900 p-4 md:p-6 lg:p-8">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default AdminView;
