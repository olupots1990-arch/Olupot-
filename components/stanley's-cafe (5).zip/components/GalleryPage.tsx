import React from 'react';
import type { Page } from '../App';
import { MenuItem } from '../types';

interface GalleryPageProps {
    galleryProductIds: string[];
    menuItems: MenuItem[];
    setActivePage: (page: Page) => void;
    setInitialChatMessage: React.Dispatch<React.SetStateAction<string | null>>;
}

const GalleryPage: React.FC<GalleryPageProps> = ({ galleryProductIds, menuItems, setActivePage, setInitialChatMessage }) => {
    const images = menuItems
        .filter(item => galleryProductIds.includes(item.id))
        .map(item => ({
            id: item.id,
            src: item.imageUrl,
            alt: item.name,
            price: item.price,
        }));

    const handleOrderClick = (itemName: string) => {
        setInitialChatMessage(`I would like to order one ${itemName}.`);
        setActivePage('order');
    };

    return (
        <div className="bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 min-h-full">
            <div className="container mx-auto px-4 py-8">
                <h1 className="text-4xl font-bold text-center text-indigo-600 dark:text-indigo-400 mb-8">
                    Our Gallery
                </h1>
                <p className="text-center text-lg text-gray-600 dark:text-gray-300 mb-12 max-w-2xl mx-auto">
                    A glimpse into the delicious world of Stanley's Cafe. Every dish is a story, and every picture a memory.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {images.map((image) => (
                        <div key={image.id} className="group rounded-lg shadow-lg flex flex-col overflow-hidden transform transition-transform duration-300 hover:-translate-y-1">
                            <div className="relative h-64">
                                <img
                                    src={image.src}
                                    alt={image.alt}
                                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                                />
                            </div>
                            <div className="p-4 bg-white dark:bg-gray-800 flex-grow flex flex-col">
                                <h3 className="font-semibold text-lg flex-grow">{image.alt}</h3>
                                <div className="flex justify-between items-center mt-2">
                                    <p className="font-bold text-indigo-600 dark:text-indigo-400">${image.price.toFixed(2)}</p>
                                    <button 
                                        onClick={() => handleOrderClick(image.alt)}
                                        className="px-4 py-2 bg-indigo-500 text-white text-sm font-semibold rounded-lg shadow-md hover:bg-indigo-600 transition-colors"
                                    >
                                        Order
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                     {images.length === 0 && (
                        <div className="col-span-full text-center py-20">
                            <p className="text-gray-500 dark:text-gray-400">The gallery is currently empty. Check back soon!</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default GalleryPage;
