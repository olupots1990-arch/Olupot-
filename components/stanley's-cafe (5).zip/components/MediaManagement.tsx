

import React, { useRef, useState, useEffect } from 'react';
import { UploadIcon, SparklesIcon, XCircleIcon, FilmIcon, FolderIcon, PlusCircleIcon, EditIcon, TrashIcon, MusicIcon, CloseIcon } from './icons';
import type { BackgroundMedia, Advertisement, MenuItem } from '../types';
import { VoiceoverAsset } from '../types';
import AIVideoGenerator from './AIVideoGenerator';
import AIVoiceoverGenerator from './AIVoiceoverGenerator';
import AIMusicGenerator from './AIMusicGenerator';
import TransitionPreview from './TransitionPreview';
import AdvertisementModal from './AdvertisementModal';

interface MediaManagementProps {
    backgroundVideos: (BackgroundMedia | null)[];
    setBackgroundVideos: React.Dispatch<React.SetStateAction<(BackgroundMedia | null)[]>>;
    backgroundImages: (BackgroundMedia | null)[];
    setBackgroundImages: React.Dispatch<React.SetStateAction<(BackgroundMedia | null)[]>>;
    backgroundMusicUrl: string | null;
    onMusicChange: React.Dispatch<React.SetStateAction<string | null>>;
    mediaLibrary: BackgroundMedia[];
    setMediaLibrary: React.Dispatch<React.SetStateAction<BackgroundMedia[]>>;
    voiceoverLibrary: VoiceoverAsset[];
    setVoiceoverLibrary: React.Dispatch<React.SetStateAction<VoiceoverAsset[]>>;
    advertisements: Advertisement[];
    setAdvertisements: React.Dispatch<React.SetStateAction<Advertisement[]>>;
    galleryProductIds: string[];
    setGalleryProductIds: React.Dispatch<React.SetStateAction<string[]>>;
    menuItems: MenuItem[];
    isOnline: boolean;
}

const isVideoFile = (file: File) => file.type.startsWith('video/');
const isVideoUrl = (url: string) => /\.(mp4|webm|ogg|mov)$/i.test(url) || url.startsWith('blob:');

export const MediaManagement: React.FC<MediaManagementProps> = ({ 
    backgroundVideos, setBackgroundVideos, 
    backgroundImages, setBackgroundImages,
    backgroundMusicUrl, onMusicChange,
    mediaLibrary, setMediaLibrary,
    voiceoverLibrary, setVoiceoverLibrary,
    advertisements, setAdvertisements,
    galleryProductIds, setGalleryProductIds,
    menuItems,
    isOnline
}) => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const voiceoverFileInputRef = useRef<HTMLInputElement>(null);
    const musicFileInputRef = useRef<HTMLInputElement>(null);
    const [editingSlot, setEditingSlot] = useState<{ type: 'video' | 'image', index: number} | null>(null);
    const [voiceoverUploadTarget, setVoiceoverUploadTarget] = useState<number | null>(null);
    const [previewingIndex, setPreviewingIndex] = useState<number | null>(null);
    const [isAIVideoOpen, setIsAIVideoOpen] = useState(false);
    const [isAIVoiceoverOpen, setIsAIVoiceoverOpen] = useState(false);
    const [isAIMusicOpen, setIsAIMusicOpen] = useState(false);
    const [isAdModalOpen, setIsAdModalOpen] = useState(false);
    const [editingAd, setEditingAd] = useState<Advertisement | null>(null);
    const [isVoiceoverChoiceOpen, setIsVoiceoverChoiceOpen] = useState(false);
    const [editingTransition, setEditingTransition] = useState<{ type: 'video' | 'image', index: number, target: HTMLElement } | null>(null);
    const popoverRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const popoverNode = popoverRef.current;
        const targetNode = editingTransition?.target;

        if (popoverNode && targetNode) {
            const targetRect = targetNode.getBoundingClientRect();
            popoverNode.style.position = 'fixed';
            popoverNode.style.top = `${targetRect.bottom + 8}px`;
            popoverNode.style.left = `${targetRect.left}px`;

            const popoverRect = popoverNode.getBoundingClientRect();
            if (popoverRect.right > window.innerWidth - 16) {
                popoverNode.style.left = `${targetRect.right - popoverRect.width}px`;
            }
             if (popoverRect.left < 16) {
                popoverNode.style.left = `16px`;
            }
        }
    
        const handleClickOutside = (event: MouseEvent) => {
            if (
                popoverRef.current &&
                !popoverRef.current.contains(event.target as Node) &&
                editingTransition?.target &&
                !editingTransition.target.contains(event.target as Node)
            ) {
                setEditingTransition(null);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [editingTransition]);

    const handleFileSelect = (type: 'video' | 'image', index: number) => {
        setEditingSlot({ type, index });
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file && editingSlot) {
            const isVideo = isVideoFile(file);
            const newMedia: BackgroundMedia = {
                url: URL.createObjectURL(file),
                type: isVideo ? 'video' : 'image',
                transitionType: isVideo ? 'slide' : 'fade',
                transitionDuration: 1.5,
            };

            setMediaLibrary(prev => [...prev, newMedia]);
            
            if (editingSlot.type === 'video' && isVideo) {
                setBackgroundVideos(prev => {
                    const newVideos = [...prev];
                    newVideos[editingSlot.index] = newMedia;
                    return newVideos;
                });
            } else if (editingSlot.type === 'image' && !isVideo) {
                setBackgroundImages(prev => {
                    const newImages = [...prev];
                    newImages[editingSlot.index] = newMedia;
                    return newImages;
                });
            } else {
                alert(`Please upload a ${editingSlot.type} file.`);
            }
        }
        setEditingSlot(null);
        if (e.target) e.target.value = ''; // Reset file input
    };
    
    const handleVoiceoverFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file && voiceoverUploadTarget !== null) {
            if (!file.type.startsWith('audio/')) {
                alert('Please upload a valid audio file.');
                if (e.target) e.target.value = '';
                return;
            }
            const url = URL.createObjectURL(file);
            const newVoiceover: VoiceoverAsset = {
                url,
                script: `Uploaded: ${file.name}`
            };

            setVoiceoverLibrary(prev => [...prev, newVoiceover]);

            setBackgroundVideos(prev => {
                const newVideos = [...prev];
                const targetVideo = newVideos[voiceoverUploadTarget];
                if(targetVideo) {
                    newVideos[voiceoverUploadTarget] = { ...targetVideo, voiceoverUrl: url };
                }
                return newVideos;
            });
            
            setIsVoiceoverChoiceOpen(false);
            setVoiceoverUploadTarget(null);
            if (e.target) e.target.value = '';
        }
    };

    const handleAIVideoGenerated = (media: BackgroundMedia) => {
        setMediaLibrary(prev => [...prev, media]);
        if (editingSlot?.type === 'video') {
            setBackgroundVideos(prev => {
                const newVideos = [...prev];
                newVideos[editingSlot.index] = media;
                return newVideos;
            });
        }
        setIsAIVideoOpen(false);
        setEditingSlot(null);
    };

    const handleAIVoiceoverGenerated = (url: string, script: string) => {
        setVoiceoverLibrary(prev => [...prev, { url, script }]);
        if (voiceoverUploadTarget !== null) {
            setBackgroundVideos(prev => {
                const newVideos = [...prev];
                const targetVideo = newVideos[voiceoverUploadTarget];
                if(targetVideo) {
                    newVideos[voiceoverUploadTarget] = { ...targetVideo, voiceoverUrl: url };
                }
                return newVideos;
            });
        }
        setIsAIVoiceoverOpen(false);
    };

    const handleAIMusicGenerated = (url: string) => {
        onMusicChange(url);
        setIsAIMusicOpen(false);
    };
    
    const handleSaveAd = (ad: Advertisement) => {
        if (editingAd) { // Update existing
            setAdvertisements(prev => prev.map(a => a.id === ad.id ? ad : (ad.isActive ? {...a, isActive: false} : a)));
        } else { // Create new
            const newAd = { ...ad, id: `ad-${Date.now()}` };
            setAdvertisements(prev => [...prev.map(a => newAd.isActive ? {...a, isActive: false} : a), newAd]);
        }
        setIsAdModalOpen(false);
        setEditingAd(null);
    };
    
    const handleDeleteAd = (adId: string) => {
        setAdvertisements(prev => prev.filter(a => a.id !== adId));
    };

    const handleGalleryProductToggle = (productId: string) => {
        setGalleryProductIds(prevIds => {
            if (prevIds.includes(productId)) {
                return prevIds.filter(id => id !== productId);
            } else {
                return [...prevIds, productId];
            }
        });
    };
    
    const handleTransitionChange = (field: 'transitionType' | 'transitionDuration', value: string | number) => {
        if (!editingTransition) return;

        const { type, index } = editingTransition;
        const updater = (prev: (BackgroundMedia | null)[]) => {
            const newArr = [...prev];
            const media = newArr[index];
            if (media) {
                newArr[index] = { ...media, [field]: field === 'transitionDuration' ? Number(value) : value };
            }
            return newArr;
        };

        if (type === 'video') {
            setBackgroundVideos(updater);
        } else {
            setBackgroundImages(updater);
        }
    };

    const currentEditingMedia = editingTransition ? (editingTransition.type === 'video' ? backgroundVideos[editingTransition.index] : backgroundImages[editingTransition.index]) : null;

    const MediaSlot: React.FC<{
        media: BackgroundMedia | null;
        type: 'video' | 'image';
        index: number;
    }> = ({ media, type, index }) => (
        <div className="relative aspect-video bg-gray-200 dark:bg-gray-700 rounded-lg group overflow-hidden">
            {media ? (
                <>
                    { isVideoUrl(media.url) ? (
                        <video key={media.url} src={media.url} muted loop autoPlay playsInline className="w-full h-full object-cover" />
                    ) : (
                        <img src={media.url} alt={`Background ${type} ${index + 1}`} className="w-full h-full object-cover" />
                    )}
                    {media.voiceoverUrl && (
                        <div className="absolute bottom-1 left-1 bg-black/60 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                            <MusicIcon className="w-3 h-3"/> Voiceover Added
                        </div>
                    )}
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-2">
                        <button onClick={() => {
                            const combinedPlaylist = [...backgroundVideos, ...backgroundImages].filter(Boolean) as BackgroundMedia[];
                            const globalIndex = type === 'video' ? index : backgroundVideos.filter(Boolean).length + index;
                            setPreviewingIndex(globalIndex);
                        }} className="text-white text-xs bg-black/60 px-2 py-1 rounded">Preview Transition</button>
                        <button onClick={(e) => setEditingTransition({ type, index, target: e.currentTarget as HTMLElement })} className="text-white text-xs bg-black/60 px-2 py-1 rounded flex items-center gap-1">
                            <EditIcon className="w-3 h-3"/> Edit Transition
                        </button>
                        {type === 'video' && (
                             <button onClick={() => { setVoiceoverUploadTarget(index); setIsVoiceoverChoiceOpen(true); }} className="text-white text-xs bg-black/60 px-2 py-1 rounded disabled:opacity-50">
                                {media.voiceoverUrl ? 'Change Voiceover' : 'Add Voiceover'}
                             </button>
                        )}
                        <button onClick={() => {
                            if (type === 'video') setBackgroundVideos(p => p.map((v, i) => i === index ? null : v));
                            else setBackgroundImages(p => p.map((img, i) => i === index ? null : img));
                        }} className="absolute top-1 right-1 p-1.5 bg-black/60 rounded-full text-white"><XCircleIcon className="w-5 h-5"/></button>
                    </div>
                </>
            ) : (
                <div className="flex flex-col items-center justify-center h-full">
                    <button onClick={() => handleFileSelect(type, index)} className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600">
                        <UploadIcon className="w-4 h-4"/> Upload {type}
                    </button>
                    <button onClick={() => { setEditingSlot({type, index}); setIsAIVideoOpen(true); }} disabled={!isOnline} className="mt-2 flex items-center gap-2 px-3 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed">
                        <SparklesIcon className="w-4 h-4" /> AI Generate
                    </button>
                </div>
            )}
        </div>
    );

    return (
        <div className="p-6 space-y-6">
            <input type="file" accept="image/*,video/*" ref={fileInputRef} className="hidden" onChange={handleFileChange} />
            <input type="file" accept="audio/*" ref={voiceoverFileInputRef} className="hidden" onChange={handleVoiceoverFileChange} />
            
            <div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Homepage Slideshow</h3>
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                    Manage the videos and images that appear on your website's homepage. Videos with voiceovers will play for the duration of the audio.
                </p>
                {!isOnline && <p className="mt-2 text-xs text-red-500 p-2 bg-red-100 dark:bg-red-900/50 rounded-md">AI generation features are disabled while offline.</p>}
            </div>
            
            <div className="relative grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="col-span-full font-semibold text-lg flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                        <FilmIcon className="w-5 h-5"/>
                        <span>Background Videos</span>
                    </div>
                    <button 
                        onClick={() => alert('Manage background videos functionality can be implemented here.')}
                        className="px-3 py-1 text-xs font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700"
                    >
                        Manage Background Videos
                    </button>
                </div>
                {backgroundVideos.map((video, index) => <MediaSlot key={`video-${index}`} media={video} type="video" index={index} />)}
                <h4 className="col-span-full font-semibold text-lg flex items-center gap-2"><FolderIcon className="w-5 h-5"/> Background Images</h4>
                {backgroundImages.map((image, index) => <MediaSlot key={`image-${index}`} media={image} type="image" index={index} />)}
            </div>
             {editingTransition && currentEditingMedia && (
                <div
                    ref={popoverRef}
                    className="absolute z-20 bg-white dark:bg-gray-900 rounded-lg shadow-xl p-4 border dark:border-gray-700 w-64 space-y-4"
                >
                    <div className="flex justify-between items-center">
                        <h4 className="font-semibold text-gray-800 dark:text-gray-200">Transition Settings</h4>
                        <button onClick={() => setEditingTransition(null)} className="p-1 rounded-full text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700">
                            <CloseIcon className="w-5 h-5"/>
                        </button>
                    </div>
                    
                    <div>
                        <label htmlFor="transitionType" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Effect</label>
                        <select
                            id="transitionType"
                            value={currentEditingMedia.transitionType || 'fade'}
                            onChange={(e) => handleTransitionChange('transitionType', e.target.value)}
                            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                        >
                            <option value="fade">Fade</option>
                            <option value="slide">Slide</option>
                            <option value="zoom">Zoom</option>
                            <option value="rotate">Rotate</option>
                        </select>
                    </div>
                    
                    <div>
                        <label htmlFor="transitionDuration" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                            Duration: <span className="font-bold">{currentEditingMedia.transitionDuration?.toFixed(1) || '1.5'}s</span>
                        </label>
                        <input
                            id="transitionDuration"
                            type="range"
                            min="0.5"
                            max="5"
                            step="0.1"
                            value={currentEditingMedia.transitionDuration || 1.5}
                            onChange={(e) => handleTransitionChange('transitionDuration', parseFloat(e.target.value))}
                            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                        />
                    </div>
                </div>
            )}

            <div className="pt-4 border-t dark:border-gray-700 space-y-4">
                 <h3 className="text-xl font-bold">Homepage Music</h3>
                 <div className="flex flex-col sm:flex-row items-center gap-3 p-4 bg-gray-50 dark:bg-gray-900/40 rounded-lg">
                    <div className="flex-1">
                        {backgroundMusicUrl ? <audio src={backgroundMusicUrl} controls className="w-full"/> : <p className="text-sm text-gray-500">No background music selected.</p>}
                    </div>
                    <div className="flex items-center gap-2">
                        <input type="file" accept="audio/*" ref={musicFileInputRef} className="hidden" onChange={e => e.target.files?.[0] && onMusicChange(URL.createObjectURL(e.target.files[0]))} />
                        <button onClick={() => musicFileInputRef.current?.click()} className="px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600">Upload</button>
                        <button onClick={() => setIsAIMusicOpen(true)} disabled={!isOnline} className="px-3 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700 disabled:opacity-50">AI Generate</button>
                        {backgroundMusicUrl && <button onClick={() => onMusicChange(null)} className="p-2 text-red-500 rounded-md hover:bg-red-100 dark:hover:bg-red-900/50"><TrashIcon className="w-5 h-5"/></button>}
                    </div>
                 </div>
            </div>

            <div className="pt-4 border-t dark:border-gray-700 space-y-4">
                <div className="flex justify-between items-center">
                    <h3 className="text-xl font-bold">Advertisements Banner</h3>
                     <button onClick={() => { setEditingAd(null); setIsAdModalOpen(true); }} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg shadow-sm hover:bg-green-700">
                        <PlusCircleIcon className="w-5 h-5"/> Create Ad
                    </button>
                </div>
                <div className="space-y-3">
                    {advertisements.map(ad => (
                        <div key={ad.id} className="p-3 bg-gray-50 dark:bg-gray-900/40 rounded-lg flex items-center justify-between">
                           <div>
                             <p className="font-semibold">{ad.title} {ad.isActive && <span className="ml-2 text-xs font-bold text-green-600 dark:text-green-400">(ACTIVE)</span>}</p>
                             <p className="text-sm text-gray-600 dark:text-gray-400">{ad.description}</p>
                           </div>
                            <div className="flex items-center gap-2">
                                <button onClick={() => { setEditingAd(ad); setIsAdModalOpen(true); }} className="p-2 text-indigo-600 rounded-md hover:bg-indigo-100 dark:hover:bg-indigo-900/50"><EditIcon className="w-5 h-5"/></button>
                                <button onClick={() => handleDeleteAd(ad.id)} className="p-2 text-red-600 rounded-md hover:bg-red-100 dark:hover:bg-red-900/50"><TrashIcon className="w-5 h-5"/></button>
                            </div>
                        </div>
                    ))}
                    {advertisements.length === 0 && <p className="text-sm text-center text-gray-500 py-4">No advertisements created yet.</p>}
                </div>
            </div>

            <div className="pt-4 border-t dark:border-gray-700 space-y-4">
                <h3 className="text-xl font-bold">Website Gallery</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Select which menu items to display on the public Gallery page.</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {menuItems.map(item => (
                        <div key={item.id} className="p-3 bg-gray-50 dark:bg-gray-900/40 rounded-lg flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <img src={item.imageUrl} alt={item.name} className="w-12 h-12 rounded-md object-cover"/>
                                <span className="font-medium text-sm">{item.name}</span>
                            </div>
                            <label className="relative inline-flex items-center cursor-pointer">
                                <input
                                    type="checkbox"
                                    checked={galleryProductIds.includes(item.id)}
                                    onChange={() => handleGalleryProductToggle(item.id)}
                                    className="sr-only peer"
                                />
                                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 dark:peer-focus:ring-indigo-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-indigo-600"></div>
                            </label>
                        </div>
                    ))}
                </div>
            </div>

            {isVoiceoverChoiceOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-[60] p-4">
                    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-sm">
                        <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                            <h3 className="text-lg font-bold">Add Voiceover</h3>
                            <button onClick={() => setIsVoiceoverChoiceOpen(false)}><CloseIcon className="w-6 h-6"/></button>
                        </header>
                        <div className="p-6 space-y-4">
                            <p className="text-sm text-gray-600 dark:text-gray-300">
                                Choose how you would like to add a voiceover to your video.
                            </p>
                            <button
                                onClick={() => {
                                    setIsVoiceoverChoiceOpen(false);
                                    setIsAIVoiceoverOpen(true);
                                }}
                                disabled={!isOnline}
                                className="w-full flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700 disabled:opacity-50"
                            >
                                <SparklesIcon className="w-5 h-5" />
                                AI Generate Voiceover
                            </button>
                            <button
                                onClick={() => {
                                    voiceoverFileInputRef.current?.click();
                                }}
                                className="w-full flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600"
                            >
                                <UploadIcon className="w-5 h-5" />
                                Upload Audio File
                            </button>
                        </div>
                    </div>
                </div>
            )}
            {isAIVideoOpen && <AIVideoGenerator onClose={() => setIsAIVideoOpen(false)} onMediaGenerated={handleAIVideoGenerated} />}
            {isAIVoiceoverOpen && <AIVoiceoverGenerator onClose={() => setIsAIVoiceoverOpen(false)} onVoiceoverGenerated={handleAIVoiceoverGenerated} />}
            {isAIMusicOpen && <AIMusicGenerator onClose={() => setIsAIMusicOpen(false)} onMusicGenerated={handleAIMusicGenerated} />}
            {isAdModalOpen && <AdvertisementModal advertisement={editingAd} onSave={handleSaveAd} onClose={() => setIsAdModalOpen(false)} menuItems={menuItems} />}
            {previewingIndex !== null && (
                <TransitionPreview 
                    mediaItems={[...backgroundVideos, ...backgroundImages].filter(Boolean) as BackgroundMedia[]}
                    startIndex={previewingIndex}
                    onClose={() => setPreviewingIndex(null)}
                />
            )}
        </div>
    );
};