import React from 'react';
import { FolderIcon } from './icons';

interface PathStepProps {
    installPath: string;
    onPathChange: (path: string) => void;
}

const PathStep: React.FC<PathStepProps> = ({ installPath, onPathChange }) => {
    const handleBrowse = async () => {
        // The File System Access API is a modern API and may not be supported in all browsers.
        // @ts-ignore
        if ('showDirectoryPicker' in window) {
            try {
                // @ts-ignore
                const dirHandle = await window.showDirectoryPicker();
                // We can't get the full path for security reasons.
                // For this simulation, we'll show a representation of the selected folder.
                onPathChange(`...\\${dirHandle.name}\\Stanley's Cafe`);
            } catch (err) {
                // User may have cancelled the picker.
                console.log('User cancelled directory picker or an error occurred.', err);
            }
        } else {
            alert('Your browser does not support selecting a directory. Please type the path manually.');
        }
    };

    return (
        <div>
            <h2 className="text-xl font-semibold">Choose Install Location</h2>
            <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                Setup will install Stanley's Cafe in the following folder.
            </p>
            <div className="mt-6">
                <label htmlFor="install-path" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Destination Folder
                </label>
                <div className="mt-1 flex rounded-md shadow-sm">
                    <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-100 text-gray-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300 sm:text-sm">
                        <FolderIcon className="w-5 h-5" />
                    </span>
                    <input
                        type="text"
                        id="install-path"
                        value={installPath}
                        onChange={(e) => onPathChange(e.target.value)}
                        className="block w-full min-w-0 flex-1 rounded-none border-gray-300 bg-white dark:bg-gray-900 dark:border-gray-600 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                    />
                    <button
                        type="button"
                        onClick={handleBrowse}
                        className="relative -ml-px inline-flex items-center space-x-2 rounded-r-md border border-gray-300 bg-gray-100 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-200 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600"
                    >
                        Browse...
                    </button>
                </div>
            </div>
            <div className="mt-6 text-sm text-gray-500 dark:text-gray-400 space-y-2">
                <p>Setup requires at least <span className="font-semibold">10.5 MB</span> of free disk space.</p>
                <p>Space required: <span className="font-semibold">5.2 MB</span></p>
                <p>Space available: <span className="font-semibold">102.4 GB</span></p>
            </div>
        </div>
    );
};

export default PathStep;
