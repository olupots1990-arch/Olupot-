import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import type { BackgroundMedia, Advertisement, MenuItem } from '../types';
import { Volume2Icon, VolumeXIcon, CloseIcon } from './icons';

interface HomePageProps {
  backgroundVideos: (BackgroundMedia | null)[];
  backgroundImages: (BackgroundMedia | null)[];
  backgroundMusicUrl: string | null;
  onNavigate: () => void;
  advertisements: Advertisement[];
  menuItems: MenuItem[];
}

const SLIDESHOW_INTERVAL = 10000; // 10 seconds for images and videos without voiceovers

const HomePage: React.FC<HomePageProps> = ({ backgroundVideos, backgroundImages, onNavigate, backgroundMusicUrl, advertisements, menuItems }) => {
  const [playlist, setPlaylist] = useState<(BackgroundMedia)[]>([]);
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [exitingIndex, setExitingIndex] = useState<number | null>(null);
  
  const voiceoverAudioRef = useRef<HTMLAudioElement | null>(null);
  const musicAudioRef = useRef<HTMLAudioElement | null>(null);
  const [isMusicMuted, setIsMusicMuted] = useState(true);
  const [isAdVisible, setIsAdVisible] = useState(true);

  const activeAd = useMemo(() => advertisements.find(ad => ad.isActive), [advertisements]);
  const adImage = useMemo(() => {
    if (!activeAd) return null;
    if (activeAd.imageUrl) return activeAd.imageUrl;
    const menuItem = menuItems.find(item => item.id === activeAd.productId);
    return menuItem?.imageUrl || null;
  }, [activeAd, menuItems]);

  useEffect(() => {
    const slideshowMedia = [
        ...backgroundVideos.filter(Boolean) as BackgroundMedia[],
        ...backgroundImages.filter(Boolean) as BackgroundMedia[]
    ];
    
    setPlaylist(slideshowMedia);
    setCurrentIndex(0);
    setExitingIndex(null);
  }, [backgroundVideos, backgroundImages]);

  useEffect(() => {
    const advance = () => {
        if (playlist.length <= 1) return;

        setCurrentIndex(prevCurrentIndex => {
            const exitingMedia = playlist[prevCurrentIndex];
            if (exitingMedia) {
                const duration = (exitingMedia.transitionDuration || 1.5) * 1000;
                setExitingIndex(prevCurrentIndex);
                setTimeout(() => setExitingIndex(null), duration);
            }
            return (prevCurrentIndex + 1) % playlist.length;
        });
    };

    if (exitingIndex !== null) {
        return; // Don't start a new timer/audio while a transition is happening
    }

    const currentMedia = playlist[currentIndex];
    if (!currentMedia) {
        return;
    }

    let timerId: number | null = null;
    let audio: HTMLAudioElement | null = null;
    const handleEnd = () => advance();

    if (currentMedia.type === 'video' && currentMedia.voiceoverUrl) {
        audio = new Audio(currentMedia.voiceoverUrl);
        voiceoverAudioRef.current = audio;
        
        audio.addEventListener('ended', handleEnd);
        audio.addEventListener('error', (e) => {
            console.error("Voiceover error:", e);
            handleEnd();
        });
        audio.play().catch(e => {
            console.error("Audio play failed:", e);
            handleEnd();
        });

    } else {
        timerId = window.setTimeout(advance, SLIDESHOW_INTERVAL);
    }

    return () => {
        if (timerId) clearTimeout(timerId);
        if (audio) {
            audio.removeEventListener('ended', handleEnd);
            audio.removeEventListener('error', handleEnd);
            audio.pause();
            voiceoverAudioRef.current = null;
        }
    };
  }, [currentIndex, exitingIndex, playlist]);


  useEffect(() => {
    if (musicAudioRef.current) {
        if (backgroundMusicUrl) {
            if (musicAudioRef.current.src !== backgroundMusicUrl) {
                musicAudioRef.current.src = backgroundMusicUrl;
            }
            musicAudioRef.current.play().catch(e => console.error("Background music auto-play failed. User interaction needed.", e));
        } else {
            musicAudioRef.current.pause();
            musicAudioRef.current.src = '';
        }
    }
  }, [backgroundMusicUrl]);

  const toggleMusicMute = () => {
      if(musicAudioRef.current) {
          const newMutedState = !musicAudioRef.current.muted;
          musicAudioRef.current.muted = newMutedState;
          setIsMusicMuted(newMutedState);
      }
  };

  const MediaItem: React.FC<{ media: BackgroundMedia; isActive: boolean; isExiting: boolean; }> = ({ media, isActive, isExiting }) => {
    const { url, type } = media;
    const isVideo = type === 'video';
    
    let animationClass = '';
    // Transition is based on the OUTGOING slide's properties
    const transitionMedia = isExiting ? media : (exitingIndex !== null ? playlist[exitingIndex] : null);
    
    const transitionType = transitionMedia?.transitionType || 'fade';
    const transitionDuration = transitionMedia?.transitionDuration || 1.5;

    if (isActive && exitingIndex !== null) {
        switch(transitionType) {
            case 'slide': animationClass = 'animate-slide-in-new'; break;
            case 'zoom': animationClass = 'animate-zoom-in'; break;
            case 'rotate': animationClass = 'animate-rotate-in'; break;
            default: animationClass = 'animate-fade-in'; break;
        }
    }
    if (isExiting) {
        switch(transitionType) {
            case 'slide': animationClass = 'animate-slide-out-old'; break;
            case 'zoom': animationClass = 'animate-zoom-out'; break;
            case 'rotate': animationClass = 'animate-rotate-out'; break;
            default: animationClass = 'animate-fade-out'; break;
        }
    }
    
    if (!isActive && !isExiting) return null;

    return (
      <div
        className={`absolute inset-0 w-full h-full ${animationClass}`}
        style={{ animationDuration: `${transitionDuration}s`, zIndex: isExiting ? 1 : 2 }}
      >
        {isVideo ? (
          <video
            key={url}
            className="w-full h-full object-cover"
            src={url}
            autoPlay
            loop
            muted
            playsInline
          />
        ) : (
          <img src={url} className="w-full h-full object-cover" alt="Restaurant background" />
        )}
      </div>
    );
  };
  
  return (
    <div className="relative w-full h-full text-center text-white flex flex-col items-center justify-center overflow-hidden">
      {isAdVisible && activeAd && (
        <div className="absolute top-0 left-0 right-0 bg-indigo-600 p-3 z-20 flex items-center justify-center shadow-lg animate-slide-down-ad">
            <div className="flex items-center gap-4">
                {adImage && <img src={adImage} alt={activeAd.title} className="w-12 h-12 rounded-md object-cover hidden sm:block" />}
                <div>
                    <h3 className="font-bold text-sm sm:text-base">{activeAd.title}</h3>
                    <p className="text-xs sm:text-sm">{activeAd.description}</p>
                </div>
                <button onClick={onNavigate} className="ml-4 px-3 py-1 bg-white text-indigo-600 font-semibold rounded-full text-xs sm:text-sm hover:bg-indigo-100 flex-shrink-0">
                    Order Now
                </button>
            </div>
            <button onClick={() => setIsAdVisible(false)} className="absolute top-1/2 -translate-y-1/2 right-3 p-1 text-white hover:bg-white/20 rounded-full">
                <CloseIcon className="w-5 h-5" />
            </button>
        </div>
      )}
      {playlist.map((media, index) => 
        media && (
        <MediaItem 
          key={`${index}-${media.url}`} 
          media={media} 
          isActive={index === currentIndex} 
          isExiting={index === exitingIndex}
        />
      ))}
      <audio ref={musicAudioRef} loop playsInline autoPlay muted={isMusicMuted} />
      <div className="absolute inset-0 bg-black bg-opacity-50 backdrop-blur-sm"></div>
      <div className="relative z-10 p-4 flex flex-col items-center">
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-shadow-lg animate-slide-in">Welcome to Stanley's Cafe</h1>
        <p className="mt-4 text-lg md:text-xl max-w-2xl mx-auto text-shadow">
          Delicious meals, friendly atmosphere, and an AI-powered ordering experience.
        </p>
        <div className="mt-8">
            <button
              onClick={onNavigate}
              className="px-8 py-3 bg-indigo-500 text-white font-semibold rounded-lg shadow-lg hover:bg-indigo-600 transition-transform transform hover:scale-105"
            >
              Order Now
            </button>
        </div>
      </div>
      {backgroundMusicUrl && (
        <button 
            onClick={toggleMusicMute}
            className="absolute bottom-4 right-4 z-20 bg-black/50 p-3 rounded-full text-white hover:bg-black/80 transition-colors"
            aria-label={isMusicMuted ? "Unmute background music" : "Mute background music"}
        >
            {isMusicMuted ? <VolumeXIcon className="w-6 h-6" /> : <Volume2Icon className="w-6 h-6" />}
        </button>
      )}
      <style>{`
        .text-shadow { text-shadow: 2px 2px 4px rgba(0,0,0,0.7); }
        .text-shadow-lg { text-shadow: 3px 3px 6px rgba(0,0,0,0.7); }
        @keyframes slideInFromRight {
          0% { transform: translateX(100%); opacity: 0; }
          100% { transform: translateX(0); opacity: 1; }
        }
        .animate-slide-in { animation: slideInFromRight 1s ease-out forwards; }
        
        @keyframes slideDownAd {
          from { transform: translateY(-100%); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .animate-slide-down-ad { animation: slideDownAd 0.5s ease-out forwards; }

        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        .animate-fade-in { animation: fadeIn ease-in-out forwards; }

        @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
        .animate-fade-out { animation: fadeOut ease-in-out forwards; }

        @keyframes slideInNew { from { transform: translateX(100%); } to { transform: translateX(0); } }
        .animate-slide-in-new { animation: slideInNew ease-in-out forwards; }
        
        @keyframes slideOutOld { from { transform: translateX(0); } to { transform: translateX(-100%); } }
        .animate-slide-out-old { animation: slideOutOld ease-in-out forwards; }

        @keyframes zoomIn { from { transform: scale(1.2); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        .animate-zoom-in { animation: zoomIn ease-in-out forwards; }

        @keyframes zoomOut { from { transform: scale(1); opacity: 1; } to { transform: scale(0.8); opacity: 0; } }
        .animate-zoom-out { animation: zoomOut ease-in-out forwards; }

        @keyframes rotateIn { from { transform: rotate(-25deg) scale(0.7); opacity: 0; } to { transform: rotate(0) scale(1); opacity: 1; } }
        .animate-rotate-in { animation: rotateIn cubic-bezier(0.25, 1, 0.5, 1) forwards; }
        
        @keyframes rotateOut { from { transform: rotate(0) scale(1); opacity: 1; } to { transform: rotate(25deg) scale(0.7); opacity: 0; } }
        .animate-rotate-out { animation: rotateOut cubic-bezier(0.5, 0, 0.75, 0) forwards; }
      `}</style>
    </div>
  );
};

export default HomePage;