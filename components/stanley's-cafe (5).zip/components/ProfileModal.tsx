import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { User } from '../types';
import { CameraIcon, CloseIcon, UploadIcon, TrashIcon } from './icons';

interface ProfileModalProps {
    user: User;
    onClose: () => void;
    onSave: (dataUrl: string | null) => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({ user, onClose, onSave }) => {
    const [view, setView] = useState<'default' | 'camera' | 'preview'>('default');
    const [capturedImage, setCapturedImage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const stopCamera = useCallback(() => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
    }, []);
    
    const startCamera = useCallback(async () => {
        stopCamera();
        setError(null);
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 480, height: 480 } });
            streamRef.current = stream;
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
            }
        } catch (err) {
            console.error("Error accessing camera:", err);
            setError("Could not access the camera. Please check permissions.");
            setView('default');
        }
    }, [stopCamera]);

    useEffect(() => {
        if (view === 'camera') {
            startCamera();
        } else {
            stopCamera();
        }
        // Ensure camera is stopped when component unmounts
        return stopCamera;
    }, [view, startCamera, stopCamera]);
    
    const handleCapture = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            context?.drawImage(video, 0, 0, canvas.width, canvas.height);
            const dataUrl = canvas.toDataURL('image/jpeg');
            setCapturedImage(dataUrl);
            setView('preview');
        }
    };
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                onSave(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const renderContent = () => {
        switch (view) {
            case 'camera':
                return (
                    <>
                        <video ref={videoRef} autoPlay playsInline className="w-full h-64 bg-black rounded-md" />
                        <div className="flex justify-center gap-4 mt-4">
                            <button onClick={() => setView('default')} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 rounded-md">Cancel</button>
                            <button onClick={handleCapture} className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Capture</button>
                        </div>
                    </>
                );
            case 'preview':
                return (
                    <>
                        <img src={capturedImage!} alt="Capture preview" className="w-full h-64 object-cover bg-black rounded-md" />
                         <div className="flex justify-center gap-4 mt-4">
                            <button onClick={() => setView('camera')} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 rounded-md">Retake</button>
                            <button onClick={() => onSave(capturedImage)} className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Use Photo</button>
                        </div>
                    </>
                );
            case 'default':
            default:
                return (
                    <>
                        <div className="flex items-center justify-center">
                             <img
                                src={user.profilePictureUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=random`}
                                alt={user.name}
                                className="w-32 h-32 rounded-full object-cover"
                            />
                        </div>
                        {error && <p className="text-center text-red-500 text-sm mt-2">{error}</p>}
                        <div className="mt-6 grid grid-cols-1 gap-3">
                            <button onClick={() => setView('camera')} className="w-full flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700">
                                <CameraIcon className="w-5 h-5" /> Take Photo
                            </button>
                            <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                            <button onClick={() => fileInputRef.current?.click()} className="w-full flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600">
                                <UploadIcon className="w-5 h-5" /> Upload Photo
                            </button>
                            {user.profilePictureUrl && (
                                <button onClick={() => onSave(null)} className="w-full flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-red-700 bg-red-100 border border-transparent rounded-md hover:bg-red-200 dark:bg-red-900/50 dark:text-red-200 dark:hover:bg-red-900">
                                    <TrashIcon className="w-5 h-5" /> Remove Photo
                                </button>
                            )}
                        </div>
                    </>
                );
        }
    };


    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-sm max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">Profile Photo</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </header>
                <main className="p-6">
                    {renderContent()}
                    <canvas ref={canvasRef} className="hidden" />
                </main>
            </div>
        </div>
    );
};

export default ProfileModal;
