import React, { useState, useMemo, useRef } from 'react';
import type { Advertisement, MenuItem } from '../types';
import { CloseIcon, UploadIcon, TrashIcon, ImageIcon } from './icons';

interface AdvertisementModalProps {
    advertisement: Advertisement | null;
    onSave: (ad: Advertisement) => void;
    onClose: () => void;
    menuItems: MenuItem[];
}

const AdvertisementModal: React.FC<AdvertisementModalProps> = ({ advertisement, onSave, onClose, menuItems }) => {
    const [formData, setFormData] = useState<Advertisement>(
        advertisement || {
            id: '',
            productId: menuItems[0]?.id || '',
            title: '',
            description: '',
            isActive: false,
            imageUrl: undefined,
        }
    );
    const [imageFile, setImageFile] = useState<File | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const imagePreviewUrl = useMemo(() => {
        if (imageFile) return URL.createObjectURL(imageFile);
        if (formData.imageUrl) return formData.imageUrl;
        const menuItem = menuItems.find(item => item.id === formData.productId);
        return menuItem?.imageUrl || null;
    }, [imageFile, formData.imageUrl, formData.productId, menuItems]);


    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        const checked = (e.target as HTMLInputElement).checked;
        setFormData(prev => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setImageFile(file);
            // Clear existing custom URL if a new file is uploaded
            setFormData(prev => ({ ...prev, imageUrl: undefined }));
        }
    };
    
    const handleRemoveCustomImage = () => {
        setImageFile(null);
        setFormData(prev => ({ ...prev, imageUrl: undefined }));
        if (fileInputRef.current) fileInputRef.current.value = "";
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (imageFile) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const newFormData = { ...formData, imageUrl: reader.result as string };
                onSave(newFormData);
            };
            reader.readAsDataURL(imageFile);
        } else {
            onSave(formData);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[60] p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">{advertisement ? 'Edit Advertisement' : 'Create Advertisement'}</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </header>
                <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
                    <div>
                        <label htmlFor="productId" className="block text-sm font-medium">Product to Feature</label>
                        <select
                            name="productId"
                            id="productId"
                            value={formData.productId}
                            onChange={handleChange}
                            required
                            className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                        >
                            {menuItems.map(item => (
                                <option key={item.id} value={item.id}>{item.name}</option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium">Ad Image</label>
                        <div className="mt-1 flex items-center gap-4">
                            <div className="w-24 h-24 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center overflow-hidden">
                                {imagePreviewUrl ? (
                                    <img src={imagePreviewUrl} alt="Ad preview" className="w-full h-full object-cover"/>
                                ) : (
                                    <ImageIcon className="w-10 h-10 text-gray-400"/>
                                )}
                            </div>
                            <div className="flex-1">
                                <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                                <button type="button" onClick={() => fileInputRef.current?.click()} className="w-full flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-600">
                                    <UploadIcon className="w-4 h-4" /> Upload Custom Image
                                </button>
                                {(imageFile || formData.imageUrl) && (
                                     <button type="button" onClick={handleRemoveCustomImage} className="w-full mt-2 flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-red-700 bg-red-100 border border-transparent rounded-md hover:bg-red-200 dark:bg-red-900/50 dark:text-red-200 dark:hover:bg-red-900">
                                         <TrashIcon className="w-4 h-4" /> Remove Custom Image
                                     </button>
                                )}
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Optional. If not provided, the default product image will be used.</p>
                            </div>
                        </div>
                    </div>
                    <div>
                        <label htmlFor="title" className="block text-sm font-medium">Title</label>
                        <input
                            type="text"
                            name="title"
                            id="title"
                            value={formData.title}
                            onChange={handleChange}
                            required
                            className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                            placeholder="e.g., Weekend Special!"
                        />
                    </div>
                    <div>
                        <label htmlFor="description" className="block text-sm font-medium">Description</label>
                        <textarea
                            name="description"
                            id="description"
                            rows={3}
                            value={formData.description}
                            onChange={handleChange}
                            required
                            className="mt-1 block w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                            placeholder="e.g., Get 20% off on all pizzas this weekend."
                        />
                    </div>
                    <div className="flex items-center">
                        <input
                            type="checkbox"
                            name="isActive"
                            id="isActive"
                            checked={formData.isActive}
                            onChange={handleChange}
                            className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <label htmlFor="isActive" className="ml-2 block text-sm font-medium">
                            Set as Active Banner
                        </label>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                        Note: Activating this banner will deactivate any other currently active banner.
                    </p>
                    <footer className="flex justify-end gap-3 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 rounded-md">Cancel</button>
                        <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save Advertisement</button>
                    </footer>
                </form>
            </div>
        </div>
    );
};

export default AdvertisementModal;
