

import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import { generateVideo, generateSpeechAudioUrl, generateImage } from '../services/geminiService';
import type { BackgroundMedia } from '../types';
import { CloseIcon, SparklesIcon, CheckCircleIcon } from './icons';

interface AIVideoGeneratorProps {
    onClose: () => void;
    onMediaGenerated: (media: BackgroundMedia) => void;
}

const AIVideoGenerator: React.FC<AIVideoGeneratorProps> = ({ onClose, onMediaGenerated }) => {
    const [mediaType, setMediaType] = useState<'video' | 'image'>('video');
    const [prompt, setPrompt] = useState('');
    const [voiceoverScript, setVoiceoverScript] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [statusMessage, setStatusMessage] = useState('');
    const [generatedMediaUrl, setGeneratedMediaUrl] = useState<string | null>(null);
    const [generatedAudioUrl, setGeneratedAudioUrl] = useState<string | null>(null);
    const [isKeySelected, setIsKeySelected] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const aiRef = useRef<GoogleGenAI | null>(null);

    useEffect(() => {
        const checkApiKey = async () => {
            // @ts-ignore
            if (window.aistudio && await window.aistudio.hasSelectedApiKey()) {
                setIsKeySelected(true);
            }
        };
        checkApiKey();
    }, []);

    const handleSelectKey = async () => {
        // @ts-ignore
        if (window.aistudio) {
            // @ts-ignore
            await window.aistudio.openSelectKey();
            // Assume selection is successful to avoid race conditions
            setIsKeySelected(true); 
        }
    };
    
    const resetStateForGeneration = () => {
        setIsLoading(true);
        setError(null);
        setGeneratedMediaUrl(null);
        setGeneratedAudioUrl(null);
    };

    const handleGenerate = async () => {
        if (!prompt.trim()) {
            setError("Prompt cannot be empty.");
            return;
        }

        resetStateForGeneration();
        
        // Re-initialize AI with the potentially new key right before the call
        aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

        if (mediaType === 'video') {
            if (!isKeySelected) {
                setError("Please select an API key for video generation.");
                setIsLoading(false);
                return;
            }
            try {
                const videoUrlPromise = generateVideo(aiRef.current, prompt, setStatusMessage);

                let audioUrlPromise: Promise<string | null> = Promise.resolve(null);
                if (voiceoverScript.trim()) {
                    setStatusMessage("Generating voiceover...");
                    audioUrlPromise = generateSpeechAudioUrl(aiRef.current, voiceoverScript);
                }

                const [videoUrl, audioUrl] = await Promise.all([videoUrlPromise, audioUrlPromise]);

                setGeneratedMediaUrl(videoUrl);
                if(audioUrl) setGeneratedAudioUrl(audioUrl);
                setStatusMessage("Generation complete!");

            } catch (e: any) {
                console.error("Video generation failed:", e);
                const errorMessage = e.message || "An unknown error occurred.";
                setError(`Generation failed: ${errorMessage}`);
                setStatusMessage("An error occurred during video generation.");
                if (errorMessage.includes("Requested entity was not found")) {
                     setError("Generation failed: Your API key may be invalid. Please re-select your key.");
                     setIsKeySelected(false);
                }
            } finally {
                setIsLoading(false);
            }
        } else { // Image generation
             try {
                setStatusMessage("Generating image...");
                const imageUrl = await generateImage(aiRef.current, prompt);
                setGeneratedMediaUrl(imageUrl);
                setStatusMessage("Image generation complete!");
            } catch (e: any) {
                console.error("Image generation failed:", e);
                const errorMessage = e.message || "An unknown error occurred.";
                setError(`Generation failed: ${errorMessage}`);
                setStatusMessage("An error occurred during image generation.");
            } finally {
                setIsLoading(false);
            }
        }
    };
    
    const handleAddToHomepage = () => {
        if (generatedMediaUrl) {
            onMediaGenerated({
                url: generatedMediaUrl,
                type: mediaType,
                voiceoverUrl: mediaType === 'video' ? generatedAudioUrl || undefined : undefined,
            });
            onClose();
        }
    };
    
    const TabButton: React.FC<{ type: 'video' | 'image', children: React.ReactNode }> = ({ type, children }) => (
        <button
            onClick={() => {
                setMediaType(type);
                setPrompt('');
                setVoiceoverScript('');
                setGeneratedMediaUrl(null);
                setError(null);
                setStatusMessage('');
            }}
            className={`flex-1 py-2 text-sm font-medium text-center transition-colors ${
                mediaType === type
                    ? 'border-b-2 border-indigo-500 text-indigo-600 dark:text-indigo-400'
                    : 'border-b border-gray-200 dark:border-gray-700 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
        >
            {children}
        </button>
    );

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700">
                    <h2 className="text-xl font-bold">AI Media Generator</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800 dark:hover:text-white">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </header>
                
                <div className="flex border-b dark:border-gray-700">
                    <TabButton type="video">Generate Video</TabButton>
                    <TabButton type="image">Generate Image</TabButton>
                </div>

                <main className="flex-1 p-6 overflow-y-auto space-y-4">
                    {mediaType === 'video' ? (
                        <>
                            {!isKeySelected && (
                                <div className="p-4 bg-yellow-100 dark:bg-yellow-900/50 border border-yellow-300 dark:border-yellow-700 rounded-lg text-center">
                                    <p className="text-sm text-yellow-800 dark:text-yellow-200 mb-2">
                                        Video generation with Veo requires an API key with access to the model. 
                                        <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="underline hover:text-yellow-600"> Learn about billing.</a>
                                    </p>
                                    <button onClick={handleSelectKey} className="px-4 py-2 bg-yellow-500 text-white font-semibold rounded-lg hover:bg-yellow-600">
                                        Select API Key
                                    </button>
                                </div>
                            )}
                            <div>
                                <label htmlFor="video-prompt" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Video Prompt</label>
                                <textarea
                                    id="video-prompt"
                                    rows={3}
                                    value={prompt}
                                    onChange={e => setPrompt(e.target.value)}
                                    placeholder="e.g., A cinematic, hyper-realistic video of a delicious pizza being sliced. Steam rises from the fresh cheese."
                                    className="mt-1 w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                                    disabled={isLoading || !isKeySelected}
                                />
                            </div>
                            <div>
                                <label htmlFor="voiceover-script" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Voiceover Script (Optional)</label>
                                <textarea
                                    id="voiceover-script"
                                    rows={2}
                                    value={voiceoverScript}
                                    onChange={e => setVoiceoverScript(e.target.value)}
                                    placeholder="e.g., Welcome to Stanley's Cafe, where every slice is a piece of heaven."
                                    className="mt-1 w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                                    disabled={isLoading || !isKeySelected}
                                />
                            </div>
                        </>
                    ) : (
                         <div>
                            <label htmlFor="image-prompt" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Image Prompt</label>
                            <textarea
                                id="image-prompt"
                                rows={3}
                                value={prompt}
                                onChange={e => setPrompt(e.target.value)}
                                placeholder="e.g., A photorealistic image of a steaming cup of coffee on a rustic wooden table in a cozy cafe."
                                className="mt-1 w-full p-2 border rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                                disabled={isLoading}
                            />
                        </div>
                    )}

                    <div className="h-40 bg-gray-100 dark:bg-gray-900 rounded-lg flex items-center justify-center">
                        {isLoading ? (
                            <div className="text-center">
                                <SparklesIcon className="w-10 h-10 text-indigo-500 animate-pulse mx-auto" />
                                <p className="mt-2 text-sm text-gray-600 dark:text-gray-300 font-medium">{statusMessage}</p>
                                {mediaType === 'video' && <p className="text-xs text-gray-500">AI video generation can take several minutes.</p>}
                            </div>
                        ) : generatedMediaUrl ? (
                            mediaType === 'video' ? (
                                <video src={generatedMediaUrl} controls className="w-full h-full object-contain rounded-lg" />
                            ) : (
                                <img src={generatedMediaUrl} alt="Generated media" className="w-full h-full object-contain rounded-lg" />
                            )
                        ) : error ? (
                             <p className="text-red-500 text-sm text-center p-4">{error}</p>
                        ) : (
                            <p className="text-gray-500">Your generated media will appear here.</p>
                        )}
                    </div>
                </main>

                <footer className="flex justify-end items-center space-x-3 p-4 bg-gray-50 dark:bg-gray-700/50 border-t border-gray-200 dark:border-gray-700">
                    {generatedMediaUrl && !isLoading ? (
                         <button
                            onClick={handleAddToHomepage}
                            className="px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 flex items-center gap-2"
                        >
                           <CheckCircleIcon className="w-5 h-5"/> Add to Homepage
                        </button>
                    ) : (
                         <button
                            onClick={handleGenerate}
                            disabled={isLoading || (mediaType === 'video' && !isKeySelected) || !prompt.trim()}
                            className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                            <SparklesIcon className="w-5 h-5"/> {isLoading ? 'Generating...' : 'Generate'}
                        </button>
                    )}
                </footer>
            </div>
        </div>
    );
};

export default AIVideoGenerator;