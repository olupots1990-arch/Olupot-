
import React, { useState, useEffect } from 'react';
import AdminView from './components/AdminView';
import WebsiteView from './components/WebsiteView';
import { DEFAULT_BACKGROUND_VIDEO, INITIAL_USERS, MOCK_ORDERS, INITIAL_EMPLOYEES, INITIAL_ADVERTISEMENTS, INITIAL_INVENTORY, INITIAL_INVENTORY_LOGS, INITIAL_GALLERY_PRODUCT_IDS, INITIAL_MENU_ITEMS } from './constants';
import { LocationInfo, VoiceoverAsset, User, Order, BackgroundMedia, Employee, Advertisement, InventoryItem, InventoryLogEntry, DeploymentLog, AiAssistantSettings, MenuItem } from './types';
import InstallerWizard from './components/InstallerWizard';
import { DownloadIcon } from './components/icons';

type View = 'website' | 'admin';
export type Page = 'home' | 'order' | 'gallery' | 'contact';
export type Theme = 'light' | 'dark' | 'system';

// Helper to get data from localStorage or use initial data
const usePersistentState = <T,>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] => {
    const [state, setState] = useState<T>(() => {
        try {
            const item = window.localStorage.getItem(key);
            // Dates need to be re-hydrated from string format
            if (item) {
                const parsed = JSON.parse(item);
                if (key === 'orders' || key === 'employees' || key === 'inventoryLogs' || key === 'deploymentHistory') {
                    return parsed.map((d: any) => ({
                        ...d,
                        timestamp: d.timestamp ? new Date(d.timestamp) : undefined,
                        hireDate: d.hireDate ? new Date(d.hireDate) : undefined,
                    }));
                }
                return parsed;
            }
        } catch (error) {
            console.error(`Error reading localStorage key “${key}”:`, error);
        }
        return initialValue;
    });

    useEffect(() => {
        try {
            window.localStorage.setItem(key, JSON.stringify(state));
        } catch (error) {
            console.error(`Error setting localStorage key “${key}”:`, error);
        }
    }, [key, state]);

    return [state, setState];
};


const App: React.FC = () => {
  const [isInstalled, setIsInstalled] = usePersistentState<boolean>('isInstalled', true);
  const [currentView, setCurrentView] = useState<View>('admin');
  const [activePage, setActivePage] = useState<Page>('home');
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [theme, setTheme] = usePersistentState<Theme>('theme', 'system');
  const [initialChatMessage, setInitialChatMessage] = useState<string | null>(null);
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  const [backgroundVideos, setBackgroundVideos] = usePersistentState<(BackgroundMedia | null)[]>('backgroundVideos', [
    { 
      url: DEFAULT_BACKGROUND_VIDEO, 
      type: 'video',
      transitionType: 'slide',
      transitionDuration: 1.5,
    },
    null,
    null,
    null,
    null
  ]);
  const [backgroundImages, setBackgroundImages] = usePersistentState<(BackgroundMedia | null)[]>('backgroundImages', [null, null, null, null]);
  const [backgroundMusicUrl, setBackgroundMusicUrl] = usePersistentState<string | null>('backgroundMusicUrl', null);
  const [location, setLocation] = usePersistentState<LocationInfo>('location', {
    address: "123 Foodie Lane, Valletta, VLT 1234, Malta",
    coordinates: { latitude: 35.8989, longitude: 14.5146 },
  });
  const [domainName, setDomainName] = usePersistentState<string>('domainName', 'www.stanleycafe.com');
  const [mediaLibrary, setMediaLibrary] = usePersistentState<BackgroundMedia[]>('mediaLibrary', []);
  const [voiceoverLibrary, setVoiceoverLibrary] = usePersistentState<VoiceoverAsset[]>('voiceoverLibrary', []);
  const [currencySymbol, setCurrencySymbol] = usePersistentState<string>('currencySymbol', '€');
  const [users, setUsers] = usePersistentState<User[]>('users', INITIAL_USERS);
  const [orders, setOrders] = usePersistentState<Order[]>('orders', MOCK_ORDERS);
  const [employees, setEmployees] = usePersistentState<Employee[]>('employees', INITIAL_EMPLOYEES);
  const [advertisements, setAdvertisements] = usePersistentState<Advertisement[]>('advertisements', INITIAL_ADVERTISEMENTS);
  const [inventory, setInventory] = usePersistentState<InventoryItem[]>('inventory', INITIAL_INVENTORY);
  const [inventoryLogs, setInventoryLogs] = usePersistentState<InventoryLogEntry[]>('inventoryLogs', INITIAL_INVENTORY_LOGS);
  const [galleryProductIds, setGalleryProductIds] = usePersistentState<string[]>('galleryProductIds', INITIAL_GALLERY_PRODUCT_IDS);
  const [menuItems, setMenuItems] = usePersistentState<MenuItem[]>('menuItems', INITIAL_MENU_ITEMS);
  const [deploymentHistory, setDeploymentHistory] = usePersistentState<DeploymentLog[]>('deploymentHistory', [
    { id: 'dep-1', timestamp: new Date(Date.now() - 86400000), status: 'Success', trigger: 'Initial deployment' }
  ]);
  const [aiSettings, setAiSettings] = usePersistentState<AiAssistantSettings>('aiSettings', {
    systemPrompt: "You are 'Stan', the AI assistant for Stanley's Cafe. Your responses must be helpful, concise, and straight to the point. Your main tasks are taking orders and answering questions about the menu. Use emojis like 🍕 or 😊 sparingly.",
    suggestionsEnabled: true,
  });
  
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const page = params.get('page') as Page | null;
    const view = params.get('view') as View | null;

    if (view === 'admin') {
      setCurrentView('admin');
    } else if (page && ['home', 'order', 'gallery', 'contact'].includes(page)) {
      setActivePage(page);
    }
  }, []);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const applyTheme = () => {
        if (theme === 'dark' || (theme === 'system' && mediaQuery.matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    };
    
    applyTheme();

    mediaQuery.addEventListener('change', applyTheme);
    return () => mediaQuery.removeEventListener('change', applyTheme);
  }, [theme]);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    installPrompt.userChoice.then((choiceResult: { outcome: 'accepted' | 'dismissed' }) => {
        if (choiceResult.outcome === 'accepted') {
            console.log('User accepted the install prompt');
        } else {
            console.log('User dismissed the install prompt');
        }
        setInstallPrompt(null);
    });
  };

  const handleLogout = () => {
    setCurrentView('website');
    setActivePage('home');
  };

  const NavLink: React.FC<{ page: Page, label: string }> = ({ page, label }) => (
    <button
      onClick={() => setActivePage(page)}
      className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
        activePage === page 
          ? 'text-indigo-600 dark:text-indigo-400 bg-gray-100 dark:bg-gray-700' 
          : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
      }`}
    >
      {label}
    </button>
  );

  if (!isInstalled) {
    return (
      <div className="bg-gray-200 dark:bg-gray-900 min-h-screen flex items-center justify-center font-sans p-4">
        <InstallerWizard onInstallComplete={() => setIsInstalled(true)} />
      </div>
    );
  }

  return (
    <div className="bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100 min-h-screen font-sans">
      {currentView === 'website' && (
        <nav className="bg-white dark:bg-gray-800 shadow-md sticky top-0 z-30">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center py-4">
              <h1 className="text-xl font-bold text-indigo-600 dark:text-indigo-400">Stanley's Cafe</h1>
              <div className="hidden md:flex items-center space-x-2">
                <NavLink page="home" label="Home" />
                <NavLink page="order" label="Order Online" />
                <NavLink page="gallery" label="Gallery" />
                <NavLink page="contact" label="Contact Us" />
              </div>
              <div className="flex items-center gap-2">
                {installPrompt && (
                  <button
                    onClick={handleInstallClick}
                    className="flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition text-white bg-indigo-500 hover:bg-indigo-600"
                  >
                    <DownloadIcon className="w-5 h-5" />
                    Install App
                  </button>
                )}
                <button
                  onClick={() => setCurrentView('admin')}
                  className="px-4 py-2 rounded-md text-sm font-medium transition text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  Admin Login
                </button>
              </div>
            </div>
          </div>
        </nav>
      )}

      <main>
        {currentView === 'website' ? (
          <WebsiteView 
            backgroundVideos={backgroundVideos}
            backgroundImages={backgroundImages}
            backgroundMusicUrl={backgroundMusicUrl} 
            location={location}
            activePage={activePage}
            setActivePage={setActivePage}
            advertisements={advertisements}
            galleryProductIds={galleryProductIds}
            menuItems={menuItems}
            initialChatMessage={initialChatMessage}
            setInitialChatMessage={setInitialChatMessage}
            isOnline={isOnline}
            aiSettings={aiSettings}
          />
        ) : (
          <AdminView 
            onLogout={handleLogout}
            backgroundVideos={backgroundVideos}
            setBackgroundVideos={setBackgroundVideos}
            backgroundImages={backgroundImages}
            setBackgroundImages={setBackgroundImages}
            backgroundMusicUrl={backgroundMusicUrl}
            setBackgroundMusicUrl={setBackgroundMusicUrl}
            location={location}
            setLocation={setLocation}
            domainName={domainName}
            setDomainName={setDomainName}
            mediaLibrary={mediaLibrary}
            setMediaLibrary={setMediaLibrary}
            voiceoverLibrary={voiceoverLibrary}
            setVoiceoverLibrary={setVoiceoverLibrary}
            currencySymbol={currencySymbol}
            setCurrencySymbol={setCurrencySymbol}
            users={users}
            setUsers={setUsers}
            orders={orders}
            setOrders={setOrders}
            employees={employees}
            setEmployees={setEmployees}
            advertisements={advertisements}
            setAdvertisements={setAdvertisements}
            inventory={inventory}
            setInventory={setInventory}
            inventoryLogs={inventoryLogs}
            setInventoryLogs={setInventoryLogs}
            isOnline={isOnline}
            theme={theme}
            setTheme={setTheme}
            galleryProductIds={galleryProductIds}
            setGalleryProductIds={setGalleryProductIds}
            menuItems={menuItems}
            setMenuItems={setMenuItems}
            deploymentHistory={deploymentHistory}
            setDeploymentHistory={setDeploymentHistory}
            aiSettings={aiSettings}
            setAiSettings={setAiSettings}
          />
        )}
      </main>
    </div>
  );
};

export default App;
