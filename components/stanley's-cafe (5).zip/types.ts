export type Message = {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: string;
  sources?: { uri: string; title: string }[];
};

export enum OrderStatus {
    PENDING = 'Pending',
    CONFIRMED = 'Confirmed',
    PREPARING = 'Preparing',
    OUT_FOR_DELIVERY = 'Out for Delivery',
    DELIVERED = 'Delivered',
    CANCELLED = 'Cancelled'
}

export enum PaymentMethod {
    CASH = 'Cash',
    CREDIT_CARD = 'Credit Card',
    MOBILE_MONEY = 'Mobile Money',
    OTHER = 'Other',
}

export type Order = {
  id: string;
  customerId: string; // Link to a user
  customerName: string; // Keep for legacy or quick entry
  customerPhone?: string;
  items: { name: string; quantity: number }[];
  total: number;
  status: OrderStatus;
  timestamp: Date;
  deliveryAgentId?: string;
  isPaid?: boolean;
  deliveryAgentNotes?: string;
  paymentMethod?: string;
  isNew?: boolean;
};

export type DeliveryAgent = {
  id:string;
  name: string;
  status: 'available' | 'on-delivery' | 'offline' | 'on-leave';
  phone: string;
  attendance?: Record<string, 'present' | 'absent' | 'on-leave'>;
  commissionRate?: number;
};

export type LeaveRequest = {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeType: 'agent' | 'employee';
  startDate: Date;
  endDate: Date;
  reason: string;
  status: 'pending' | 'approved' | 'denied';
};

export type GeolocationCoordinates = {
    latitude: number;
    longitude: number;
};

export type LocationInfo = {
  address: string;
  coordinates: GeolocationCoordinates;
};

export type VoiceoverAsset = {
  url: string;
  script: string;
};

export type UserRole = 'admin' | 'manager' | 'supervisor' | 'deliveryAgent' | 'customer';

export type User = {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  password?: string;
  phone?: string;
  profilePictureUrl?: string;
};

export interface BackgroundMedia {
  url: string;
  type: 'video' | 'image';
  voiceoverUrl?: string;
  transitionType?: 'fade' | 'slide' | 'zoom' | 'rotate';
  transitionDuration?: number;
}

export type EmployeeFile = {
  name: string;
  type: string;
  url: string;
  size: number;
};

export type Employee = {
  id: string;
  name: string;
  role: 'Chef' | 'Waiter' | 'Cashier' | 'Cleaner' | 'Other';
  hireDate: Date;
  phone?: string;
  email?: string;
  files: EmployeeFile[];
  baseSalary: number; // Monthly salary
  attendance?: Record<string, 'present' | 'absent' | 'on-leave'>;
};

export type Advertisement = {
  id: string;
  productId: string; // From MENU_ITEMS
  title: string;
  description: string;
  imageUrl?: string; // Optional custom image
  isActive: boolean;
};

export type PayrollData = {
    id: string; // employee or agent ID
    name: string;
    type: 'Employee' | 'Delivery Agent';
    baseSalary?: number;
    commissionRate?: number;
    deliveries?: number;
    commissionEarned?: number;
    bonuses: number;
    deductions: number;
    netPay: number;
};

export type InventoryItem = {
  id: string;
  name: string;
  category: string;
  assignedTo: string | null; // Employee ID
};

export type InventoryLogEntry = {
  id: string;
  itemId: string;
  employeeId: string;
  action: 'assigned' | 'unassigned';
  timestamp: Date;
  notes?: string;
};

export type Suggestion = {
  title: string;
  description: string;
  itemName?: string; // The menu item to add if the user accepts
};

export type DeploymentLog = {
    id: string;
    timestamp: Date;
    status: 'Success' | 'In Progress' | 'Failed';
    trigger: string;
};

export type AiAssistantSettings = {
  systemPrompt: string;
  suggestionsEnabled: boolean;
};

export type MenuItem = {
  id: string;
  name: string;
  price: number;
  imageUrl: string;
};